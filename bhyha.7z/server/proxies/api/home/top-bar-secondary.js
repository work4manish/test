var requireModule = require;

module.exports = function(app) {
  var express = requireModule('express'),
    mockServerRouter = express.Router();

  mockServerRouter.get('/linemanagerview/secondarytopbar', function(request, response) {
    var pageJSON;

    pageJSON = requireModule('../../_data/home/top-bar-secondary/top-bar-secondary.json');

    response.header("Access-Control-Allow-Origin", "*");

    return response.json(pageJSON);
  });

  app.use(app.contextPath, mockServerRouter);
};
