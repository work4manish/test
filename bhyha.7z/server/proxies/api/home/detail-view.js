var requireModule = require;
module.exports = function(app) {
  var express = requireModule('express'),
    mockServerRouter = express.Router();
  var dataPath = '../../_data';

  mockServerRouter.get('/chartview', function(req, res) {
    var pageJSON;
    var chartId = app.getQueryParamValue(req, 'chartId');
    var durationId = app.getQueryParamValue(req, 'durationfilter');

    if (chartId === 'Search_View_By_Dashboard') {
      pageJSON = requireModule(dataPath + '/search/search-item-detail-chart.json');
      res.json(pageJSON);
      return;
    }
    if (durationId === '1M') {
      pageJSON = requireModule(dataPath + '/home/exception/column.json');
    } else if (durationId === '2M') {
      pageJSON = requireModule(dataPath + '/home/exception/column2.json');
    } else {
      pageJSON = requireModule(dataPath + '/home/exception/column3.json');
    }

    res.header("Access-Control-Allow-Origin", "*");
    setTimeout(function() {
      res.json(pageJSON);
    }, 0);
  });


    mockServerRouter.get('/rbchartview', function(req, res) {
    var pageJSON;
    var chartId = app.getQueryParamValue(req, 'chartId');
    var durationId = app.getQueryParamValue(req, 'durationfilter');

    if (chartId === 'Search_View_By_Dashboard') {
      pageJSON = requireModule(dataPath + '/search/search-item-detail-chart.json');
      res.json(pageJSON);
      return;
    }
    if (durationId === '1M') {
      pageJSON = requireModule(dataPath + '/home/exception/column.json');
    } else if (durationId === '2M') {
      pageJSON = requireModule(dataPath + '/home/exception/column2.json');
    } else {
      pageJSON = requireModule(dataPath + '/home/exception/column3.json');
    }

    res.header("Access-Control-Allow-Origin", "*");
    setTimeout(function() {
      res.json(pageJSON);
    }, 0);
  });

  app.use(app.contextPath + '/:linemanagerview', mockServerRouter);
};
