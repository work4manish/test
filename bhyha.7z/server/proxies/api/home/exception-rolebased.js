var requireModule = require;
module.exports = function(app) {
  var express = requireModule('express'),
    mockServerRouter = express.Router();

  mockServerRouter.get('/viewbydashboard', function(req, res) {
    var pageJSON;
    pageJSON = requireModule('../../_data/home/exception/donut.json');
    res.header("Access-Control-Allow-Origin", "*");
    setTimeout(function() {
      res.json(pageJSON);
    }, 1000);
  });

  mockServerRouter.get('/viewbyemployee', function(req, res) {
    var pageJSON;
    var pageFilter = String(app.getQueryParamValue(req, 'pagefilter'));
    var roleId = String(app.getQueryParamValue(req, 'roleid'));
    if (roleId === 'LM') {
      pageJSON = requireModule('../../_data/home/exception/bar.json');
    } else {
      if(pageFilter=='sourcesystem'){
        pageJSON = requireModule('../../_data/home/exception/bar3.json');
      }
      if(pageFilter=='notionalamount'){
        pageJSON = requireModule('../../_data/home/exception/bar3-1.json');

      }
      if(pageFilter=='ragstatus'){
        pageJSON = requireModule('../../_data/home/exception/bar3-2.json');

      }else{
        pageJSON = requireModule('../../_data/home/exception/bar3.json');

      }
    }

    res.header("Access-Control-Allow-Origin", "*");
    setTimeout(function() {
      res.json(pageJSON);
    }, 1000);
  });

  mockServerRouter.get('/viewbysummary', function(req, res) {
    var pageJSON;
    pageJSON = requireModule('../../_data/home/exception/line.json');
    res.header("Access-Control-Allow-Origin", "*");
    setTimeout(function() {
      res.json(pageJSON);
    }, 0);
  });

  app.use(app.contextPath + '/rolebasedview', mockServerRouter);
};
