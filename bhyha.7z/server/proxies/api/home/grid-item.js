var requireModule = require;

module.exports = function(app) {
  var express = requireModule('express'),
    mockServerRouter = express.Router();
  var dataPath = '../../_data';

  mockServerRouter.get('/:griditem/gridview', function(request, response) {
    var pageJSON;
    var gridId = app.getQueryParamValue(request, 'gridId');

    console.log('***** ' + gridId);

    if (gridId === 'searchViewGrid')  {
      var selectedChartName = app.getQueryParamValue(request, 'selectedChart');
      if (selectedChartName === 'MISSED MARK') {
        pageJSON = requireModule(dataPath + '/search/search-item-detail-grid-missed-mark.json');
      } else {
        pageJSON = requireModule(dataPath + '/search/search-item-detail-grid.json');
      }
    } else {
      pageJSON = requireModule(dataPath + '/home/exception/grid.json');
    }

    return response.json(pageJSON);
  });

  app.use(app.contextPath, mockServerRouter);
};
