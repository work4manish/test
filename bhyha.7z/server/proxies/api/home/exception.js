var requireModule = require;
module.exports = function(app) {
  var express = requireModule('express'),
    mockServerRouter = express.Router();

  mockServerRouter.get('/viewbydashboard', function(req, res) {
    var pageJSON;
    pageJSON = requireModule('../../_data/home/exception/donut.json');
    res.header("Access-Control-Allow-Origin", "*");
    setTimeout(function() {
      res.json(pageJSON);
    }, 1000);
  });

  mockServerRouter.get('/viewbyemployee', function(req, res) {
    var pageJSON;
    var filterId = String(app.getQueryParamValue(req, 'durationfilter'));
    console.log(filterId);

    pageJSON = requireModule('../../_data/home/exception/bar.json');

    res.header("Access-Control-Allow-Origin", "*");
    setTimeout(function() {
      res.json(pageJSON);
    }, 1000);
  });

  mockServerRouter.get('/viewbysummary', function(req, res) {
    var pageJSON;
    var filterId = String(app.getQueryParamValue(req, 'durationfilter'));
    if (filterId === "1M") {
      pageJSON = requireModule('../../_data/home/exception/line.json');
    } else if (filterId === "2M") {
      pageJSON = requireModule('../../_data/home/exception/line-no-data.json');
    } else {
      pageJSON = requireModule('../../_data/home/exception/line.json');
    }
    res.header("Access-Control-Allow-Origin", "*");
    setTimeout(function() {
      res.json(pageJSON);
    }, 5000);
  });

  app.use(app.contextPath + '/linemanagerview', mockServerRouter);
};
