import Ember from 'ember';
import convertToJSON from '../mixins/convert-to-json';


export default Ember.Controller.extend(convertToJSON, {
  coreDataService: Ember.inject.service(),
  routing: Ember.inject.service('-routing'),
  userCurrentRoleService: Ember.inject.service(),
  userAssignedRoles: Ember.computed.alias('userCurrentRoleService.userAssignedRoles'),
  isAllSwitcheShow: true,

  routesMap: {
    generalMIS: 'home.general',
    exceptionMIS: 'home.exception'
  },

  actions: {

    changeView(selectedView) {
      console.log(selectedView);
      this.setSelectedContext(selectedView);
    },

    changeDashboardType(selectedDashboardType) {
      this.get('routing').transitionTo(this.routesMap[selectedDashboardType]);
    },

    toggleAll(state) {
      Ember.run.next(() => {
        this.send('selectAllDirectsReport', state.checked);
      });
    },

    onRoleChange(role) {
      this.get('userCurrentRoleService').setCurrentRole(role);
      this.setRoleConfig();
      this.send('assignedRoleForUser', role);
    },
    changedOtherAttributeTab(selectedAttrTab) {
      this.send('changedOtherAttribute', selectedAttrTab);
    }
  },

  init() {
    this.setRoleConfig();
    let selectedRole = this.get('userCurrentRoleService').getCurrentRole();
    let topBarSecondary = this.topBarSecondaryJSON();
    this.contextItems = topBarSecondary.contextItems;

    this.setProperties({
      contents: this.get('userAssignedRoles'),
      selectedRole: selectedRole.roleId,
      topBarSecondary: topBarSecondary,
      selectedContext: topBarSecondary.selectedContext,
      selectedContextIcon: topBarSecondary.selectedContextIcon,
      dashboardTypes: topBarSecondary.dashboardTypes,
      selectedDashboardType: topBarSecondary.selectedDashboardType
    });
  },

  updateTopBarSecondary(model) {

    let title = model.get('title');
    this.set('lastRefreshDate', title);

    let hideTabbs = false;
    let otherAttributeFilter = model.get('otherAttributeFilter');
    if (!Ember.isEmpty(otherAttributeFilter)) {
      let filterItems = this.convertToJSON(otherAttributeFilter);
      let selectedObject = filterItems.filterBy('selected', true)[0];
      if (!Ember.isEmpty(filterItems) && filterItems.length > 0) {
        this.setProperties({
          otherAttributeTabs: filterItems,
          otherAttributeTab: selectedObject.id,
        });
      }
    } else {
      hideTabbs = true;
    }
    this.toggleSecondaryTopBarTabs('detail', hideTabbs);

  },

  toggleSecondaryTopBarTabs(dashboard, flag) {
    let tabFlag = (dashboard === 'index') ? true : false;
    this.setProperties({
      dashboardViewTabs: false,
      detailViewTabs: false
    });
    Ember.run.next(() => {
      this.setProperties({
        isAllSwitcheShowOnDetail: flag,
        lastRefreshDateFlag: !tabFlag,
        dashboardViewTabs: tabFlag,
        detailViewTabs: flag ? tabFlag : !tabFlag
      });
    });

  },

  getDasboardTabs(topBarSecondary) {
    let dashboardTypes = topBarSecondary.dashboardTypes;
    let dashboardTabs = [];

    for (let i = 0, len = dashboardTypes.length; i < len; i++) {
      let dashboardType = dashboardTypes[i];

      dashboardTabs[i] = dashboardType;
      dashboardTabs[i]['id'] = dashboardType.id;
    }

    return dashboardTabs;
  },

  setSelectedContext(selectedView) {
    let contextItems = this.contextItems;

    for (let i = 0, len = contextItems.length; i < len; i++) {
      let contextItem = contextItems[i];

      if (contextItem.id === selectedView) {
        this.set('selectedContext', contextItem.text);
        this.set('selectedContextIcon', contextItem.iconClass);

        return;
      }
    }
  },

  setRoleConfig() {
    let selectedRole = this.get('userCurrentRoleService').getCurrentRole();
    let isLineManager = this.get('userCurrentRoleService').isLineManager();
    this.setProperties({
      roleConfig: selectedRole.roleConfig,
      isAllSwitcheShow: isLineManager
    });
  },

  topBarSecondaryJSON() {
    let topBarSecondaryObject = Ember.Object.create({
      "topBarSecondary": {
        "id": "top-bar-secondary1",

        "contextItems": [{
          "id": "sup-context-rb",
          "acronym": "RB",
          "text": "Role Based",
          "iconClass": "mdi-account-multiple"
        }, {
          "id": "sup-context-lm",
          "acronym": "LM",
          "text": "Line Manager",
          "iconClass": "mdi-account-circle",
          "isSelected": true
        }],

        "selectedContext": "Line Manager",
        "selectedContextIcon": "mdi-account-circle",

        "dashboardTypes": [{
          "id": "exceptionMIS",
          "title": "EXCEPTION MI"
        }, {
          "id": "generalMIS",
          "title": "GENERAL MI"
        }],

        "selectedDashboardType": "exceptionMIS"
      }
    });
    return topBarSecondaryObject.topBarSecondary;
  }
});
