import Ember from 'ember';
import Base from 'supdash-ui-base/controllers/top-bar';

export default Base.extend({
  routing: Ember.inject.service('-routing'),
  coreTransition: Ember.inject.service(),

  init() {
    this._super();
  },

  actions: {
    toggleView(className) {
      if (className === 'mdi-arrow-left') {
        this.get('routing').transitionTo(this.get('coreTransition').getPreviousRoute());
      }
    },

    onFocusSearchField(/*searchField*/) {
      this.showSearchPage('');
    },

    onFocusOutSearchField() {},

    onSearchStringChange(searchField) {
      let searchString = searchField.value;

      if (this.isSearchActive) {
        this.send('onKeyupSearchText', searchString);
      }
    }
  },

  showSearchPage(/*searchString*/) {
    this.transitionToRoute('home.search', {
      queryParams: {
        appTitle: 'Back'
      }
    });
  },

  setSearchActive(isActive) {
    let searchActiveClass = 'search-not-active';

    if (isActive) {
      searchActiveClass = 'search-active';
    } else {
      Ember.$('.base-search-box').val('');
    }

    this.set('searchActiveClass', searchActiveClass);
    this.set('isSearchActive', isActive);
  }
});
