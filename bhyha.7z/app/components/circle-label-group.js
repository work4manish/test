import Ember from 'ember';

export default Ember.Component.extend({
  classNames: ['col-sm-12 circle-label-group'],
  items: [],
  onSelect: null,   //custom event handler
  selectedView: null,

  activeItemChanged: Ember.observer('selectedView', function () {
    var items = Ember.$('#' + this.selectedView).parent().find('.circle-label');

    for (var i = 0; i < items.length; i++) {
      var item = Ember.$(items[i]);

      if (this.selectedView === item.attr('id')) {
        item.addClass('selected');
      } else if (item.hasClass('selected')) {
        item.removeClass('selected');
      }
    }
  }),

  actions: {
    updateSelectedView(selectedView) {
      console.log(selectedView);

      this.set('selectedView', selectedView);

      var onSelectHandler = this.get('onSelect');
      if (onSelectHandler) {
        this.sendAction(onSelectHandler, selectedView);
      }
    }
  },

  init() {
    this._super();

    var onSelecteHandler = this.get('onSelect');
    if (onSelecteHandler) {
      this[onSelecteHandler] = onSelecteHandler;
    }
  }
});
