import Ember from 'ember';
import convertToJSON from '../mixins/convert-to-json';

//const { get, A, computed } = Ember;

/**
 * Purpose: This is generic chart component, This componet is a wrapper for wb-new-barchart
 * All properites whihch will be required by wb-new-barchart are initialzed in the component
 * This also adds some dom element like header and action button on that header.
 */
export default Ember.Component.extend(convertToJSON, {
  store: Ember.inject.service('store'),
  chartClickAction: 'chartClickAction',
  onChartSeriesClickAction: 'onChartSeriesClickAction',
  refreshOnDurationFilterChange: 'refreshOnDurationFilterChange',
  resetRefreshFlagToFalse: 'resetRefreshFlagToFalse',
  detailSreenChartClick:'detailSreenChartClick',
  chartConfig: {},
  chartDataSourceConfig: {},
  isContentLoaded: false,
  showRadioComponent: false,
  serviceParams: {},
  modelNameForModule: null,
  fullWidth: false,
  durationFilter: false,
  regularFilter: false,
  hideHeader: false,
  sendActionToRoute: false,
  updateTitleValue: false,
  chartLoading: false,
  noDataFoundMessage: 'No Data Found',

  actions: {
    onTabChange(durationFilter) {
      if (this.get('sendActionToRoute')) {
        this.sendAction('refreshOnDurationFilterChange', durationFilter);
      } else {
        this.updateChartDataAndTitle('durationFilter', durationFilter);
      }
    },

    radioClickAction(dashboardName) {
      this.updateChartDataAndTitle('dashboardName', dashboardName);
    },

    SelectBoxChangeAction(pageFilter) {
      this.updateChartDataAndTitle('pageFilter', pageFilter);

    },

    chartSeriesClick(event) {
      this.sendAction('chartClickAction', event);
    },

    onChartSeriesClick(event) {
      if (this.updateTitleValue && this.get('chartTitleObj')) {
        this.set('chartTitleObj.value', event.value);
      }

      this.sendAction('onChartSeriesClickAction', event);
    },
    detailSreenChartClick(event){
      // if (this.updateTitleValue && this.get('chartTitleObj')) {
      //   this.set('chartTitleObj.value', event.value);
      // }
      this.sendAction('detailSreenChartClick',event)
    }
  },

  refreshObserver: Ember.observer('refresh', function() {
    if (this.get('refresh')) {
      this.set('chartLoading', true);
      this.init();
    }
  }),

  init: function() {
    this._super();
    this.modelNameForModule = this.get('modelNameForModule');
    this.serviceParams = this.get('serviceParams');
    let showRadioComponent = this.get('showRadioComponent');
    let serviceObjects = {
      chartServices: this.get('store').queryRecord(this.modelNameForModule, this.serviceParams)
    };

    if (showRadioComponent) {
      serviceObjects.radioServices = this.get('store').queryRecord('dashboardList', {});
    }

    Ember.RSVP.hash(serviceObjects).then((a_data) => {
      if(this.isDestroyed){
        return;
      }

      let chartServiceData = a_data.chartServices;
      let radioServiceData = !Ember.isEmpty(a_data.radioServices) ? a_data.radioServices : {};
      let chartData = chartServiceData.get('chartData');
      let config = chartServiceData.get('chartConfig');
      let chartSeries = chartData.get('chartSeries');
      let totalTitle = chartData.get('chartTitle');
      if(!Ember.isEmpty(config.get('noDataFoundMessage'))){
        this.set('noDataFoundMessage', config.get('noDataFoundMessage'));
      }
      let title = config.get('title');

      Ember.run.next(() => {
        this.set('chartLoading', false);
      });

      this.setDataAndConfig(chartSeries, config, title, totalTitle);
      this.setDurationFilter(chartServiceData.get('filter'));
      this.setRegularFilter(chartServiceData.get('filter'));

      if (showRadioComponent && !Ember.isEmpty(radioServiceData)) {
        this.setRadioFilter(radioServiceData);
      }

      if (this.get('refresh')) {
        this.sendAction('resetRefreshFlagToFalse', this);
      }

      this.set('isContentLoaded', true);
      this.set('showRadioComponent', showRadioComponent);
   });
  },

  updateChartDataAndTitle(attr, value) {
    this.set('chartLoading', true);
    this.serviceParams[attr] = value;
    this.get('store').queryRecord(this.modelNameForModule, this.serviceParams).then((a_data) => {
      if(this.isDestroyed){
        return;
      }
      this.set('chartData', a_data.get('chartData').get('chartSeries'));
      if(!Ember.isEmpty(a_data.get('chartConfig').get('noDataFoundMessage'))){
        this.set('noDataFoundMessage', a_data.get('chartConfig').get('noDataFoundMessage'));
      }
      this.set('chartTitleObj', a_data.get('chartData').get('chartTitle'));
      this.set('chartLoading', false);
    }.bind(this));
  },

  setRegularFilter(a_data) {
    let data = a_data.get('regularFilter');
    if (!Ember.isEmpty(data)) {
      let filterItems = this.convertToJSON(data);
      let selectedObject = filterItems.filterBy('selected', true)[0];
      if (!Ember.isEmpty(filterItems) && filterItems.length > 0) {
        this.set('regularFilter', true);
        this.setProperties({
          contents: filterItems,
          regularSelected: selectedObject.id,
        });
      }
    } else {
      this.set('regularFilter', false);
    }
  },

  setDurationFilter(a_data) {
    let data = a_data.get('durationFilter');
    if (!Ember.isEmpty(data)) {
      let filterItems = this.convertToJSON(data);
      let selectedObject = filterItems.filterBy('selected', true)[0];
      if (!Ember.isEmpty(filterItems) && filterItems.length > 0) {
        this.set('durationFilter', true);
        this.setProperties({
          filterItems: filterItems,
          selected: selectedObject.id,
        });
      }
    } else {
      this.set('durationFilter', false);
    }

  },

  setRadioFilter(a_data) {
    this.setProperties({
      selection: a_data.get('selected'),
      optionValuePath: 'id',
      optionLabelPath: 'title',
      content: a_data.get('dashboardItems'),
      clickAction: 'radioClickAction',
    });
  },

  setDataAndConfig(data, config, title, totalTitle) {
    this.setProperties({
      title: title,
      chartData: data,
      chartConfig: config,
      chartTitleObj: totalTitle,
    });
  }
});
