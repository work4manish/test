import Ember from 'ember';
import MapActionMixin from '../mixins/map-action-mixin';

export default Ember.Component.extend(MapActionMixin, {
  name: '',
  renderTo: null,
  prependToRenderTo: null,
  filter: null,
  taget: null,
  prependToTarget: null,
  showOn: 'click',
  header: {
    menuItems: null,
    selected: null,
    checkedMenu: false,
    multiSelect: false
  },
  menuItems: Ember.A([]),
  footer: {
    menuItems: null,
    selected: null,
    checkedMenu: false,
    multiSelect: false
  },
  selected: Ember.A([]),
  lastClickedMenuItem: null,
  optionLabelPath: 'title',
  optionValuePath: 'id',

  sendActionOnChange: Ember.observer('selected.length', function() {
    if (this.onChange && !this.get('init')) {
      this.sendAction(this.onChange, this.selected, this.lastClickedMenuItem);
    }
  }),

  actions: {
    onMenuItemClick(menuItem, section) {
      this.updateSelected(menuItem, section);

      if (this.onMenuItemClick) {
        this.sendAction(this.onMenuItemClick, this.lastClickedMenuItem, this.menuItems, this.selected, this.header, this.footer);
      }
    }
  },

  init() {
    this.set('init', true);
    this._super();
    this.mapAction('onChange');
    this.mapAction('onMenuItemClick');

    if (this.prependToTarget) {
      this.target = this.prependToTarget + this.target;
    }

    if (this.prependToRenderTo) {
      this.renderTo = this.prependToRenderTo + this.renderTo;
    }

    if (this.menuItems) {
      this.set('menuItems', Ember.A(this.menuItems));
    }

    if (this.headerMenuItems) {
      this.header.menuItems = Ember.A(this.headerMenuItems);
      delete this.headerMenuItems;
    }

    if (this.footerMenuItems) {
      this.footer.menuItems = Ember.A(this.footerMenuItems);
      delete this.footerMenuItems;
    }

    this.initializeSelectedItems();
    this.set('init', false);
  },

  initializeSelectedItems() {
    this.selected.clear();
    this.set('selected', this.getCheckedItemsFor(this.menuItems));

    if (this.header && this.header.menuItems) {
      this.header.selected = Ember.A([]);
      this.header.selected = this.getCheckedItemsFor(this.header.menuItems);
    }

    if (this.footer && this.footer.menuItems) {
      this.footer.selected = Ember.A([]);
      this.footer.selected = this.getCheckedItemsFor(this.footer.menuItems);
    }
  },

  getCheckedItemsFor(list) {
    var selectedItems = Ember.A([]);
    for (let i = 0, len = list.length; i < len; i++) {
      let item = list[i];

      if (item.isChecked) {
        selectedItems.addObject(item);
      }
    }

    return selectedItems;
  },

  didInsertElement() {
    this.contextMenu = Ember.$('#' + this.renderTo).kendoContextMenu({
      orientation: "vertical",
      target: '#' + this.target,
      alignToAnchor: true,
      //closeOnClick: true,
      filter: this.filter,
      animation: {
        open: {
          effects: "fadeIn"
        },
        duration: 500
      },
      showOn: this.showOn
    }).data('kendoContextMenu');
  },

  /*click(event) {
    if (this.checkedMenu) {
      if (event.target.type === 'checkbox') {
        this.updateSelected(Ember.$(event.target));
      }
    } else if (this.header.menuItems || this.footer.menuItems) {
      this.updateSelectedForCurrentSection(Ember.$(event.target));
    } else {
      this.selected.clear();
      this.updateSelected(Ember.$(event.target));
    }
  },*/

/*  updateSelected(targetItem) {
    if (this.checkedMenu) {
      let selectedText = this.getSelectedText(targetItem);
      let selectedItem = this.selected.findBy(this.optionLabelPath, selectedText);

      if (targetItem.is(':checked')) {
        if (!selectedItem) {
          selectedItem = this.menuItems.findBy(this.optionLabelPath, selectedText);
          selectedItem = Ember.Object.create(selectedItem);
          selectedItem.set('isChecked', true);
          this.lastClickedMenuItem = selectedItem;
          this.selected.addObject(selectedItem);
        }
      } else {
        if (selectedItem) {
          this.lastClickedMenuItem = Ember.Object.create(selectedItem);
          this.lastClickedMenuItem.set('isChecked', false);
          this.selected.removeObject(selectedItem);
        }
      }
    } else {
      console.log('TODO: implementaion pending for single select', targetItem);
    }
  },

  getSelectedText(targetItem) {
    return targetItem.next('label').text();
  },

*/

  updateSelected(menuItem, section) {
    let selected;
    let operation = menuItem.isChecked ? 'deselect' : 'select';
    this.lastClickedMenuItem = menuItem;

    Ember.set(menuItem, 'isChecked', !menuItem.isChecked);

    if (this.checkedMenu) {
      selected = this.selected;
    } else if (this.header && this.header.menuItems && this.header.menuItems.length > 0 ||
      this.footer && this.footer.menuItems && this.footer.menuItems.length > 0) {

      if (section === 'header' || section === 'footer') {
        selected = this[section].selected;
      } else {
        selected = this.selected;
      }
    }

    if (this.checkedMenu || this[section].multiSelect) {
      if (operation === 'deselect') {
        let selectedItem = selected.findBy(this.optionLabelPath, menuItem[this.optionLabelPath]);
        Ember.set(selectedItem, 'isChecked', false);
        selected.removeObject(selectedItem);
      } else {
        selected.addObject(menuItem);
      }
    } else {
      this.deselectAllExcept(menuItem, section);
    }
  },

  deselectAllExcept(currentMenuItem, section) {
    let menuItems = this[section].menuItems || this.menuItems;
    let selected = this[section].selected || this.selected;

    for (let i = 0, len = menuItems.length; i < len; i++) {
      let menuItem = menuItems[i];

      if (menuItem[this.optionValuePath] === currentMenuItem[this.optionValuePath]) {
        continue;
      }

      if (menuItem.isChecked) {
        Ember.set(menuItem, 'isChecked', false);
      }
    }

    selected.clear();
    selected.addObject(currentMenuItem);
  },

  getSelectedMenuItems() {
    if (this.header.menuItems || this.footer.menuItems) {
      return {
        header: this.getSelectedMenuItemsFor('header'),
        menuItems: this.selected,
        footer: this.getSelectedMenuItemsFor('footer')
      };
    } else {
      return this.selected;
    }
  },

  getSelectedMenuItemsFor(type) {
    if (this[type] && this[type].menuItems) {
      return this[type].selected;
    }

    return [];
  },

  willDistroy() {
    console.log('removed attached events');
    this.selected.clear();
    this.header = null;
    this.footer = null;
    this.menuItems = null;
    this.contextMenu = null;
  }
});
