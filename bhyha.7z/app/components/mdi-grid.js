import Ember from 'ember';
import PaginationHelper from '../mixins/pagination-helper';

export default Ember.Component.extend(PaginationHelper, {
  gridId: null,
  height: null,
  data: null,
  gridItemId: null, //'This value will be sent to server to fetch grid data'
  gridIdParamKey: 'gridItemId',
  coreDataService: Ember.inject.service(),
  resetRefreshFlagToFalse: 'resetRefreshFlagToFalse',
  reCreateGrid: false,
  resetConfig: false,
  bottomBar: null,
  topBar: null,
  serverPaging: true,
  serverFiltering: false,
  serverSorting: false,
  onColumnMenuSelect: 'onColumnMenuSelect',
  defaultPageable: {
    "pageSizes": [5, 10, 20, 100],
    "pageSize": 10,
    "messages": {
      "itemsPerPage": "Rows per page:",
      "display": "{0}-{1} of {2}",
      "empty": "No data"
    },
  },

  reCreateGridObserver: Ember.observer('reCreateGrid', function() {
    if (this.reCreateGrid) {

      this.createGrid(this.gridConfig);

      this.set('reCreateGrid', false);
    }
  }),

  refreshObserver: Ember.observer('refresh', function() {
    if (this.get('refresh')) {
      this.refreshGrid();
    }
  }),

  dataObserver: Ember.observer('data', function() {
    this.updateGridDataSource();
  }),

  setupConfig: Ember.on('init', function() {
    if (this.gridConfig) {
      this.initializeConfig();
    } else {
      this.fetchConfig();
    }
  }),

  actions: {
    onColumnMenuSelect(selectedColumns, lastClickedColumn) {
      if (lastClickedColumn.isChecked) {
        this.grid.showColumn(lastClickedColumn.field);
      } else {
        this.grid.hideColumn(lastClickedColumn.field);
      }
    }
  },

  initializeConfig() {
    if (this.gridConfig.kendoDefault) {
      this.set('gridConfig', this.gridConfig);
    } else {
      this.setupGridConfig();
    }
  },

  fetchConfig() {
    let params = this.get('serviceParams') || {};
    params[this.gridIdParamKey] = this.gridItemId;

    this.get('coreDataService').queryRecord('gridItem', params).then((gridItem) => {
      this.gridConfig = gridItem.get('gridConfig');
      this.gridData = gridItem.get('gridData');
      this.initializeConfig(gridItem);
      this.set('reCreateGrid', true);
    });
  },

  refreshGrid(reCreateGrid, pageNumber) {
    let params = this.get('serviceParams') || {};

    params[this.gridIdParamKey] = this.gridItemId;
    params.configRequired = false;
    params.currentPage = pageNumber ? pageNumber : 1;
    params.pageSize = this.get('pageSize');

    this.get('coreDataService').queryRecord('gridItem', params).then((gridItem) => {
      this.gridData = gridItem.get('gridData');
      this.set('data', this.gridData.data);
      this.sendAction('resetRefreshFlagToFalse');
    });
  },

  setupGridConfig() {
    this.gridConfig.height = this.get('height');

    if (this.gridConfig.gridId) {
      this.set('gridItemId', this.gridConfig.gridId);
    }

    this.setupTopBarConfig();

    if (this.gridConfig.highlightCell) {
      this.setColumnTemplate();
    }

    this.set('columnMenu', this.gridConfig.columnMenu);
    this.gridConfig.columnMenu = false;

    this.addColumnAlignmentTemplate();
    this.prepareColumnListMenu();
    this.setDataBoundEvent();
    this.setDataSource();
    //this should be last one, because for server side paging defaultPageable object is changed
    this.setBottomBar();
    this.postSetupGridConfig();
  },

  setupTopBarConfig() {
    let topBarItems = [];
    let isTopBarPresent = false;

    if (false/*this.gridConfig.downloadEnable*/) {
      isTopBarPresent = true;

      topBarItems[topBarItems.length] = {
        title: 'Export',
        iconClass: 'mdi-download',
        text: 'Export'
      };
    }

    if (isTopBarPresent || (this.gridConfig.topBar && typeof this.gridConfig.topBar === 'object')) {
      this.set('topBarItems', isTopBarPresent ? topBarItems : this.gridConfig.topBar);
    }
  },

  postSetupGridConfig() {
    if (this.serverPaging) {
      this.set('pageSize', this.gridConfig.pageable.pageSize);
      this.handleServerPagination(this.gridData);
    }
  },

  didInsertElement() {
    let gridConfig = this.get('gridConfig');

    try {
      this.set('gridId', this.elementId + '-kendo-grid');

      if (gridConfig) {
        this.createGrid(gridConfig);
      } else {
        this.$('#' + this.gridId).kendoGrid();
      }

      this.sendAction('afterGridRender', this);
    } catch (error) {
      Ember.Logger.error(error);
    }
  },

  createGrid: function(gridConfig) {
    let gridIdSelector = "#" + this.gridId;
    this.$(gridIdSelector).kendoGrid(gridConfig);
    this.set('grid', this.$(gridIdSelector).data("kendoGrid"));
    this.set('data', this.getData(this.get('serverPaging')));
    /*this.gridLoadingObserver(); //call the progress bar loader on init*/
    this.postGridCreationTasks();
  },

  setDataBoundEvent() {
    let dataBound = this.gridConfig.dataBound;

    this.gridConfig.dataBound = (event) => {
      if (this.gridConfig.highlightCell) {
        this.highlightCell();
      }

      if (dataBound) {
        dataBound(event);
      }
    };
  },

  setColumnTemplate() {
    if (this.gridConfig.highlightCell) {
      let highlightCellColorField = this.gridConfig.highlightCellColorField || 'color';
      let firstColumn = this.gridConfig.columns[0];
      let tempalte;

      if (typeof firstColumn.tempalte === 'function') {
        tempalte = firstColumn.tempalte;
      }

      firstColumn.template = (record) => {
        if (!this.dataUidMap) {
          this.dataUidMap = [];
        }
        this.dataUidMap['' + record.get('uid') + ''] = record.get(highlightCellColorField);

        if (tempalte) {
          return tempalte(record);
        }

        let html = '';
        if (firstColumn.align) {
          html += this.getColumnAlignHTML(firstColumn, record);
        } else {
          html = record.get(firstColumn.field);
        }
        return html;
      };
    }
  },

  addColumnAlignmentTemplate() {
    let columns = this.gridConfig.columns;

    //started from i = 1 because alignment has been handler in firstColumnTemplate
    for (let i = 1, len = columns.length; i < len; i++) {
      let column = columns[i];

      if (column.align) {
        column.template = this.getColumnAlignHTML.bind(this, column);
      }
    }
  },

  prepareColumnListMenu() {
    if (this.get('columnMenu')) {
      let columnMenuItems = [];

      for (let i = 0, len = this.gridConfig.columns.length; i < len; i++) {
        let column = this.gridConfig.columns[i];
        let columnMenuItem = column;

        if (columnMenuItem.locked) {
          continue;
        }

        columnMenuItem.isChecked = true;
        columnMenuItems[columnMenuItems.length] = columnMenuItem;
      }

      this.set('columnMenuItems', columnMenuItems);
    }
  },

  getActionColumnTemplate: function() {
    var template = '';
    template += '<div class="dropdown column-action-menu">';
    template += '<span class="mdi mdi-dots-vertical" id="' + this.elementId + '-column-menu" data-toggle="dropdown" aria-expanded="true"></span>';
    template += '</div>';

    return template;
  },

  getColumnAlignHTML(columnConfig, record) {
    return '<span class="align-span-' + columnConfig.align + '">' + record.get(columnConfig.field) + '</span>';
  },

  highlightCell() {
    for (let key in this.dataUidMap) {
      if (this.dataUidMap.hasOwnProperty(key)) {
        let trObj = Ember.$('[data-uid=' + key + ']')[0];
        let firstCell = Ember.$(trObj).find('td:first-child');

        firstCell.css('border-left', '3px solid ' + this.dataUidMap[key]);
      }
    }
  },

  setDataSource() {
    if (this.gridData) {
      this.set('serverPaging', ((String(this.gridConfig.hideBottomBar) !== 'true') &&
                                (this.gridConfig.serverPaging !== 'false' || this.gridConfig.serverPaging !== false)));

      this.gridConfig.dataSource = {
        data: [],
        serverPaging: this.get('serverPaging'),
        serverFiltering: false,
        serverSorting: false
      };
    }
  },

  updateGridDataSource() {
    if (this.serverPaging) {
      this.clearDataSource();
      let data = this.get('data');

      for (let i = 0, len = data.length; i < len; i++) {
        let dataItem = data[i];

        this.grid.dataSource.add(dataItem);
      }
    } else {
      this.grid.dataSource.data(this.get('data'));
    }
  },

  clearDataSource() {
    let dataSource = this.grid.dataSource;

    while (dataSource.data().length) {
      let dataItem = dataSource.data()[0];

      dataSource.remove(dataItem);
    }
  },

  getData(serverPaging) {
    let data;

    if (serverPaging) {
      data = this.gridData.data;
      this.set('totalRecords', this.gridData.total);
      if (!data || !(data instanceof Array)) {
        Ember.Logger.error('gridData must have key data for sever side pagination.');
      }
    } else {
      data = this.gridData;

      if (!(data instanceof Array)) {
        if (this.gridData.data instanceof Array) {
          data = this.gridData.data;
          this.gridData = data;
        } else {
          Ember.Logger.error('gridData or gridData.data must be an array for client side pagination.');
        }
      }
    }

    return data;
  },

  setBottomBar() {

    if (!this.gridConfig.hideBottomBar) {
      this.gridConfig.bottomBar = {
        pageable: true
      };
    }

    if (this.gridConfig.bottomBar) {
      let pageable = this.gridConfig.bottomBar.pageable;

      if (pageable) {
        if (pageable === true || pageable === 'true') {
          this.gridConfig.pageable = this.defaultPageable;
        } else {
          this.gridConfig.pageable = this.defaultPageable;

          for (let key in pageable) {
            if (pageable.hasOwnProperty(key)) {
              this.gridConfig.pageable[key] = pageable[key];
            }
          }
        }
      } else {
        this.gridConfig.pageable = false;
      }
    }
  },

  postGridCreationTasks() {
    this.addCustomLegendPanel();
    this.handleServerPaginationElements();
    this.appendColumnListMenuTemplate();
    this.addDomEvents();
  },

  appendColumnListMenuTemplate() {
    if (this.get('columnMenu')) {
      let headerWrapEl = Ember.$('#' + this.gridId + ' .k-grid-header');

      headerWrapEl.append('<div class="sup-column-menu mdi mdi-dots-vertical"></div>');
    }
  },

  addDomEvents() {

  },

  addCustomLegendPanel() {
    if (this.gridConfig.bottomBar) {
      let legends = this.gridConfig.bottomBar.legends;

      if (legends) {
        let gridPanel = Ember.$('#' + this.gridId);
        let pagerPanel = gridPanel.find('.k-pager-wrap.k-grid-pager');

        if (pagerPanel) {
          let html = '<div class="legend-panel">';

          for (let i = 0; i < legends.length; i++) {
            let legend = legends[i];

            html += '<div class="legend-item">';
            html += '<span class="lengend-icon" style="background:' + legend.color + ';"></span>';
            html += '<span class="lengend-text" style="">' + legend.text + '</span>';
            html += '</div>';
          }

          html += '</div>';

          pagerPanel.prepend(html);
        }
      }
    }
  },

  willDestroy() {
    if (this.serverPaging) {
      this.pageSizeCombo.off('change');
    }
    console.log('remove all attached events for : ' + this.gridItemId);
  }
});
