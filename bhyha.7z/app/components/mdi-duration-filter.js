import Ember from 'ember';

export default Ember.Component.extend({
  selected: null,
  selectedDurationLabel: '',
  onTabChange: 'onTabChange',
  dayFormat: 'DD',
  monthFormat: 'MMM',
  yearFormat: 'YYYY',
  durationMap: {
    D: 'd',
    W: 'w',
    M: 'M',
    Y: 'y'
  },

  actions: {
    onTabChange(selectedValue) {
      if (!this.isCalendarTab(selectedValue)) {
        this.setSelectedDurationLabel(selectedValue);
      }

      this.sendAction('onTabChange', selectedValue);
    }
  },

  getDateRage(selectedValue) {
    let endDate = moment();
    let startDate;

    for (let key in this.durationMap) {
      if (selectedValue.toUpperCase().indexOf(key) > -1) {
        let factor = parseInt(selectedValue.split(key)[0]);
        startDate = moment(endDate).add((factor * -1), this.durationMap[key]);

        break;
      }
    }

    let dateRange;
    let format = this.dayFormat + ' ' + this.monthFormat + ' ' + this.yearFormat;

    if (!startDate) {
      startDate = moment(selectedValue);
    }

    if (startDate.year() === endDate.year()) {
      if (startDate.month() === endDate.month()) {
        dateRange = startDate.format(this.dayFormat) + ' - ' + endDate.format(format);
      } else {
        dateRange = startDate.format(this.dayFormat + ' ' + this.monthFormat) +' - '+ endDate.format(format);
      }
    } else {
      dateRange = startDate.format(format) +' - '+ endDate.format(format);
    }

    return dateRange;
  },

  isCalendarTab(selectedValue) {
    let filterItems = this.get('filterItems');

    if (filterItems) {
      for (let i = 0; i < filterItems.length; i++) {
        let filterItem = filterItems[i];

        if (selectedValue === filterItem.id && filterItem.type === 'date') {
          return true;
        }
      }
    }

    return false;
  },

  init() {
    this._super();

    this.setSelectedDurationLabel(this.selected);

    let filterItems = this.get('filterItems');

    if (filterItems) {
      for (let i = 0; i < filterItems.length; i++) {
        let filterItem = filterItems[i];

        if (filterItem.type === 'date') {
          var customClassNames = this.get('customClassNames');
          if (!customClassNames) {
            customClassNames = '';
          }

          filterItem.customClassNames = customClassNames + ' ' + 'mdi mdi-calendar';
          this.set('addDatePicker', true);
        }
      }
    }
  },

  setSelectedDurationLabel(selectedValue) {
    this.set('selectedDurationLabel', this.getDateRage(selectedValue));
  }
});
