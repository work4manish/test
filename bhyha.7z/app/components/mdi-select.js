import Ember from 'ember';
import MaterializeSelect from 'ember-cli-materialize/components/md-input-field';
import layout from '../templates/components/mdi-select';
import MapActionMixin from '../mixins/map-action-mixin';

export default MaterializeSelect.extend(MapActionMixin, {
  layout,
  classNames: ['md-select'],
  optionLabelPath: 'content',
  optionValuePath: 'content',
  previousValue: '',
  actions: {
    onChangeHandler(/*e*/) {
      let value = this.$('select').val();
      let preValue = this.get('previousValue');
      if (!Ember.isEmpty(this.get('action')) && value !== preValue) {
        this.set('previousValue', value);
        this.sendAction(this.action, value);
      }
    }
  },
  init() {
    this._super();
    this.mapAction('action');
  },
  didInsertElement() {
    this._super(...arguments);
    this._setupSelect();
    this.set('previousValue', this.get('value'));
  },

  _setupSelect() {
    // jscs: disable
    this.$('select').material_select();
    //jscs: enable
  },

  _parsedContent: Ember.computed('optionValuePath', 'optionLabelPath', 'content.[]', function() {
    const contentRegex = /(content\.|^content$)/;
    // keep backwards compatability for defining optionValuePath & as optionContentPath `content.{{attName}}`
    const optionValuePath = (this.get('optionValuePath') || '').replace(contentRegex, '');
    const optionLabelPath = (this.get('optionLabelPath') || '').replace(contentRegex, '');
    return Ember.A((this.get('content') || []).map((option) => {
      return Ember.Object.create({
        value: optionValuePath ? Ember.get(option, optionValuePath) : option,
        label: optionLabelPath ? Ember.get(option, optionLabelPath) : option
      });
    }));
  }),

  //  that is bound to the class attribute of the inputSelector
  errorsDidChange: Ember.observer('errors', function() {
    const inputSelector = this.$('input');
    // monitor the select's validity and copy the appropriate validation class to the materialize input element.
    if (!Ember.isNone(inputSelector)) {
      Ember.run.later(this, function() {
        const isValid = this.$('select').hasClass('valid');
        if (isValid) {
          inputSelector.removeClass('invalid');
          inputSelector.addClass('valid');
        } else {
          inputSelector.removeClass('valid');
          inputSelector.addClass('invalid');
        }
      }, 150);
    }
  })
});
