import Ember from 'ember';
import layout from '../templates/components/chart-component';
import convertToJSON from '../mixins/convert-to-json';


export default Ember.Component.extend(convertToJSON, {
  layout: layout,
  classNames: ['chartview'],
  showToolTip: false,
  chartInstance: null,
  chartData: [],
  chartLoading: false,
  supDashConfig: true,
  chartDataSourceConfig: {},
  isChartEmpty: false,
  noDataFoundMessage: 'No Data Found',
  staticSeriesWidth: true,

  init() {
    this._super();
    this.seriesShiftDistace = 0;
    let chartConfigObj = this.get('chartConfig');
    if (this.get('supDashConfig') && !Ember.isEmpty(chartConfigObj) && chartConfigObj.get('xAxis')) {
      this.buildSupdashConfig(chartConfigObj);
    }else if(this.get('supDashConfig')){
      this.set('chartConfig',{});
    }
  },

  willInsertElement() {
    this.$('.chartview').kendoChart(this.get('chartConfig'));
    this.chartInstance = this.$('.chartview').data("kendoChart");

    this.chartInstance.bind("dataBound", function (e) {
              this.setDataBoundForChart(e);
          }.bind(this));
    this.chartInstance.bind("render", function (e) {
              this.setOnRenderHanlder(e);
          }.bind(this));

    this.$(window).resize(() => {
      if (!Ember.isEmpty(this.chartInstance)) {
        this.chartInstance.refresh();
      }
    });
    this.doDraw();
    this._super();
  },
  // resize () {
  //   if (this.chartInstance) {
  //       this.chartInstance.resize();
  //   }
  //   this.set('chartLoading', false);
  // },

  didInsertElement() {
   // this.set('chartLoading', true);
    if (!Ember.isEmpty(this.chartInstance)) {
        this.chartInstance.resize();
    }
   //Ember.run.later(this, this.resize.bind(this), 1000);
  },

  loadingObserver: Ember.observer('chartLoading', function() {
    let chartLoading = this.get('chartLoading');
    this.set('chartLoading',chartLoading);
  }),

  doDraw: Ember.observer('chartData', function() {
    var chartData = this.get('chartData');
    if (chartData && this.$('.chartview')) {
      this.chartInstance = this.$('.chartview').data("kendoChart");
      this.set('noDataFoundMessage',this.get('noDataFoundMessage'));
      this.get('chartConfig').dataSource = {
        data: this.convertToJSON(chartData)
      };
      this.prepareDataSourceConfig(this.get('chartConfig'), this.get('chartDataSourceConfig'));
      if (!this.chartInstance) {
        this.$('.chartview').kendoChart(this.get('chartConfig'));
        this.chartInstance = this.$('.chartview').data("kendoChart");
      }
      this.chartInstance.setDataSource(this.get('chartConfig').dataSource);
      this.chartInstance.redraw();
    }else if (chartData) {
      this.get('chartConfig').dataSource = {data: this.convertToJSON(chartData)};
      this.prepareDataSourceConfig (this.get('chartConfig'), this.get('chartDataSourceConfig'));
    }
    return true;
  }),

  buildSupdashConfig(graphConfig) {

    this.chartType = graphConfig.get('type');
    //For setting x-axis and y-axis
    let xAxis = graphConfig.get('xAxis');
    let yAxis = graphConfig.get('yAxis');
    let xAxisLabel = graphConfig.get('xAxisDisplayName') || xAxis;

    //group by config
    let groupBy = graphConfig.get('groupBy') || false;
    let isGrouping = groupBy ? true : false;
    let stackFlag = graphConfig.get('stack') || false;
    let legendPosition = graphConfig.get('legend') || 'bottom';

    let chartConfigObj = {};
    chartConfigObj.theme = 'bootstrap';
    chartConfigObj.tooltip = {
      background: "black",
      visible: true,
      template: this.createToolTipTemplate.bind(this)
    };
    chartConfigObj.legend = this.createLegendConfig(this.chartType, legendPosition);
    chartConfigObj.categoryAxis = this.createCategoryConfig(this.chartType);
    chartConfigObj.series = this.createSeriesConfig(this.chartType, yAxis, stackFlag, xAxisLabel);
    chartConfigObj.valueAxis = this.createValueAxisConfig(this.chartType);
    chartConfigObj.pannable = {
      lock: (this.chartType.toUpperCase() === "BAR") ? 'x' : 'y'
    };
    chartConfigObj.chartArea = {
      height: 320
    };
    //Action handler
    let axisClickAction = graphConfig.get('axisClick');
    let seriesClickAction = graphConfig.get('seriesClick');

    if (seriesClickAction) {
      this[seriesClickAction] = seriesClickAction;
      chartConfigObj.seriesClick = this.onSeriesClick.bind(this, seriesClickAction);
    }

    if (axisClickAction) {
      this[axisClickAction] = axisClickAction;
      chartConfigObj.axisLabelClick = this.onAxisClick.bind(this, axisClickAction);
    }

    let chartDataSourceConfigObj = {};
    chartDataSourceConfigObj.isGrouping = isGrouping;
    chartDataSourceConfigObj.groupField = groupBy;

    this.setProperties({
      chartConfig: chartConfigObj,
      chartDataSourceConfig: chartDataSourceConfigObj
    });
  },

  createLegendConfig(type, position) {
    let legendconfig = {};
    type = type.toUpperCase();
    legendconfig.position = position;
    legendconfig.labels = {
      color: '#4a4a4a',
      font: "11px Roboto-Regular",
      margin: {
        bottom: 10
      },
      template: "#: text.toUpperCase() #"
    };
    legendconfig.markers = {
      type: "circle",
      width: 7,
      margin: {
        bottom: 10
      },
    };
    if (type === "DONUT") {
      legendconfig.offsetX = -20;
    }
    if (type === "BAR") {
      legendconfig.offsetY = 10;
    }
    if (type === "COLUMN" && position !== 'bottom') {
      legendconfig.offsetX = 20;
      legendconfig.offsetY = -60;
    }
    return legendconfig;
  },

  createValueAxisConfig(type) {
    let chartType = type.toUpperCase();
    let valueAxis = {
      labels: {
        //visible: (chartType === "BAR" || chartType === "LINE") ? true : false,
        visible: true ,
        color: "#a6a6a6",
        font: "11px Roboto-Regular",
        template: "#= kendo.format('{0:N0}', value) #"
      },
      line: {
        visible: (chartType === "BAR")
      }
    };

    return valueAxis;
  },

  createSeriesConfig(type, value, stack, categoryAxis) {
    let series = [];
    let seriesObj = {};
    let chartType = type.toUpperCase();
    seriesObj.field = value;
    seriesObj.type = type;
    seriesObj.border = {
      width: 0
    };
    seriesObj.colorField = "color";
    seriesObj.categoryField = categoryAxis;
    if (chartType === 'BAR' || chartType === 'COLUMN' || chartType === 'DONUT') {
      seriesObj.stack = stack;
      seriesObj.visual = this.setSeriesWidthToFixedVlaue.bind(this);
    }

    if (chartType === 'BAR') {
      seriesObj.gap = 0;
    }
    if (chartType === 'LINE') {
      seriesObj.style = "smooth";
    }
    if (chartType === 'DONUT') {
      seriesObj.holeSize = 80;
    }
    series.push(seriesObj);
    return series;
  },

  createCategoryConfig(type) {
    type = type.toUpperCase();
    let catAxis = {};
    catAxis.max = (type === "LINE" || type === "COLUMN") ? 12 : 6;
    catAxis.majorTicks = {
      width: 0
    };
    catAxis.labels = {
      font: "13px Roboto-Regular",
      color: '#424242',
      visual: this.createLabelItem.bind(this)
    };

    catAxis.majorGridLines = {
      visible: (type === "BAR") ? true : false
    };

    return catAxis;
  },

  createToolTipTemplate(a_data) {
    let w_tpl;
    let category = a_data.category ? a_data.category : 'Unknown';
   // let category = a_data.category ? a_data.category.toUpperCase() : 'Unknown';
    w_tpl = (category + ' : <span class="tooltip-number">' + a_data.dataItem['displayValue'] + '<span>');
    w_tpl = '<div class="tooltip-container">' + w_tpl + '</div>';
    return w_tpl;
  },

  setSeriesWidthToFixedVlaue(e) {
    let visual = e.createVisual();
    let chartType = this.chartType.toUpperCase();
    if (chartType === "BAR") {
      let rect = e.rect;
      let origin = rect.origin;
      let bottomRight = rect.bottomRight();
      let geom = kendo.geometry;
      let Rect = geom.Rect;
      let color = e.dataItem ? e.dataItem.color : '';
      let seriesShiftDistace = rect.bottomRight().y - rect.center().y - 10;

      rect.origin.y = rect.origin.y + seriesShiftDistace;
      this.seriesShiftDistace = seriesShiftDistace;
      let rectLayout = new Rect(rect.origin, rect.size);
      visual = new kendo.drawing.Layout(rectLayout, {
        alignContent: "center",
        alignItems: "center",
        justifyContent: "center",
        spacing: 10,
        lineSpacing: 0
      });

      let marker = new kendo.drawing.Path({
        fill: {
          color: color
        },
        stroke: "none"
      }).moveTo(origin.x, origin.y).lineTo(bottomRight.x, origin.y).lineTo(bottomRight.x, origin.y + 20).lineTo(origin.x, origin.y + 20).close();

      visual.append(marker);
      visual.reflow();
    } else if (chartType === 'COLUMN') {
      var BAR_SIZE = 20;
      visual.transform(kendo.geometry.transform().scale(BAR_SIZE / e.rect.size.width, 1, e.rect.center()));
    } else if (chartType === 'DONUT') {}
    return visual;
  },

  setTotalLabel(chart, toggledSeriesIndex) {
    /*var categoryAxis = chart.options.categoryAxis;
    var categories = categoryAxis.categories;
    var categorDataItem = Ember.A(categoryAxis.dataItems);
    var dataSource = chart.dataSource.data().toJSON();
    dataSource = Ember.A(dataSource);
    var allSeries = chart.options.series;
    var categoryField = allSeries[0].categoryField
    var seriesField = allSeries[0].field

    for(let j=0;j<categories.length;j++){
      var catIndex = categories[j];
      var dataArray = dataSource.filterBy(categoryField,catIndex);
      var total = 0
         dataArray.forEach(function(val,key){
          total += val[seriesField];
         });
    }*/
    var allSeries = chart.options.series;
    var lastSeries = {};
    var fields = [];

    for (var i = 0; i < allSeries.length; i++) {
      var visible = allSeries[i].visible;

      // We're about to toggle the visibility of the clicked series
      if (i === toggledSeriesIndex) {
        visible = !visible;
      }

      if (visible) {
        fields.push("dataItem." + allSeries[i].field);
        lastSeries = allSeries[i];
      }

      // Clean-up existing labels
      allSeries[i].labels = {};
    }

    lastSeries.labels = {
      visible: true,
      template: "#=" + fields.join("+") + "#"
    };
  },

  createLabelItem(e) {
    let geom = kendo.geometry;
    let Rect = geom.Rect;
    let draw = kendo.drawing;
    let chartType = this.chartType.toUpperCase();

    let layoutConfig = (chartType === "BAR") ? {} : {
      alignContent: "center",
      alignItems: "center",
      justifyContent: "center",
      spacing: 10,
      lineSpacing: 0
    };

    if (chartType === "BAR") {
      e.rect.origin.x = e.rect.origin.x + 10;
      e.rect.origin.y = e.rect.origin.y + this.seriesShiftDistace + 2;
    }
    let rect = new Rect(e.rect.origin, e.rect.size);
    let layout = new draw.Layout(rect, layoutConfig);
    let lineWidth = (e.rect.size.width<150)?150:e.rect.size.width;
    let pathA = new draw.Path().moveTo(e.rect.origin.x, e.rect.origin.y).lineTo(e.rect.origin.x + 190, e.rect.origin.y + 0).stroke("#CCCCCC", 0.5).close();

    let kendoTxt = new draw.Text(this.trimText(e.text, 24), '', e.options).fill(e.options.color);

    let color = '#00eedd';
    let racColor = e.dataItem.get('ragColor') ? e.dataItem.get('ragColor') : color;
    //used to draw circle along with lables
    let circleGeometry = new geom.Circle(e.rect.origin, 5);
    let circle = new draw.Circle(circleGeometry).fill(racColor, 1).stroke("none", 0);

    if (chartType === "BAR") {
      layout.append(kendoTxt, pathA);
    } else if ((chartType === "COLUMN" || chartType === "LINE") && !this.chartConfig.hideRag) {
      layout.append(circle, kendoTxt);
    } else {
      return e.createVisual();
    }

    layout.reflow();
    return layout;
  },

  trimText(txt, len) {
    if (!txt) {
      txt = 'Unknown';
    } else if (txt.length > len) {
      txt = txt.substring(0, len) + "...";
    }
    //return txt.toUpperCase();
    return txt;
  },

  onAxisClick(actionName, event) {
    this.sendAction(actionName, event);
  },

  //this will be used when action name is different that the chartClickAction.
  onSeriesClick(actionName, event) {
    this.sendAction(actionName, event);
  },

  prepareDataSourceConfig(chartConfig, chartDataConfig) {
    if (!Ember.isEmpty(chartDataConfig)) {
      if (chartDataConfig.isGrouping && !Ember.isEmpty(chartDataConfig.groupField)) {
        chartConfig.dataSource.group = {
          field: chartDataConfig.groupField,
          dir: Ember.isEmpty(chartDataConfig.groupOrderBy) ? 'asc' : 'desc'
        };
      }
      if (!Ember.isEmpty(chartDataConfig.schema)) {
        chartConfig.dataSource.schema = chartDataConfig.schema;
      }
      if (!Ember.isEmpty(chartDataConfig.sort)) {
        chartConfig.dataSource.sort = chartDataConfig.sort;
      }
    }
  },

  setDataBoundForChart(event) {
    let view = event.sender.dataSource.view();
    this.dataLength = view.length;
    if (view.length === 0) {
      this.isChartEmpty = true;
      return;
    }

    let chart = event.sender;
    let chartSeries = chart.options.series;

    for (let i = 0; i < chartSeries.length; i++) {
      if (chartSeries[i] && !Ember.isEmpty(chartSeries[i].data)) {
        chartSeries[i].color = chartSeries[i].data[0].color;
      }
    }
  },

  setOnRenderHanlder(/*event*/) {
      let chartViewContainer;
       let overlayPanel;
      if (this.isChartEmpty) {
        chartViewContainer = Ember.$('#' + this.elementId + '-chart-view');
        let svgObj = chartViewContainer.find('svg');

        if (svgObj.length > 0) {
          this.set('isChartEmpty', false);

          let height = svgObj.css('height');
          let width = svgObj.css('width');

          //svgObj.remove();

          overlayPanel = chartViewContainer.parent().find('#' + this.elementId + '-no-data-overlay');
          overlayPanel.css({
            height: height,
            width: width
          });

          chartViewContainer.toggleClass('hide');
          overlayPanel.toggleClass('hide');
        }
      }else if(!this.isChartEmpty && this.dataLength!==0){
        chartViewContainer = Ember.$('#' + this.elementId + '-chart-view');
        overlayPanel = chartViewContainer.parent().find('#' + this.elementId + '-no-data-overlay');
        if(!Ember.isEmpty(chartViewContainer)){
          chartViewContainer.removeClass('hide');
        }
        if(!Ember.isEmpty(overlayPanel)){
          overlayPanel.addClass('hide');
        }
      }
  },

  willDestroyElement() {
    this._super.apply(this, arguments);

    let chartInstance = this.$('.chartview').data("kendoChart");

    if (chartInstance) {
      chartInstance.destroy();
      this.$(window).off('resize');
    }
  }
});
