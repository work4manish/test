import Ember from 'ember';

export default Ember.Service.extend({
  userProfileService: Ember.inject.service(),
  userAssignedRoles: Ember.computed.alias('userProfileService.userProfile.assignedRoles'),

  init: function() {
    this._super.apply(this, arguments);
    let userAssignedRoles = this.get('userAssignedRoles');
    let selectedRoleObj = Ember.A(userAssignedRoles).filterBy('roleName', 'Line Manager')[0];
    let selectedRole = selectedRoleObj ? selectedRoleObj : (userAssignedRoles ? userAssignedRoles[0] : '');
    localStorage.userCurrentRole = JSON.stringify(selectedRole);
  },

  setCurrentRole: function(role) {
    let userAssignedRoles = this.get('userAssignedRoles');
    let selectedRoleObj = Ember.A(userAssignedRoles).filterBy('roleId', role)[0];
    localStorage.userCurrentRole = JSON.stringify(selectedRoleObj);
  },

  getCurrentRole: function() {

    if(localStorage!==null && localStorage.userCurrentRole){
      return JSON.parse(localStorage.userCurrentRole);
    }

  },
  isLineManager() {
    let userCurrentRole = this.getCurrentRole();
    return ((!Ember.isEmpty(userCurrentRole) && !Ember.isEmpty(userCurrentRole.roleName) && userCurrentRole.roleName.toUpperCase() === 'LINE MANAGER') ? true : false);
  }
});
