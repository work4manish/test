import Model from 'ember-data/model';
import attr from 'ember-data/attr';
import { hasMany } from 'ember-data/relationships';

export default Model.extend({
  contextItems: hasMany('round-label-items', {async: false}),
  dashboardTypes: hasMany('tab-item', {async: false}),
  selectedDashboardType: attr('string'),
  selectedContext: attr('string'),
  selectedContextIcon: attr('string')
});
