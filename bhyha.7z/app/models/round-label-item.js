import Model from 'ember-data/model';
import attr from 'ember-data/attr';

export default Model.extend({
  acronym: attr('string'),
  text: attr('string'),
  iconClass: attr('string'),
  isSelected: attr('boolean', {default: false})
});
