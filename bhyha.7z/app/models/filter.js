import Model from 'ember-data/model';
import { hasMany } from 'ember-data/relationships';
import attr from 'ember-data/attr';

export default Model.extend({
  durationFilter: hasMany('durationFilter', {
    async: false
  }),
  regularFilter: hasMany('regularFilter', {
    async: false
  }),
  otherAttributeFilter: hasMany('regularFilter', {
    async: false
  }),
  title: attr('string')
});
