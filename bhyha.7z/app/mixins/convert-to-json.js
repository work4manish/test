import Ember from 'ember';

export default Ember.Mixin.create({
      convertToJSON (data) {
        var dataJSON = [];
        Ember.assert('Dtasource is expected to be Ember Array', (Ember.isArray(data)));
        if (data.constructor === Array && data.length > 0) {
            if (data[0].constructor === Object) {
                return data;
            }else {
                data.every(function (record) {
                    if (Ember.isArray(record)) {
                        record.every(function (eachSegment) {
                            dataJSON.push(eachSegment.toJSON({includeId: true}));
                        });
                    }else {
                        dataJSON.push(record.toJSON({includeId: true}));
                    }
                    return true;
                });
            }
        }else {
            data.every(function (record) {
                if (Ember.isArray(record)) {
                    record.every(function (eachSegment) {
                        dataJSON.push(eachSegment.toJSON({includeId: true}));
                    });
                }else {
                    dataJSON.push(record.toJSON({includeId: true}));
                }
                return true;
            });
        }
        return Ember.A(dataJSON);
    },
});
