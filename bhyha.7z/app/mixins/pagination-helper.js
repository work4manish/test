import Ember from 'ember';

export default Ember.Mixin.create({

  handleServerPagination() {
    if (this.serverPaging) {
      this.updateDefaultPageableObject();
      this.addDataSourceChangeEvent();
    }
  },

  handleServerPaginationElements() {
    if (this.serverPaging) {
      this.initializePagerComponentState();
      this.addEventHandlers();
    }
  },

  initializePagerComponentState() {
    this.pageSizeCombo = Ember.$('#' + this.gridId +' .k-dropdown select');
  },

  updateDefaultPageableObject() {
    let _this = this;

    this.defaultPageable.change = function(event) {
      _this.loadNewDataSet(event.index);
    };
  },

  loadNewDataSet(pageNumber) {
    this.refreshGrid(false, pageNumber);
  },

  addDataSourceChangeEvent() {
    let _this = this;

    this.gridConfig.dataSource.change = function( /*event*/ ) {
      if (_this.get('data')) {
        this._total = _this.get('totalRecords');
      }
    };
  },

  addEventHandlers() {
    this.pageSizeCombo.on('change', this.onPageSizeChange.bind(this));
  },

  onPageSizeChange() {
    this.set('pageSize', parseInt(this.pageSizeCombo.val()));
    this.loadNewDataSet(1);
  }
});
