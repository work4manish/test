import ApplicationAdapter from './application';

export default ApplicationAdapter.extend({
  buildURL: function(modelName, id, snapshot, requestType, query) {
    let contextPath = query.dashboardName + '/topbarsecondary';
    return this._buildURL(contextPath);
  }
});
