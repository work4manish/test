import ApplicationAdapter from './application';

export default ApplicationAdapter.extend({
  buildURL(modelName, id, snapshot, requestType, query) {
    let screenName = query.screenName;

    if (screenName) {
      let contextPath = '';

      if (screenName === 'searchDetailView') {
        contextPath = 'searchview/retrievetopbarinfo';
      } else if (screenName === 'searchFilterMenu') {
        contextPath = 'searchview/retrievesearchfilters';
      }

      return this._buildURL(contextPath);
    }

    return this._super(modelName, id, snapshot, requestType, query);
  }
});
