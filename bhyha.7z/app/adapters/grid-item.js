import Ember from 'ember';
import ApplicationAdapter from './application';

export default ApplicationAdapter.extend({
  buildURL: function(modelName, id, snapshot, requestType, query) {
    let gridId = '';
    let contextPath = '';
    let viewType = '';
    let screenName = query.screenName;

    if (query.gridId) {
      gridId = query.gridId;
    }

    if (screenName) {
      if (screenName.toUpperCase() === "DETAILSCREEN") {
        viewType = gridId.split('_')[0];
        viewType = viewType.replace(/([~!@#$%^&*()_+=`{}\[\]\|\\:;'<>,.\/? ])+/g, '').toLowerCase();
        contextPath = viewType + '/gridview';
      } else if (screenName === 'searchDetailView') {

        contextPath = 'searchview/retrievegriddata';

      } else {
        Ember.logger.error('Please add a check for screenName : ' + screenName);
      }

      //delete query.screenName;  //dont remove this
      delete query.gridItemId;

      return this._buildURL(contextPath);
    }

    return this._super(modelName, id, snapshot, requestType, query);
  }
});
