import Ember from 'ember';
import DS from 'ember-data';

export default DS.RESTSerializer.extend(DS.EmbeddedRecordsMixin, {
  attrs: {
    chartConfig: {
      embedded: 'always'
    },
    filter: {
      embedded: 'always'
    },
    chartData: {
      embedded: 'always'
    }
  },

  normalizeResponse(store, primaryModelClass, payload, id, requestType) {
    payload.chartView.chartData.chartSeries = this.prepareChartSeries(payload.chartView.chartData.chartSeries);
    payload.chartView.id = 'chartView-'+new Date().getTime();
    payload.chartView.chartData.id = 'chartData-'+new Date().getTime();

    if (payload.chartView.chartData.hasOwnProperty('chartTitle') && Ember.isEmpty(payload.chartView.chartData.chartTitle)) {
      delete payload.chartView.chartData.chartTitle;
    }

    if (payload.chartView.chartConfig) {
      payload.chartView.chartConfig.id = 'chartConfig-' + new Date().getTime();
    }

    return this._super(store, primaryModelClass, payload, id, requestType);
  },

  prepareChartSeries(chartData) {
    var newChartSeries = [];

    if (chartData) {
      var seriesCount = chartData.length;
      chartData.forEach(function(items /*, key*/ ) {
        items.dataItems.forEach(function(item /*, key*/ ) {
          item.name = items.name;
          item.id = 'seriesId-'+new Date().getTime()+ Math.random()*100000;
          if(items.hasOwnProperty('ragColor')){
              item.ragColor = items.ragColor;
          }
          if(items.hasOwnProperty('color')){
              item.color = items.color;
          }
          if(items.hasOwnProperty('attributeId')){
              item.attributeId = items.attributeId;
          }

          item.seriesCount = seriesCount;
          newChartSeries.push(item);
        });
      });
    }

    return newChartSeries;
  }
});
