import DS from 'ember-data';

export default DS.RESTSerializer.extend({
  normalizeResponse(store, primaryModelClass, payload, id, requestType) {
    let newResponse = payload;

    if (this.shouldSerialize(payload)) {
      newResponse = this.normalizePayloadForBase(payload);
    }

    return this._super(store, primaryModelClass, newResponse, newResponse.base.id, requestType);
  },

  shouldSerialize(payload) {
    for (let key in payload) {
      if (payload.hasOwnProperty(key) && key !== 'title' && key !== 'info') {
        return true;
      }
    }

    return false;
  },

  normalizePayloadForBase(payload) {
    let newResponse = {
      base : {
        id: String(new Date().getTime()),
        info: payload.info ? payload.info : {}
      }
    };

    for (let key in payload) {
      if (payload.hasOwnProperty(key)) {
        if (payload !== 'title') {
          newResponse.base.info[key] = payload[key];
        }
      }
    }

    return newResponse;
  }
});
