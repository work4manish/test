import Ember from 'ember';
import AuthenticatedRoute from 'supdash-ui-core/routes/authenticated-route';
import RouteProgressIndicator from 'supdash-ui-core/mixins/route-progress-indicator';
import NumberUtil from '../../utils/number-util';
const {getOwner} = Ember;

export default AuthenticatedRoute.extend(RouteProgressIndicator, {
  hideSecondaryNav: true,
  hideSecondaryTopBar: true,
  showModuleTitle: true,
  coreDataService: Ember.inject.service(),

  actions: {
    onKeyupSearchText(searchString/*, selectedSearchCriteria*/) {
      let isNumericValue = NumberUtil.isNumber(searchString);

      if (searchString && !this.isSearchInProgress &&
          ((!isNumericValue && searchString.length >= 3) || (isNumericValue && searchString.length >= 7))) {

        this.isSearchInProgress = true;

        this.get('coreDataService').queryRecord('list-view-item', {
          searchParm: searchString,
          screenName: 'searchView',
          /*selectedSearchCriteria: selectedSearchCriteria*/
        }).then((searchListViewItem) => {

          this.isSearchInProgress = false;

          if (!this.controller.get('listViewConfig', searchListViewItem.get('listConfig'))) {
            this.controller.set('listViewConfig', null);
          }

          this.controller.set('searchResults', searchListViewItem.get('listData').data);
        }).catch((reason) => {
          console.log(reason);
        });
      } else if (searchString.length === 0 && this.controller.get('searchResults') &&
        this.controller.get('searchResults').length > 0) {
        this.controller.set('searchResults', []);
      }
    },

    onRowClick(rowId) {
      Ember.$('.base-search-box').val(this.getValueFor('name', rowId));

      this.transitionTo('home.search.detail', rowId, {
        queryParams: {
          appTitle: 'Back'
        }
      });
    }
  },

  beforeModel() {
    getOwner(this).lookup('controller:top-bar').setSearchActive(true);
  },

  deactivate() {
    getOwner(this).lookup('controller:top-bar').setSearchActive(false);
  },

  setupController(controller/*,  model*/) {
    controller.setProperties({
      listViewConfig: null,
      searchResults: []
    });
  },

  getValueFor(key, value) {
    let searchResults = this.controller.get('searchResults');

    for (let i = 0, len = searchResults.length; i < len; i++) {
      let searchItem = searchResults[i];

      if (String(searchItem['id']) === String(value)) {
        return searchItem[key];
      }
    }

    return '';
  }
});
