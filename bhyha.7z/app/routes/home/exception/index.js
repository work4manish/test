import Ember from 'ember';
import AuthenticatedRoute from 'supdash-ui-core/routes/authenticated-route';
import RouteProgressIndicator from 'supdash-ui-core/mixins/route-progress-indicator';
import convertToJSON from '../../../mixins/convert-to-json';

export default AuthenticatedRoute.extend(RouteProgressIndicator, convertToJSON, {
  hideSecondaryNav: true,
  userCurrentRoleService: Ember.inject.service(),

  model( /*params*/ ) {
    let userCurrentRole = this.get('userCurrentRoleService').getCurrentRole();

    return this.store.queryRecord('filter', {
      roleId: userCurrentRole.roleId,
      filterId: 1
    });
  },

  afterModel() {
    let owner = Ember.getOwner(this);
    let topBarSecondaryController = owner.lookup('controller:sup-top-bar-secondary');
    topBarSecondaryController.toggleSecondaryTopBarTabs('index');
  },

  setupController(controller, model) {
    this._super(controller, model);
    this.setDurationFilter(controller, model);
    this.defaultControllerSetting(controller);
  },

  defaultControllerSetting(controller) {
    let isLineManager = this.get('userCurrentRoleService').isLineManager();
    let userCurrentRole = this.get('userCurrentRoleService').getCurrentRole();
    controller.setProperties({
      viewDashConfig: this.createServiceParams('Dashboard', isLineManager, userCurrentRole),
      viewEmpConfig: this.createServiceParams('Employee', isLineManager, userCurrentRole),
      viewSummaryConfig: this.createServiceParams('Summary', isLineManager, userCurrentRole, 'dashboardName'),
      modelNameForModule: 'chartView'
    });
  },

  setDurationFilter(controller, model) {
    let title = model.get('title');
    let data = model.get('durationFilter');

    if (!Ember.isEmpty(data)) {
      let filterItems = this.convertToJSON(data);
      let selectedObject = filterItems.filterBy('selected', true)[0];

      if (!Ember.isEmpty(filterItems) && filterItems.length > 0) {
        controller.setProperties({
          title: title,
          durationFilter: true,
          filterItems: filterItems,
          selected: selectedObject.id,
        });
      }
    }
  },

  createServiceParams(cahrtType, isLM, role, dashboardName) {
    let chartIdPrefix = isLM ? 'LM_' : 'RB_';
    let chartId = chartIdPrefix + 'View_By_' + cahrtType;
    let roleId = !Ember.isEmpty(role) ? role.roleId : '';
    let serviceParams = Ember.Object.create({
      chartId: chartId,
      durationFilter: '',
      includeIndirectReports: true,
      roleId: roleId
    });

    if (!Ember.isEmpty(dashboardName)) {
      serviceParams.set('dashboardName', 'MissedTrades');
    }

    return serviceParams;
  },

  refreshChart(dashboard, employee, summary) {
    this.controller.setProperties({
      refreshDashboard: dashboard,
      refreshEmployee: employee,
      refreshSummary: summary,
    });
  },

  refreshing(attr) {
    this.controller.set(attr, false);
    Ember.run.next(() => {
      this.controller.set(attr, true);
    });
  },

  actions: {

    chartClickAction(data) {
      let includeIndirectReports = this.controller.get('viewDashConfig').includeIndirectReports;
      let durationFilter = this.controller.get('viewDashConfig').durationFilter;

      let dashboard;
      if (data.dataItem.seriesCode) {
        dashboard = data.dataItem.seriesCode;
      } else {
        dashboard = data.category ? data.category.replace(/([~!@#$%^&*()_+=`{}\[\]\|\\:;'<>,.\/? ])+/g, '').toLowerCase() : 'notFound';
      }

      this.transitionTo('home.exception.detail', dashboard, {
        queryParams: {
          appTitle: data.category,
          includeIndirectReports: includeIndirectReports,
          durationFilter: durationFilter
        }
      });
    },

    resetRefreshFlagToFalse() {
      this.refreshChart(false, false, false);
    },

    assignedRoleForUser() {
      this.defaultControllerSetting(this.controller);
      this.refreshChart(true, true, true);
    },

    selectAllDirectsReport(state) {
      this.controller.get('viewDashConfig').includeIndirectReports = state;
      this.controller.get('viewEmpConfig').includeIndirectReports = state;
      this.controller.get('viewSummaryConfig').includeIndirectReports = state;
      this.refreshChart(true, true, true);

    },

    onTabChange(val) {
      this.controller.get('viewDashConfig').durationFilter = val;
      this.controller.get('viewEmpConfig').durationFilter = val;
      this.refreshChart(true, true, false);

    }
  }
});
