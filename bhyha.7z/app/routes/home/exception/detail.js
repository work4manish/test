import Ember from 'ember';
import AuthenticatedRoute from 'supdash-ui-core/routes/authenticated-route';
import RouteProgressIndicator from 'supdash-ui-core/mixins/route-progress-indicator';
import convertToJSON from '../../../mixins/convert-to-json';

const { getOwner } = Ember;

export default AuthenticatedRoute.extend(RouteProgressIndicator, convertToJSON, {
  hideSecondaryNav: true,
  showModuleTitle: true,
  userCurrentRoleService: Ember.inject.service(),

  beforeModel: function(transition){
    if(!Ember.isEmpty(transition.queryParams)){
      this.durationFilter = transition.queryParams.durationFilter;
      this.includeIndirectReports = transition.queryParams.includeIndirectReports;
    }

  },

  model(params) {
    let userCurrentRole = this.get('userCurrentRoleService').getCurrentRole();
    params.roleId = userCurrentRole.roleId;
    params.filterId = 5;

    let ravpromise = Ember.RSVP.hash({
      otherAttributeFilterModel: this.store.queryRecord('filter', params),
      dashboard: params.dashboard
    });

    return ravpromise;
  },

  setupController(controller, model) {
    this.sendActionToSecController(model.otherAttributeFilterModel);
    this.defaultControllerSetting(controller, model);
  },

  defaultControllerSetting(controller, model) {
    let userCurrentRole = this.get('userCurrentRoleService').getCurrentRole();
    let moduleName = model.dashboard;
    let otherAttributeModel = model.otherAttributeFilterModel;

    let pageFilter = 'SourceSystem';
    let chartId = moduleName + '_DetailView_By_' + pageFilter;
    let gridId = moduleName + '_Linamanager_Grid';
    let otherAttributeFilter = otherAttributeModel.get('otherAttributeFilter').filterBy('selected', true)[0];
    let otherAttributeFilterSelectedId = otherAttributeFilter ? otherAttributeFilter.id : '';

    controller.setProperties({
      detailParmasForChart: this.createServiceParams(pageFilter, chartId, userCurrentRole, otherAttributeFilterSelectedId, true),
      detailParmasForGrid: this.createServiceParams(pageFilter, gridId, userCurrentRole, otherAttributeFilterSelectedId, false),
      gridItemId: gridId,
      modelNameForModule: 'chartView'
    });
  },

  createServiceParams(pageFilter, id, role, otherAttr, isChart) {
    let roleId = !Ember.isEmpty(role) ? role.roleId : '';
    let serviceParams = {
      pageFilter: pageFilter,
      durationFilter: this.durationFilter,
      includeIndirectReports: this.includeIndirectReports,
      otherAttributeFilter: otherAttr,
      roleId: roleId,
      isLineManager: this.get('userCurrentRoleService').isLineManager(),
      screenName: 'detailScreen'
    };

    if (isChart) {
      serviceParams.chartId = id;
    } else {
      serviceParams.gridId = id;
    }

    return serviceParams;
  },

  sendActionToSecController(model) {
    let owner = getOwner(this);
    let topBarSecondaryController = owner.lookup('controller:sup-top-bar-secondary');
    topBarSecondaryController.updateTopBarSecondary(model);
  },

  refreshing(attr) {
    this.controller.set(attr, false);
    Ember.run.next(() => {
      this.controller.set(attr, true);
    });
  },

  setAttr(attr, val) {
    this.controller.get('detailParmasForChart')[attr] = val;
    this.controller.get('detailParmasForGrid')[attr] = val;
    this.refreshAll(true, true);
  },

  refreshAll(chart, grid) {
    let gridParams = this.controller.get('detailParmasForGrid')
    if(!grid && gridParams.hasOwnProperty('userId')){
      delete gridParams.userId;
    }

    this.controller.setProperties({
      refreshChart: chart,
      refreshGrid: grid,
    });
  },
  updateOtherFilterTabs(role) {
    this.store.queryRecord('filter', {
      roleId: role,
      filterId: 5
    }).then((response) => {
      let otherFilterItems = this.convertToJSON(response.get('otherAttributeFilter'));
      let selectedObject = otherFilterItems.filterBy('selected', true)[0];
      let otherAttributeFilter = (!Ember.isEmpty(selectedObject)) ? selectedObject.id : '';
      this.setAttr('roleId', role);
      this.setAttr('isLineManager', this.get('userCurrentRoleService').isLineManager());
      this.setAttr('otherAttributeFilter', otherAttributeFilter);
      this.refreshAll(true, true);
      this.sendActionToSecController(response);

    });

  },
  actions: {
    assignedRoleForUser(role) {
      this.updateOtherFilterTabs(role);
    },

    resetRefreshFlagToFalse() {
      this.refreshAll(false, false);
    },

    changedOtherAttribute(otherAttributeFilter) {
      this.setAttr('otherAttributeFilter', otherAttributeFilter);
    },

    selectAllDirectsReport(state) {
      this.setAttr('includeIndirectReports', state);
    },

    refreshOnDurationFilterChange(durationFilter) {
      this.setAttr('durationFilter', durationFilter);
    },
    detailSreenChartClick(event){
      let userId = event.dataItem.attributeId;
      this.controller.get('detailParmasForGrid').userId = userId;
      this.refreshAll(false, true);
    }
  }
});
