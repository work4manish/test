import Ember from 'ember';

export default Ember.Route.extend({
  hideSecondaryNav: true,
  // setupController(controller, model) {

  // },

  // renderTemplate() {
  //   this.render('sup-secondary-nav', {
  //     outlet: 'secondary-nav',
  //     into: 'application'
  //   });

  //   this.render();
  // }
});
