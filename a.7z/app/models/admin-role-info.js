import Model from 'ember-data/model';
import attr from 'ember-data/attr';
import {
  belongsTo,
  hasMany
} from 'ember-data/relationships';


export default Model.extend({
  bfsHierarchyLevel2: hasMany('businessFunction', {
    async: false
  }),
  bfsHierarchyLevel3: hasMany('businessFunction', {
    async: false
  }),
  bfsHierarchyLevel4: hasMany('businessFunction', {
    async: false
  }),
  bfsHierarchyLevel6: hasMany('businessFunction', {
    async: false
  }),
  availableCountries: hasMany('country', {
    async: false
  }),
  roleConfiguration: belongsTo('adminRoleConfiguration', {
    async: false
  }),
  bankIds: attr('array')
});
