import DS from 'ember-data';

export default DS.Model.extend({
  chartTitle : DS.belongsTo("chartTitle"),
  chartSeries : DS.hasMany("chartSeries"),
  categoryCount: DS.attr('number')
});
