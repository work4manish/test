//import Model from 'ember-data/model';
import SelectableItem from './selectable-item';
//import attr from 'ember-data/attr';

export default SelectableItem.extend({

});
