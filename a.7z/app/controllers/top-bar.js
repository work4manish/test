import Ember from 'ember';
import Base from 'supdash-ui-base/controllers/top-bar';
import AdminLabel from '../utils/admin-label-const';

export default Base.extend({
  routing: Ember.inject.service('-routing'),
  coreTransition: Ember.inject.service(),
  backActionPerformed: false,

  init() {
    this._super();
  },

  actions: {
    toggleView(className) {
      if (className === 'mdi-arrow-left') {
        this.goBack();
      }
    },

    onFocusSearchField( /*searchField*/ ) {
      this.showSearchPage('');
    },

    onFocusOutSearchField() {},

    onSearchStringChange(searchField) {
      let searchString = searchField.value;

      if (this.isSearchActive) {
        this.send('onKeyupSearchText', searchString);
      }
    },

    onSearchCriteriaChange(currentMenuItem, searchCriteriaComponent) {
      if (currentMenuItem.type === 'duration' && currentMenuItem.title === 'Custom') {
        if (currentMenuItem.isChecked) {
          Ember.getOwner(this).lookup('route:home.search').showDatePickerDialog(searchCriteriaComponent, currentMenuItem);
        }
      } else {
        searchCriteriaComponent.updateTopBarSearchCriteria();
      }
    }
  },

  showSearchPage( /*searchString*/ ) {
    this.transitionToRoute('home.search', {
      queryParams: {
        appTitle: 'Back'
      }
    });
  },

  goBack() {
    history.back();
    this.set('backActionPerformed', true);
    /*
    let previousRoute = this.get('coreTransition').getPreviousRoute();
    let queryParams = previousRoute.queryParams;//Object.keys(previousTranstion.queryParams).length
    //let appRoute = Ember.getOwner(this).lookup('route:application');

    if (Object.keys(queryParams).length) {
      this.transitionToRoute(previousRoute.routeName, {
        queryParams: queryParams
      });
    } else {
      this.transitionToRoute(previousRoute.routeName);
    }
    */
    Ember.run.next(() => {
      this.set('backActionPerformed', false);
    });
  },

  setSearchActive(isActive) {
    let searchActiveClass = 'search-not-active';

    if (isActive) {
      searchActiveClass = 'search-active';
    } else {
      Ember.$('.base-search-box').val('');
    }

    this.set('topBarClass', searchActiveClass);
    this.set('isSearchActive', isActive);
  },

  setAdminTopBar(adminDashboard, baseAppTitleString) {
    let adminTopBarClass = 'admin-top-bar';
    let topBarNavClass = 'admin-home';
    let baseAppTitle = baseAppTitleString ? baseAppTitleString : AdminLabel.baseAppTitle;
    let appName = AdminLabel.dashboardAppTitle;

    this.set('topBarClass', adminTopBarClass);
    this.set('hideSearchBarPanel', true);

    if (adminDashboard) {
      Ember.run.next(() => {
        this.set('topBarNavIcon', topBarNavClass);
        this.set('baseAppTitle', baseAppTitle);
        this.set('appName', appName);
      });
    } else {
      this.set('appName', '');
    }

  }

});
