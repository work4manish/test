import ApplicationAdapter from './application';

export default ApplicationAdapter.extend({
  buildURL: function(modelName, id, snapshot, requestType, query) {
    let chartId = '';
    let contextPath = '';
    let viewType = '';
    let roleType = '';

    if (query.hasOwnProperty('chartId')) {
      chartId = query.chartId;
    }

    if (query.hasOwnProperty('screenName') && query.screenName.toUpperCase() === "DETAILSCREEN") {
      viewType = chartId.split('_')[0];
      viewType = viewType.replace(/([~!@#$%^&*()_+=`{}\[\]\|\\:;'<>,.\/? ])+/g, '').toLowerCase();

      if (query.hasOwnProperty('isLineManager')) {
        roleType = query.isLineManager ? '' : 'rb';
      }
      contextPath = viewType + '/' + roleType + 'chartview';

    } else if (query.screenName === 'searchDetailView') {

      contextPath = 'searchview/retrievechartdata';

    } else {
      viewType = chartId.substring(0, 2);
      chartId = chartId.substring(3, chartId.length);
      chartId = chartId.replace(/([~!@#$%^&*()_+=`{}\[\]\|\\:;'<>,.\/? ])+/g, '').toLowerCase();
      viewType = (viewType === 'LM') ? 'linemanagerview' : 'rolebasedview';
      contextPath = viewType + '/' + chartId;
    }

    return this._buildURL(contextPath);
  }
});
