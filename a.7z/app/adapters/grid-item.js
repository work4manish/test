import Ember from 'ember';
import ApplicationAdapter from './application';
import AppConst from '../utils/app-const';

export default ApplicationAdapter.extend({
  buildURL: function(modelName, id, snapshot, requestType, query) {
    let contextPath = '';
    let screenName = query.screenName;

    if (screenName) {
      if (screenName.toUpperCase() === "DETAILSCREEN") {

        contextPath = this.getContextPathForDetail(query);

      } else if (screenName === 'detailScreenDialogBox') {

        contextPath = this.getContextPathForDetail(query, true);

      } else if (screenName === 'searchDetailView') {

        contextPath = 'searchview/retrievegriddata';
      } else if (screenName === 'exceptionViewByDashboard') {
        let url = 'linemanagerview';

        if (query.roleName !== AppConst.LINE_MANAGER) {
          url = 'rolebasedview';
        }

        contextPath = url + '/viewbydashboard';

      } else if (screenName.toUpperCase() === 'ADMINUSERSPROFILE') {

        contextPath = 'useradmin/userslist';
      } else if (screenName === 'dashboardViewUserList') {

        contextPath = 'bsupport/userlist';

      } else {
        Ember.Logger.error('Please add a check for screenName : ' + screenName);
      }

      //delete query.screenName;  //dont remove this
      delete query.gridItemId;

      return this._buildURL(contextPath);
    }

    return this._super(modelName, id, snapshot, requestType, query);
  },

  getContextPathForDetail(query, isDetailDialog) {
    let gridId;

    if (query.gridId) {
      gridId = query.gridId;
    }

    let viewType = gridId.split('_')[0];
    viewType = viewType.replace(/([~!@#$%^&*()_+=`{}\[\]\|\\:;'<>,.\/? ])+/g, '').toLowerCase();

    let roleType = query.isLineManager ? '' : 'rb';
    let contextPath = viewType + '/' + roleType + 'gridview' + (isDetailDialog ? 'detail' : '');

    return contextPath;
  }
});
