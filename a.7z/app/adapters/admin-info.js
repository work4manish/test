import AdminBaseAdapter from './admin-base';

export default AdminBaseAdapter.extend({
  buildURL(modelName, id, snapshot, requestType, query) {
    let contextPath = 'edituserrole/'+query.userId+ '/'+query.roleId;
    delete query.userId;
    delete query.roleId;

    return this._buildURL(contextPath);
  }

});

