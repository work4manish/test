import AdminBaseAdapter from './admin-base';

export default AdminBaseAdapter.extend({

  buildURL(modelName, id, snapshot, requestType, query) {
    let contextPath = 'roleinfo/'+ query.roleId;
    delete query.roleId;
    return this._buildURL(contextPath);
  }
});
