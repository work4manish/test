import AdminBaseAdapter from './admin-base';

export default AdminBaseAdapter.extend({
  pathForType() {
    return 'roles';
  }
});
