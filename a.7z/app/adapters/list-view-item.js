import Ember from 'ember';
import ApplicationAdapter from './application';

export default ApplicationAdapter.extend({
  buildURL(modelName, id, snapshot, requestType, query) {
    let contextPath = '';
    let screenName = query.screenName;

    if (screenName) {
      if (screenName === 'searchView') {
        contextPath = 'searchview/retrievesearchresults';
      } else {
        Ember.logger.error('Please add a check for screenName : ' + screenName);
      }

      return this._buildURL(contextPath);
    }

    return this._super(modelName, id, snapshot, requestType, query);
  }
});
