import AdminBaseAdapter from './admin-base';

export default AdminBaseAdapter.extend({
  buildURL(modelName, id, snapshot/*, requestType, query*/) {
    let contextPath = snapshot.record.get('actionType').toLowerCase();
    return this._buildURL(contextPath);
  }

});
