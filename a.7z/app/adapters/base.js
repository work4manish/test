import ApplicationAdapter from './application';
import AppConst from '../utils/app-const';

export default ApplicationAdapter.extend({
  buildURL(modelName, id, snapshot, requestType, query) {
    let screenName = query.screenName;

    if (screenName) {
      let contextPath = '';

      if (screenName === 'searchDetailView') {
        contextPath = 'searchview/retrievetopbarinfo';
      } else if (screenName === 'searchFilterMenu') {
        contextPath = 'searchview/retrievesearchfilters';
      } else if (screenName === 'roleInfoPopup') {
        contextPath = 'rolebasedview/retrieveroleinformation';
      } else if (screenName === 'secondaryMenu') {
        contextPath = 'linemanagerview/dashboards';
      } else if (screenName === 'psidLookUpForAminUserPopup') {
        contextPath = 'useradmin/userlookup/' + query.userId;
        delete query.userId;
      } else if (screenName === 'generalDashboard') {
        contextPath = this.getGeneralContextPath(query);
      } else if (screenName === 'generalDashboardDetailGrid') {
        contextPath = this.getGeneralContextPath(query, true);
      } else if (screenName === 'adminPSIDSearchResult') {
        contextPath = 'useradmin/userinfo';
      } else if (screenName === 'adminUserReporteesGrid') {
        contextPath ='useradmin/userreportees';
      } else if (screenName === 'adminUserProfileHierarchy') {
        contextPath = 'useradmin/bfshierarchy/' + query.level + '/' + query.roleId;
        delete query.level;
        delete query.roleId;
      } else if (screenName === 'adminUserProfileActivateDeActivate') {
        contextPath = 'useradmin/' + query.url + '/' + query.userId + '/' + query.roleId;
        delete query.url;
        delete query.userId;
        delete query.roleId;
      }

      return this._buildURL(contextPath);
    }

    return this._super(modelName, id, snapshot, requestType, query);
  },

  getGeneralContextPath(query, isDetailGrid) {
    let roleName = query.roleName;
    let path = query.dashboardId.toLowerCase();
    let contextPath = path + '/' + (roleName === AppConst.LINE_MANAGER ? '' : 'rb') + 'gridview' + (isDetailGrid ? 'detail' : '');

    return contextPath;
  }
});
