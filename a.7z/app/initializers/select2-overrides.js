import Select2Overrides from '../utils/select2-override-util';
// import Ember from 'ember';

export function initialize(container, application) {
    application.register('Select2Overrides:main', Select2Overrides, {singleton: true, instantiate: false});
}

export default {
    name: 'select2-overrides',
    initialize: initialize
};
