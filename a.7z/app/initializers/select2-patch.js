import Select2 from 'ember-select-2/components/select-2';
import Ember from 'ember';
export function initialize() {
    // Select2.reopen({
    //     selectionChanged(data) {
    //         if (data == null) {
    //             this.set("value", data);
    //             Ember.run.schedule('actions', this, function () {
    //                 this.sendAction('didSelect', data, this);
    //             });
    //         } else {
    //             this._super.apply(this, arguments);
    //         }
    //     }
    // });
}

export default {
    name: 'select-2-patch',
    initialize: initialize
};
