import Ember from 'ember';
import AppConst from '../utils/app-const';

export default Ember.Service.extend({
  userProfileService: Ember.inject.service(),
  userAssignedRoles: Ember.computed.alias('userProfileService.userProfile.assignedRoles'),

  init: function() {
    this._super.apply(this, arguments);
    let userAssignedRoles = this.get('userAssignedRoles');
    let selectedRoleObj = Ember.A(userAssignedRoles).findBy('roleName', AppConst.LINE_MANAGER);
    let selectedRole = selectedRoleObj ? selectedRoleObj : (userAssignedRoles ? userAssignedRoles[0] : '');
    localStorage.userCurrentRole = JSON.stringify(selectedRole);
  },

  setCurrentRole: function(role) {
    let userAssignedRoles = this.get('userAssignedRoles');
    let selectedRoleObj = Ember.A(userAssignedRoles).findBy('roleId', role);
    localStorage.userCurrentRole = JSON.stringify(selectedRoleObj);
  },

  getCurrentRole: function() {

    if(localStorage!==null && localStorage.userCurrentRole){
      return JSON.parse(localStorage.userCurrentRole);
    }

  },
  isLineManager() {
    let userCurrentRole = this.getCurrentRole();
    return ((!Ember.isEmpty(userCurrentRole) && !Ember.isEmpty(userCurrentRole.roleName) && userCurrentRole.roleName.toUpperCase() === AppConst.LINE_MANAGER.toUpperCase()) ? true : false);
  }
});
