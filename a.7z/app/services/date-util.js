import Ember from 'ember';

export default Ember.Service.extend({
  preference: Ember.inject.service('corePreference'),

  getDateFormat() {
    return this.get('preference').getDateFormat();
  },

  getMomentDateFormat() {
    return this.get('preference').getMomentDateFormat();
  },

  getDateObject(dateString) {
    let format = this.getMomentDateFormat();
    let dateObject = moment(dateString, format);

    return dateObject;
  }
});
