export default {
  LINE_MANAGER: 'Line Manager',
  LABEL_BUSINESS_SUPPORT: 'Business Support',
  LABEL_DASHBOARD_VIEW: 'Dashboard View',
  LABEL_MFU: 'Manual File Upload',

  KEY_CODE: {
    ENTER: 13
  },
  STATE: {
    PROGRESS: 'Progress',
    FINISHED: 'Finished'
  }
};
