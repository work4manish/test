export default {
  FONT_FAMILY: 'Roboto-Regular',
  FONT_XS: '11px',
  DISABLED_COLOR: '#CDCDCD',
  LABELS_COLOR: '#4A4A4A',
  VALUE_AXIS_COLOR: '#A6A6A6',
  WHITE_COLOR: '#FFFFFF'
};
