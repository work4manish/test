import Ember from "ember";

export default Ember.Object.create({
  /**
   * init
   * @override
   */
  init() {
    this.customizeForMultiSelect();
  },
  customizeForMultiSelect() {
    /* jshint ignore:start */
    Select2.class.multi.prototype.findHighlightableChoices = function() {
      return this.results.find(".select2-result-selectable:not(.select2-disabled)");
    };

    var Select2TriggerSelect = Select2.class.multi.prototype.triggerSelect;

    Select2.class.multi.prototype.triggerSelect = function(data) {
      if (this.val().indexOf(this.id(data)) !== -1) {

        var val = this.id(data);
        var evt = $.Event("select2-removing");
        evt.val = val;
        evt.choice = data;
        this.opts.element.trigger(evt);

        if (evt.isDefaultPrevented()) {
          return false;
        }

        var existingVals = this.val();
        var self = this;
        if (!existingVals || existingVals.length == 0) return true;
        for (let a = 0; a < existingVals.length; a++) {
          if (existingVals[a] === val) {
            existingVals[a] = '';
            this.val(existingVals);
            this.results.find('.select2-result').each(function() {
              var $this = $(this);
              if (self.id($this.data('select2-data')) === val) {
                $this.removeClass('select2-selected');
              }
            });
          }
        }

        this.opts.element.trigger({
          type: "select2-removed",
          val: this.id(data),
          choice: data
        });
        this.triggerChange({
          removed: data
        });

      } else {
        return Select2TriggerSelect.apply(this, arguments);
      }
    }
    /**
     * createContainer for multiSelect.
     * @override
     */
    Select2.class.multi.prototype.createContainer = function() {
      var container = Ember.$(document.createElement("div")).attr({
        "class": "select2-container select2-container-multi"
      }).html([
        "<ul class='select2-choices'>",
        "  <li class='select2-search-field'>",
        "    <label for='' class='select2-offscreen'></label>",
        "    <input type='text' autocomplete='off' autocorrect='off' autocapitalize='off' spellcheck='false' class='select2-input'>",
        "  </li>",
        "</ul>",
        "       <div class='dropdown select2-search-more pull-right hidden'>",
        "           <a href='javascript:;' class='multi-select-more-option dropdown-toggle' type='button' data-toggle='dropdown' aria-haspopup='true' aria-expanded='true'>",
        "           </a>",
        "           <ul class='dropdown-menu'></ul>",
        "       </div>",
        "<div class='select2-drop select2-drop-multi select2-display-none'>",
        "   <ul class='select2-results'>",
        "   </ul>",
        "</div>"
      ].join(""));
      return container;
    };
   /**
     * addSelectedChoice for multiSelect.
     * @override
     */
    Select2.class.multi.prototype.addSelectedChoice = function(data) {
      function killEvent(event) {
        event.preventDefault();
        event.stopPropagation();
      }
      var enableChoice = !data.locked,
        enabledItem = Ember.$(
          "<li class='select2-search-choice'>" +
          "    <div></div>" +
          "    <a href='javascript:void();' class='select2-search-choice-close' tabindex='-1'></a>" +
          "</li>"),
        disabledItem = Ember.$(
          "<li class='select2-search-choice select2-locked'>" +
          "<div></div>" +
          "</li>"),
        choice = enableChoice ? enabledItem : disabledItem,
        id = this.id(data),
        val = this.getVal(),
        formatted,
        cssClass,
        moreChoice,
        moreContainer = this.container.find('.select2-search-more'),
        choices,
        dropMenu = moreContainer.find('.dropdown-menu'),
        choicesContainer = this.container.find('.select2-choices'),
        choicesWidth = 0;

      formatted = this.opts.formatSelection(data, choice.find("div"), this.opts.escapeMarkup);
      if (formatted !== undefined) {
        choice.find("div").replaceWith(Ember.$("<div></div>").html(formatted));
      }
      cssClass = this.opts.formatSelectionCssClass(data, choice.find("div"));
      if (cssClass !== `;`) {
        choice.addClass(cssClass);
      }

      if (enableChoice) {
        choice.find(".select2-search-choice-close")
          .on("mousedown", killEvent)
          .on("click dblclick", this.bind(function(e) {
            if (!this.isInterfaceEnabled()) {
              return;
            }

            this.unselect(Ember.$(e.target));
            this.selection.find(".select2-search-choice-focus").removeClass("select2-search-choice-focus");
            killEvent(e);
            this.close();
            this.focusSearch();
          })).on("focus", this.bind(function() {
            if (!this.isInterfaceEnabled()) {
              return;
            }
            this.container.addClass("select2-container-active");
            this.dropdown.addClass("select2-drop-active");
          }));
      }

      choice.data("select2-data", data);
      choice.insertBefore(this.searchContainer);
      /**
       * Added logic to enable more link.
       */
      choices = this.container.find('li.select2-search-choice').not(":hidden")
      choices.each(function(idx, val) {
        choicesWidth += Ember.$(val).outerWidth(true);
      });
      choicesWidth += choicesContainer.find('li.select2-search-field').width();
      // if (choices.length >= 1) {
      if (choicesWidth >= choicesContainer.innerWidth() - 90) {
        moreChoice = Ember.$(choices[0]).clone(true);
       // Ember.$(choices[0]).addClass('hidden');
        dropMenu.append(moreChoice);
        //moreContainer.removeClass('hidden');
        moreContainer.find('a.multi-select-more-option').html("<span>+ " + moreContainer.find('.select2-search-choice').length + "</span><span class='mdi icon-keyboard-arrow-down'></span>");
      } else {
        //fix: hidding more container if items are already there
        if (moreContainer.find('.select2-search-choice').length === 0) {
          //moreContainer.addClass('hidden');
        }
      }
      val.push(id);

      this.setVal(val);
    };

    /**
     * updateSelection for multiSelect.
     * @override
     */
    Select2.class.multi.prototype.updateSelection = function(data) {
      function indexOf(value, array) {
        var i = 0,
          l = array.length;
        for (; i < l; i = i + 1) {
          if (equal(value, array[i])) {
            return i;
          }
        }
        return -1;
      }
      /**
       * Compares equality of a and b
       * @param a
       * @param b
       */
      function equal(a, b) {
        if (a === b) {
          return true;
        }
        if (a === undefined || b === undefined) {
          return false;
        }
        if (a === null || b === null) {
          return false;
        }
        // Check whether 'a' or 'b' is a string (primitive or object).
        // The concatenation of an empty string (+'') converts its argument to a string's primitive.
        if (a.constructor === String) {
          return a + '' === b + ''; // a+'' - in case 'a' is a String object
        }
        if (b.constructor === String) {
          return b + '' === a + ''; // b+'' - in case 'b' is a String object
        }
        return false;
      }
      var ids = [],
        filtered = [],
        self = this;

      // filter out duplicates
      Ember.$(data).each(function() {
        if (indexOf(self.id(this), ids) < 0) {
          ids.push(self.id(this));
          filtered.push(this);
        }
      });
      data = filtered;

      this.selection.find(".select2-search-choice").remove();
      // Reset more container.
      this.container.find(".select2-search-more .select2-search-choice").remove();
      Ember.$(data).each(function() {
        self.addSelectedChoice(this);
      });
      self.postprocessResults();
    };
    /**
     * unselect for multiSelect.
     * @override
     */
    Select2.class.multi.prototype.unselect = function(selected) {
      function indexOf(value, array) {
        var i = 0,
          l = array.length;
        for (; i < l; i = i + 1) {
          if (equal(value, array[i])) {
            return i;
          }
        }
        return -1;
      }
      /**
       * Compares equality of a and b
       * @param a
       * @param b
       */
      function equal(a, b) {
        if (a === b) {
          return true;
        }
        if (a === undefined || b === undefined) {
          return false;
        }
        if (a === null || b === null) {
          return false;
        }
        // Check whether 'a' or 'b' is a string (primitive or object).
        // The concatenation of an empty string (+'') converts its argument to a string's primitive.
        if (a.constructor === String) {
          return a + '' === b + ''; // a+'' - in case 'a' is a String object
        }
        if (b.constructor === String) {
          return b + '' === a + ''; // b+'' - in case 'b' is a String object
        }
        return false;
      }
      var val = this.getVal(),
        data,
        evt,
        index,
        idxToRemove = null,
        hiddenChoices = this.container.find('li.select2-search-choice.hidden');

      selected = selected.closest(".select2-search-choice");

      if (selected.length === 0) {
        throw "Invalid argument: " + selected + ". Must be .select2-search-choice";
      }

      data = selected.data("select2-data");

      if (!data) {
        // prevent a race condition when the 'x' is clicked really fast repeatedly the event can be queued
        // and invoked on an element already removed
        return;
      }

      evt = Ember.$.Event("select2-removing");
      evt.val = this.id(data);
      evt.choice = data;
      this.opts.element.trigger(evt);

      if (evt.isDefaultPrevented()) {
        return false;
      }

      while ((index = indexOf(this.id(data), val)) >= 0) {
        val.splice(index, 1);
        this.setVal(val);
        if (this.select) {
          this.postprocessResults();
        }
      }

      selected.remove();
      /**
       * Remove the hidden choice as well.
       */
      hiddenChoices.each(function(idx, obj) {
        var choiceData = Ember.$(obj).data("select2-data");
        if (choiceData && this.id(choiceData) === this.id(data)) {
          idxToRemove = idx;
        }
      }.bind(this));
      if (idxToRemove != null) {
        hiddenChoices[idxToRemove].remove();
      }

      this.opts.element.trigger({
        type: "select2-removed",
        val: this.id(data),
        choice: data
      });
      this.triggerChange({
        removed: data
      });

      return true;
    };
    /* jshint ignore:end */
  },



  /**
   * container click for multiSelect.
   * @override
   */
  select2ContainerClick(e) {
    if (!this.isInterfaceEnabled()) {
      return;
    }
    if (Ember.$(e.target).closest(".select2-search-choice").length > 0 || Ember.$(e.target).closest(".select2-search-more").length > 0) {
      // clicked inside a select2 search choice or search more, do not open
      return;
    }
    this.selectChoice(null);
    this.clearPlaceholder();
    if (!this.container.hasClass("select2-container-active")) {
      this.opts.element.trigger(Ember.$.Event("select2-focus"));
    }
    this.open();
    this.focusSearch();
    e.preventDefault();
  },
  select2Resize() {
    if (!Ember.isEmpty(this.selection)) {
      this.updateSelection(this.data());
    }
  }
});
