import Ember from 'ember';

var DomUtil = {
  enableTooltip(selector) {
    var _this = this;

    Ember.$(selector).each(function() {
      if (_this.isEllipsisActive(this)) {
        Ember.$(this).attr("title", Ember.$(this).text());
      }
    });
  },

  isEllipsisActive(domElement) {
    return (domElement.offsetWidth < domElement.scrollWidth);
  },
};

export default DomUtil;
