import Ember from 'ember';

export default Ember.Mixin.create({
  rowActionItemsClass: 'row-action-items',
  rowActionItemClass: 'row-action-item-icon',

  rowActionItems: [{
    "id": "deactivate",
    "title": "Deactivate User",
    "iconClass": "mdi mdi-lock",
    "action": "onDeactivateClick",
    "conditionalClass": {
      "key": "active",
      "value": {
        "true": {
          "className": "mdi-border-color",
          "title": "Deactivate"
        },
        "false": {
          "className": "mdi-lock-open",
          "title": "Activate"
        }
      }
    }
  }, {
    "id": "editUser",
    "title": "Edit User",
    "iconClass": "mdi mdi-border-color",
    "action": "onEditClick"
  }],

  hoverActiveOnActionItems: false,
  hoverActiveOnActionItemsObserver: Ember.observer('hoverActiveOnActionItems', function() {
    if (this.hoverActiveOnActionItems === false) {
      Ember.run.next(() => {
        if (this.hoverActiveOnActionItems === false) {
          this.rowHoverTemplateEl.css({
            display: 'none'
          });
        }
      });
    }
  }),

  setRowTemplate() {
    if (this.gridConfig.showActionOnHover === true || this.gridConfig.showActionOnHover === 'true') {
      this.gridConfig.showActionOnHover = true;

      if (this.gridConfig.rowActionItems) {
        this.rowActionItems = this.gridConfig.rowActionItems;
      }

      this.rowHoverTemplate = this.getRowHoverTemplate(this.rowActionItems);
    } else {
      this.gridConfig.showActionOnHover = false;
    }
  },

  getRowHoverTemplate(rowActionItems) {
    let html = '<div class="' + this.rowActionItemsClass + '">';

    for (let i = 0, len = rowActionItems.length; i < len; i++) {
      let rowActionItem = rowActionItems[i];

      if (rowActionItem.conditionalClass) {
        this.conditionalIconOnHover = true;

        if (!this.conditionalIconFields) {
          this.conditionalIconFields = [];
        }

        this.conditionalIconFields[this.conditionalIconFields.length] = rowActionItem;
      }

      html += '<div class="row-action-item">';
      html +=   '<span id="' + rowActionItem.id +
                    '" title="' + rowActionItem.title +
                    '" class=" ' + this.rowActionItemClass + ' ' + rowActionItem.iconClass +
                    '" action="' + rowActionItem.action +
                    '" >' +
                '</span>';
      html += '</div>';
    }

    html += '</div>';

    return html;
  },

  appendRowHoverTemplate() {
    if (!this.rowHoverTemplateAppended) {
      this.grid.element.append(this.rowHoverTemplate);
      this.rowHoverTemplateEl = this.grid.element.find('.' + this.rowActionItemsClass);
      this.rowHoverTemplateAppended = true;
      this.rowHoverTemplateEl.find('.row-action-item-icon').on('click', this.eventHandlers.onRowActionItemClick.bind(null, this));
      this.onActionItemsHover();
    }
  },

  onActionItemsHover() {
    if (this.gridConfig.showActionOnHover) {

      this.rowHoverTemplateEl.hover(() => {
        this.set('hoverActiveOnActionItems', true);
        if (this.selectedRow) {
          this.selectedRow.addClass('k-state-hover');
        }
      }, () => {
        this.set('hoverActiveOnActionItems', false);
        this.selectedRow.removeClass('k-state-hover');
      });
    }
  },

  toggleRowHoverActions(onHover, selectedRow) {
    if (onHover) {
      let actionItemsHeight = 48;
      let rowHeight = selectedRow.height();
      let position = selectedRow.position();
      let top = (position.top + (rowHeight / 2) + (actionItemsHeight / 2) - 6);
      this.selectedRow = selectedRow;

      this.set('hoverActiveOnActionItems', true);

      if (this.conditionalIconOnHover) {
        this.updateContionalIconClass();
      }

      this.rowHoverTemplateEl.css({
        'top': top + 'px',
        display: 'flex',
        background: selectedRow.css('background-color')
      });
    } else {
      this.set('hoverActiveOnActionItems', false);
    }
  },

  getSelectedRow() {
    return this.selectedRow;
  },

  getSelectedRecord() {
    if (this.selectedRow) {
      return this.grid.dataItem(this.selectedRow).toJSON();
    }
  },

  updateContionalIconClass() {
    let conditionalIconFields = this.conditionalIconFields;
    let selectedRowItem = this.grid.dataItem(this.selectedRow).toJSON();

    for (let i = 0, len = conditionalIconFields.length; i < len; i++) {
      let rowActionItem = conditionalIconFields[i];
      let actionItemId = rowActionItem.id;
      let value = selectedRowItem[rowActionItem.conditionalClass.key];
      let valueObject = rowActionItem.conditionalClass.value[value];

      if (valueObject !== undefined) {
        let rowActionItemEl = this.rowHoverTemplateEl.find('#'+ actionItemId +'.row-action-item-icon');
        let valueMap = rowActionItem.conditionalClass.value;

        for (let key in valueMap) {
          let className = valueMap[key].className;

          rowActionItemEl.removeClass(className);
        }

        rowActionItemEl.addClass(valueObject.className);
        rowActionItemEl.attr('title', valueObject.title);
      } else {
        console.warn('No class defined for value: ' + value);
      }
    }
  }
});
