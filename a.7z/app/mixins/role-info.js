import Ember from 'ember';

export default Ember.Mixin.create({
  userCurrentRoleService: Ember.inject.service(),

  loadRoleInfoPopup(selectedRole, currentObject) {
    if (currentObject) {
      this.currentObject = currentObject;
    } else {
      this.currentObject = this;
    }

    return this.get('coreDataService').queryRecord('base', {
      screenName: 'roleInfoPopup',
      roleId: selectedRole.roleId
    }).then((menu) => {
      let roleInfoDetail = menu.get('info').roleInfoDetail;

      this.currentObject.setProperties({
        displayRoleInfoPopup: true,
        roleInfoDetail: roleInfoDetail,
        roleInfoPopupConfig: {
          title: selectedRole.roleName + ' Details',
          okBtnText: 'GOT IT',
          onOk: this.closeRoleInfoPopup,
          callbackContext: this
        }
      });
    });
  },

  closeRoleInfoPopup() {
    this.currentObject.set('displayRoleInfoPopup', false);
  }
});
