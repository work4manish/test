import Ember from 'ember';

export default Ember.Mixin.create({

  handleServerPagination() {
    if (this.serverPaging) {
      this.updateDefaultPageableObject();
      this.addDataSourceChangeEvent();
    }
  },

  handleServerPaginationElements() {
    if (this.serverPaging) {
      this.initializePagerComponentState();
      this.addEventHandlers();
    }
  },

  initializePagerComponentState() {
    this.pageSizeCombo = Ember.$('#' + this.gridId +' .k-grid-pager .k-dropdown select');
    this.previousBtn = Ember.$('#' + this.gridId + ' .k-grid-pager .k-i-arrow-w');
    this.nextBtn = Ember.$('#' + this.gridId + ' .k-grid-pager .k-i-arrow-e');
  },

  updateDefaultPageableObject() {
    let _this = this;

    this.defaultPageable.change = function(event) {
      if (this.totalPages() !== parseInt(event.index) || event.index !== '1') {
        _this.disableNavButtons();
        this.enableButtons = true;
      }

      _this.loadNewDataSet(event.index);
    };
  },

  loadNewDataSet(pageNumber) {
    this.refreshGrid(false, {
     currentPage: pageNumber
    });
  },

  addDataSourceChangeEvent() {
    // Not required any more as setting of total has been moved in databound event.
    // let _this = this;

    // this.gridConfig.dataSource.change = function( /*event*/ ) {
    //   if (_this.get('data')) {
    //     this._total = _this.get('totalRecords');
    //   }
    // };
  },

  addEventHandlers() {
    this.pageSizeCombo.on('change', this.onPageSizeChange.bind(this));
  },

  disableNavButtons() {
    this.disableNavButton(this.previousBtn.parent());
    this.disableNavButton(this.nextBtn.parent());
  },

  enableNavButtons() {
    this.disableNavButton(this.previousBtn.parent(), false);
    this.disableNavButton(this.nextBtn.parent(), false);
  },

  disableNavButton(navButton, disable) {
    let disableClass = 'k-state-disabled';
    let disablFn = 'addClass';

    if (disable === false) {
      disablFn = 'removeClass';
    }

    navButton[disablFn](disableClass);
  },

  onPageSizeChange() {
    this.set('pageSize', parseInt(this.pageSizeCombo.val()));
    this.loadNewDataSet(1);
  },

  resetPager(gridData) {
    /*this.grid.dataSource._page = 1;
    this.grid.dataSource._page = 1;
    this.grid.pager._page = 1;
    this.grid.dataSource.total(parseInt(gridData.total));
    */
    this.grid.dataSource._total = parseInt(gridData.total);
    this.grid.dataSource.page(1);
  }
});
