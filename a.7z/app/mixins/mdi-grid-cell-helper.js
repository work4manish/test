import Ember from 'ember';

export default Ember.Mixin.create({
  attachCellClickEvent() {
    this.grid.table.on('click', 'tbody td', this.eventHandlers.onCellClick.bind(this));
  },

  getCellIndex(cell) {
    var lockedColumnsLength = this.getLockedColumns().length;
    var cellIndex = cell[0].cellIndex + lockedColumnsLength;

    return cellIndex;
  },

  getLockedColumns() {
    let lockedColumns = [];
    let columns = this.grid.columns;

    for (let i = 0, len = columns.length; i < len; i++) {
      let column = columns[i];

      if (column.locked) {
        lockedColumns[lockedColumns.length] = column;
      }
    }

    return lockedColumns;
  },

  showCellValueInPopup(cellValue, column, event) {
    this.set('cellValueDialogConfig', {
      title: 'Detail',
      info: cellValue,
      hideHeader: true,
      showFooter: true,
      hideCancelBtn: true,
      onOk: this.closeCellValuePopup,
      callbackContext: this,
      event: event
    });

    this.set('cellValueDialog', true);
  },

  closeCellValuePopup() {
    this.set('cellValueDialog', false);
  }
});
