import Ember from 'ember';

export default Ember.Mixin.create({
  colActionItemsClass: 'col-action-items',
  colActionItemClass: 'col-action-item-icon',
  colActionItems: null,/*[{"id": "delete", "title": "Delete", "iconClass": "mdi mdi-minus-circle",
                            "action": "onDeleteClick"}],*/
  addActionColumn() {
    if (this.gridConfig.colActionItems) {
      this.colActionItems = this.gridConfig.colActionItems;
    }

    if (this.colActionItems) {
      this.gridConfig.columns.push({
        width: 50,
        title: ' ',
        command: {
          name: 'details',
          template: this.getColumnActionTemplate()
        }
      });
    }
  },

  getColumnActionTemplate() {
    let html = '<div class="' + this.colActionItemsClass + '">';
    let colActionItems = this.colActionItems;

    for (let i = 0, len = colActionItems.length; i < len; i++) {
      let colActionItem = colActionItems[i];

      html += '<div class="row-action-item">';
      html +=   '<span id="' + colActionItem.id +
                      '" title="' + colActionItem.title +
                      '" class=" ' + this.colActionItemClass + ' ' + colActionItem.iconClass +
                      '" action="' + colActionItem.action +
                      '" >' +
                '</span>';
      html += '</div>';
    }

    html += '</div>';

    return html;
  },

  attachColumActionHandler() {
    this.grid.table.on('click', '.' + this.colActionItemClass, this.onColumnActionClick.bind(this));
  },

  onColumnActionClick(event) {
    event.stopPropagation();
    let target = Ember.$(event.target);
    let action = target.attr('action');
    let row = Ember.$(event.target).closest('tr');
    let dataItemRow = this.grid.dataItem(row);

    if (action) {
      this[action] = action;
      this.sendAction(action, dataItemRow.toJSON(), target.attr('id'));
    }
  }
});
