import Ember from 'ember';
import mdTab from 'ember-cli-materialize/components/md-tab';

export default mdTab.extend({
  onTabChange: 'onTabChange',

  active: Ember.computed('composableParent.composableChildren.[]', 'composableParent.selected', 'value', function() {
    const selected = this.get('composableParent.selected');
    if (selected) {
      let value = this.get('value');
      if (value.toUpperCase() === 'CAL' || value.indexOf('||') > -1) {
        return (selected === value || selected === 'CAL' || selected.indexOf('||') > -1);
      } else {
        return selected === value;
      }
    } else {
      const values = this.get('composableParent')
        .tabComponents()
        .map(t => t.get('value'));
      return values.indexOf(this.get('value')) === 0;
    }
  }).readOnly(),

  actions: {
    onTabChange(selectedValue) {
      this.sendAction('onTabChange', selectedValue);
    }
  },

  init() {
    this._super();
  },

  click: function click() {
    let value = this.get('value') + '';
    let composableParent = this.get('composableParent');

    if (value.toUpperCase() === 'CAL' || value.indexOf('||') > -1) {
      composableParent.set('selected', '');

      Ember.run.next(() => {
        composableParent.set('selected', value);
      });
    } else {
      composableParent.set('selected', value);
    }
  }
});
