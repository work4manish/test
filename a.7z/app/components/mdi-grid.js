import Ember from 'ember';
import PaginationHelper from '../mixins/pagination-helper';
import RowActionItemHelper from '../mixins/mdi-grid-row-action-helper';
import CheckboxRowHelper from '../mixins/mdi-grid-checkbox-row-helper';
import ColumnActionHelper from '../mixins/mdi-grid-column-action-helper';
import CellHelper from '../mixins/mdi-grid-cell-helper';

export default Ember.Component.extend(PaginationHelper, RowActionItemHelper, CheckboxRowHelper,
  ColumnActionHelper, CellHelper, {
  primaryKeyField: 'id',
  gridId: null,
  height: null,
  data: null,
  newRows: null,
  gridItemId: null, //'This value will be sent to server to fetch grid data'
  gridIdParamKey: 'gridId',
  coreDataService: Ember.inject.service(),
  resetRefreshFlagToFalse: 'resetRefreshFlagToFalse',
  reCreateGrid: false,
  resetConfig: false,
  bottomBar: null,
  topBar: null,
  serverPaging: true,
  serverSorting: true,
  serverAggregates: true,
  serverFiltering: false,
  styleAttribMap: {
    color: 'color',
    backgroundColor: 'background-color',
    fontWeight: 'font-weight',
    fontSize: 'font-size'
  },
  onColumnMenuSelect: 'onColumnMenuSelect',
  defaultPageable: {
    "pageSizes": [5, 10, 20, 100],
    "pageSize": 10,
    "messages": {
      "itemsPerPage": "Rows per page:",
      "display": "{0}-{1} of {2}",
      "empty": "No data"
    },
  },

  reCreateGridObserver: Ember.observer('reCreateGrid', function() {
    if (this.reCreateGrid) {

      this.createGrid(this.gridConfig);

      this.set('reCreateGrid', false);
    }
  }),

  refreshObserver: Ember.observer('refresh', function() {
    if (this.get('refresh')) {
      this.refreshGrid();
    }
  }),

  dataObserver: Ember.observer('data', function() {
    this.updateDataSource();
    this.updateCustomLegendPanel();
    this.sendDataChangeAction();
  }),

  newRowsObserver: Ember.observer('newRows.length', function() {
    if (this.newRows && this.newRows.length > 0) {
      this.appendRows();
      this.set('newRows', Ember.A([]));
      this.sendDataChangeAction();
    }
  }),

  removedRowsObserver: Ember.observer('removedRows.length', function() {
    if (this.removedRows && this.removedRows.length > 0) {
      this.removeRows();
      this.set('removedRows', Ember.A([]));
      this.sendDataChangeAction();
    }
  }),

  setupConfig: Ember.on('init', function() {
    if (this.gridConfig) {
      this.initializeConfig();
    } else {
      this.fetchConfig();
    }
  }),

  actions: {
    onColumnMenuSelect(selectedColumns, lastClickedColumn) {
      if (lastClickedColumn.isChecked) {
        this.grid.showColumn(lastClickedColumn.field);
      } else {
        this.grid.hideColumn(lastClickedColumn.field);
      }
    }
  },

  eventHandlers: {
    onRowColChange(_this /*, event*/ ) {
      let selectedRow = _this.grid.select();

      if (selectedRow) {
        let selectedItem = _this.grid.dataItem(selectedRow).toJSON();

        _this[_this.onRowSelect] = _this.onRowSelect;
        _this.sendAction(_this.onRowSelect, selectedItem);
      }
    },

    onRowHover(_this, rowHover, event) {
      let selectedRow = Ember.$(event.target.closest('tr'));

      _this.toggleRowHoverClass(rowHover, selectedRow, event);

      if (_this.gridConfig.showActionOnHover) {
        _this.toggleRowHoverActions(rowHover, selectedRow, event);
      }
    },

    onRowActionItemClick(_this, event) {
      let target = Ember.$(event.target);

      var action = target.attr('action');
      var id = target.attr('id');

      if (action) {
        if (_this.selectedRow) {
          let selectedItem = _this.grid.dataItem(_this.selectedRow).toJSON();

          _this[action] = action;
          _this.sendAction(action, id, selectedItem);
        }
      }
    },

    onCellClick(event) {
      var cell = this.$(event.currentTarget);
      var cellIndex = this.getCellIndex(cell);
      //var grid = this.$(this.gridId).data("kendoGrid");
      var column = this.grid.columns[cellIndex];
      var dataItem = this.grid.dataItem(cell.closest("tr"));
      var cellValue = dataItem[column.field];
      var onCellSelect = this.onCellSelect;

      if (onCellSelect) {
        this[onCellSelect] = onCellSelect;
        this.sendAction(onCellSelect, cellValue, column, event);
      } else if (column.multiline) {
        cellValue = Ember.copy(dataItem[column.field + 'Original'], true);
        this.showCellValueInPopup(cellValue, column, event);
        event.stopPropagation();
      }
    }
  },

  sendDataChangeAction() {
    if (this.onDataChange) {
      this[this.onDataChange] = this.onDataChange;
      this.sendAction(this.onDataChange, this.get('data'), this.primaryKeyField);
    }
  },

  initializeConfig() {
    this.set('selectedRows', Ember.A([]));
    this.set('newRows', Ember.A([]));
    this.set('removedRows', Ember.A([]));

    if (this.gridConfig.kendoDefault) {
      this.set('gridConfig', this.gridConfig);
    } else {
      this.setupGridConfig();
    }
  },

  fetchConfig() {
    let params = this.get('serviceParams') || {};
    this.setGridIdParam(params);
    let modelName = this.getModelName();

    this.get('coreDataService').queryRecord(modelName, params).then((response) => {
      let gridItem = this.getGridItemFromResponse(response);
      this.gridConfig = gridItem.get('gridConfig');
      this.gridData = gridItem.get('gridData');

      if (!this.isDestroyed) {
        this.initializeConfig(gridItem);
        this.set('reCreateGrid', true);
      }
    });
  },

  setGridIdParam(params) {
    if (!params[this.gridIdParamKey]) {
      params[this.gridIdParamKey] = this.gridItemId;
    }
  },

  refreshGrid(reCreateGrid, extraParams) {
    let params = this.get('serviceParams') || {};

    params.configRequired = false;
    params.currentPage = extraParams && extraParams.currentPage ? extraParams.currentPage : 1;
    params.pageSize = this.get('pageSize');
    this.setGridIdParam(params);

    if (extraParams) {
      for (let paramKey in extraParams) {
        if (extraParams[paramKey]) {
          params[paramKey] = extraParams[paramKey];
        }
      }
    }

    this.resetSelectedRows();
    this.set('gridDataLoading', true);

    let modelName = this.getModelName();
    return this.get('coreDataService').queryRecord(modelName, params).then((response) => {
      let gridItemResponse = this.getGridItemFromResponse(response); //gridItem.get('gridData');
      this.gridData = gridItemResponse.get('gridData');

      if (params.currentPage === 1) {
        this.resetPager(this.gridData);
      }

      if (!this.isDestroyed) {
        this.set('data', this.gridData.data);

        if (this.get('refresh') && !this.gridConfig.noResetRefreshRequired) {
          //TODO: Remove logic of sending action
          this.sendAction('resetRefreshFlagToFalse');
        }

        if (this.enableButtons) {
          this.enableNavButtons();
        }

        this.set('gridDataLoading', false);
      }
    });
  },

  getModelName() {
    var modelName;

    if (this.gridConfig && this.gridConfig.modelName) {
      modelName = this.gridConfig.modelName;
    }

    if (!modelName && this.modelName) {
      modelName = this.modelName;
    }

    if (!modelName) {
      modelName = 'gridItem';
    }

    return modelName;
  },

  getGridItemFromResponse(response) {
    let gridItem;

    if (this.gridItemRoot) {
      gridItem = Ember.Object.create(response.get(this.gridItemRoot).gridItem);
    }

    if (!gridItem && this.gridConfig && this.gridConfig.gridItemRoot) {
      gridItem = Ember.Object.create(response.get(this.gridConfig.gridItemRoot).gridItem);
    }


    return gridItem || response;
  },

  setupGridConfig() {
    this.gridConfig.height = this.get('height') || this.gridConfig.height;

    if (!this.gridConfig.height) {
      this.gridConfig.height = '100%';
    }

    if (this.gridConfig.gridId) {
      this.set('gridItemId', this.gridConfig.gridId);
    }

    this.setupTopBarConfig();

    this.setColumnTemplate();
    this.setRowTemplate();
    this.set('columnMenu', this.gridConfig.columnMenu);
    this.gridConfig.columnMenu = false;

    this.prepareColumnListMenu();
    this.addEvents();
    this.setDataSource();
    //this should be last one, because for server side paging defaultPageable object is changed
    this.setBottomBar();
    this.postSetupGridConfig();
  },

  setupTopBarConfig() {
    let topBarItems = [];
    let isTopBarPresent = false;

    if (false /*this.gridConfig.downloadEnable*/ ) {
      isTopBarPresent = true;

      topBarItems[topBarItems.length] = {
        title: 'Export',
        iconClass: 'mdi-download',
        text: 'Export'
      };
    }

    if (isTopBarPresent || (this.gridConfig.topBar && typeof this.gridConfig.topBar === 'object')) {
      this.set('topBarItems', isTopBarPresent ? topBarItems : this.gridConfig.topBar);
    }
  },

  postSetupGridConfig() {
    if (this.serverPaging) {
      this.set('pageSize', this.gridConfig.pageable.pageSize);
      this.handleServerPagination(this.gridData);
    }
  },

  didInsertElement() {
    let gridConfig = this.get('gridConfig');

    try {
      this.set('gridId', this.elementId + '-kendo-grid');

      if (gridConfig) {
        this.createGrid(gridConfig);
      } else {
        this.$('#' + this.gridId).kendoGrid();
      }

      this.sendAction('afterGridRender', this);
    } catch (error) {
      Ember.Logger.error(error);
    }
  },

  createGrid: function(gridConfig) {
    let gridIdSelector = "#" + this.gridId;
    this.$(gridIdSelector).kendoGrid(gridConfig);
    this.set('grid', this.$(gridIdSelector).data("kendoGrid"));
    this.set('data', this.getData(this.get('serverPaging')));
    /*this.gridLoadingObserver(); //call the progress bar loader on init*/
    this.postGridCreationTasks();
  },

  addEvents() {
    this.setDataBoundEvent();

    let enableRowSelect = (this.gridConfig.enableRowSelect === true || this.gridConfig.enableRowSelect === 'true');
    if (enableRowSelect) {
      if (this.onRowSelect) {
        this.gridConfig.selectable = 'row';
        this.gridConfig.change = this.eventHandlers.onRowColChange.bind(null, this);
      }
    }
  },

  setDataBoundEvent() {
    let dataBound = this.gridConfig.dataBound;
    let _this = this;

    this.gridConfig.dataBound = function( /*event*/ ) {
      if (_this.gridColumnsLockable || _this.rowHoverTemplate) {
        _this.highlightEntireRow(this);
      }

      if (_this.serverPaging) {
        this.dataSource._total = parseInt(_this.gridData.total);
      }

      if (_this.gridConfig.highlightCell) {
        _this.highlightCell();
      }

      if (_this.gridConfig.enableRowConfig) {
        _this.applyRowConfig(this.dataSource.view());
      }

      if (dataBound) {
        //dataBound(event);
      }
    };
  },

  applyRowConfig(dataView) {

    for (let i = 0; i < dataView.length; i++) {
      let dataItem = dataView[i];
      let rowConfig = dataItem.rowConfig ? dataItem.rowConfig.toJSON() : '';

      if (rowConfig) {
        let uid = dataItem.uid;

        if (this.grid.lockedTable) {
          let lockedRow = this.grid.lockedTable.find("tr[data-uid=" + uid + "]");
          lockedRow.css(rowConfig);
        }

        let row = this.grid.table.find("tr[data-uid=" + uid + "]");
        row.css(rowConfig);
      }
    }
  },

  attachColumnResizeEvent() {
    let _this = this;
    this.gridConfig.columnResize = function(event) {
      let column = event.column;
      let newWidth = event.newWidth;

      if (event.column.multiline) {
        _this.updateMultilineCellContent(column, newWidth);
      }
    };
  },

  updateMultilineCellContent(column, newWidth) {
    let trs = this.grid.table.find('tr');

    for (let i = 0, len = trs.length; i < len; i++) {
      let tr = trs[i];
      let dataItem = this.grid.dataItem(tr);
      let originalCellValue = Ember.copy(dataItem.get(column.field + 'Original'), true);
      column.width = newWidth;
      let newValue = this.truncateCellContentTillScrollHides(originalCellValue, newWidth);

      this.deriveCellContent = false;
      dataItem.set(column.field, newValue);
      this.deriveCellContent = true;
    }
  },

  highlightEntireRow(kendoGridObject) {
    var rows = Ember.$(kendoGridObject.table).find('tbody tr');
    var lockedRows = Ember.$(kendoGridObject.lockedTable).find('tbody tr');

    rows.hover(this.eventHandlers.onRowHover.bind(null, this, true),
      this.eventHandlers.onRowHover.bind(null, this, false));

    lockedRows.hover(this.eventHandlers.onRowHover.bind(null, this, true),
      this.eventHandlers.onRowHover.bind(null, this, false));
  },

  toggleRowHoverClass(onHover, selectedRow /*, event*/ ) {
    var dataUiId = selectedRow.attr('data-uid');
    var trs = Ember.$('[data-uid=' + dataUiId + ']');
    let fnName = 'removeClass';

    if (onHover) {
      fnName = 'addClass';
    }

    trs[fnName]('k-state-hover');
  },

  setColumnTemplate() {
    let columns = this.gridConfig.columns;
    this.gridColumnsLockable = false;

    for (let i = 0, len = columns.length; i < len; i++) {
      let column = columns[i];

      this.addFooterTemplateForAggregateColumns(column);
      this.addCellStyleTemplate(column);
      this.prepareAggregateConfig(column);

      if (column.lockable || column.locked) {
        this.gridColumnsLockable = true;
      }

      if (column.primaryKeyField === true || column.primaryKeyField === 'true') {
        this.set('primaryKeyField', column.field);
      }
    }

    this.addHighlightCellTemplate(columns);

    if (this.gridConfig.rowSelectionMode === 'checkbox') {
      this.set('rowSelectionMode', 'checkbox');
      this.addCheckboxColumn();
    }

    this.addActionColumn();
  },

  addHighlightCellTemplate(columns) {
    if (this.gridConfig.highlightCell) {
      let highlightCellColorField = this.gridConfig.highlightCellColorField || 'color';
      let firstColumn = columns[0];
      let template;

      if (typeof firstColumn.template === 'function') {
        template = firstColumn.template;
      }

      firstColumn.template = (record) => {
        if (!this.dataUidMap) {
          this.dataUidMap = [];
        }
        this.dataUidMap['' + record.get('uid') + ''] = record.get(highlightCellColorField);

        if (template) {
          return template(record);
        }

        return record.get(firstColumn.field);
      };
    }
  },

  addFooterTemplateForAggregateColumns(column) {
    let aggregate = column.aggregate instanceof Array ? column.aggregate[0] : column.aggregate;

    if (aggregate) {
      let aggregateConfig = {
        field: column.field,
        aggregate: aggregate
      };

      column.footerTemplate = this.footerTemplate.bind(this, aggregateConfig, column);
      column.footerAttributes = {
        class: 'table-footer-cell',
        style: 'text-align: ' + column.align + ';'
      };
    }
  },

  footerTemplate(aggregateConfig, column, aggregateDetail) {
    if (this.gridData.aggregates && aggregateConfig) {
      let aggregateValue = this.gridData.aggregates[aggregateConfig.field][aggregateConfig.aggregate];

      return '<span calss="align-span-' + column.align + ' ' + (column.customClass ? column.customClass : '') + '">' + aggregateValue + '</span>';
    }

    return aggregateDetail[aggregateConfig.field][aggregateConfig.aggregate];
  },

  addCellStyleTemplate(column) {
    if (column.align) {
      column.headerAttributes = {
        class: 'custom-grid-header-cell',
        style: 'text-align: ' + column.align + ';'
      };
    }

    if (column.align || column.cellStyle || column.multiline) {
      column.template = this.doCellStyling.bind(this, column);
    }

    if (column.multiline) {
      this.set('cellClickEventRequired', true);
      this.attachColumnResizeEvent();
    }
  },

  doCellStyling(column, record) {
    let className = '';
    if (column.align) {
      className = 'align-span-' + column.align;
    }

    let cssStyles = '';
    let cellConfig = record.get('cellConfig');
    if (column.cellStyle && cellConfig) {
      let currentCellConfig = cellConfig[column.field];

      if (currentCellConfig) {
        cssStyles = this.getCssStyleString(currentCellConfig);
      }
    }

    let html = '<div class=" ' + className + ( column.multiline ? ' multiline-cell ' : '') +
                  (cssStyles ? '" style="' + cssStyles : '')  +
                  '">' +
                    this.getCellContent(column, record) +
                '</div>';

    return html;
  },

  getCssStyleString(styleConfigMap) {
    let cssStyles = '';

    for (let styleAttrib in styleConfigMap) {
      if (styleConfigMap.hasOwnProperty(styleAttrib)) {
        let styleKey = this.styleAttribMap[styleAttrib];

        if (styleKey) {
          cssStyles += styleKey + ':' + styleConfigMap['' + styleAttrib + ''] + ';';
        }
      }
    }

    return cssStyles;
  },

  getCellContent(column, record) {
    var cellContent = Ember.copy(record.get(column.field), true);

    if (column.multiline && this.deriveCellContent !== false) {
      this.deriveCellContent = false;
      record[column.field + 'Original'] = cellContent;
      let modifiedCellContent = this.truncateCellContentTillScrollHides(cellContent, column.width);
      this.deriveCellContent = true;

      return modifiedCellContent;
    }

    return cellContent;
  },

  truncateCellContentTillScrollHides(cellValue, columnWidth) {
    //console.log('truncateCellContentTillScrollHides called');
    let cellContent = Ember.copy(cellValue, true);
    let cellWidth = columnWidth ? columnWidth - 30 : 70; //30 is padding-left + padding-right that needs to be removed
    let pxRequiredSingleChar = 7;   //on an average 7px will be required for one char for font-size 13px;
    let noOfCharsToBeDisplayed = (cellWidth / pxRequiredSingleChar) * 2;
    let newCellContent = cellContent.substring(0, noOfCharsToBeDisplayed);
    let showEllipsis = false;

    if (cellContent.length > newCellContent.length) {
      let multilineScrollabeCellClass = 'multiline-cell-scrollable';
      let gridContainer = this.$('.grid-container');
      let multilineScrollabeCell = gridContainer.find('.' + multilineScrollabeCellClass);

      if (multilineScrollabeCell.length === 0) {
        gridContainer.append('<div class="multiline-cell-scrollable" style="width:'+ cellWidth +'px;">'+
                              '</div>');
        multilineScrollabeCell = gridContainer.find('.' + multilineScrollabeCellClass);
      } else {
        multilineScrollabeCell.css({
          width: cellWidth + 'px'
        });
      }

      multilineScrollabeCell.html(newCellContent);

      let cellHeight = multilineScrollabeCell.height();
      let domEl = multilineScrollabeCell[0];
      let scrollHeight = domEl.scrollHeight;

      while(scrollHeight <= cellHeight) {
        newCellContent = cellContent.substring(0, ++noOfCharsToBeDisplayed);

        multilineScrollabeCell.html(newCellContent);
        scrollHeight = domEl.scrollHeight;
        showEllipsis = true;
      }

      while(scrollHeight > cellHeight) {
        newCellContent = newCellContent.substring(0, newCellContent.length - 1);

        multilineScrollabeCell.html(newCellContent);
        scrollHeight = domEl.scrollHeight;
        showEllipsis = true;
      }
    }

    if (showEllipsis) {
      newCellContent = newCellContent.substring(0, newCellContent.length - 3) + '...';
      cellContent = newCellContent;
    }

    return cellContent;
  },

  prepareAggregateConfig(column) {
    if (column && column.aggregate) {
      if (!this.columnAggregates) {
        this.columnAggregates = [];
      }

      let columnAggregate = (column.aggregate instanceof Array) ? column.aggregate[0] : column.aggregate;
      let columnAggregates = this.columnAggregates;

      columnAggregates[columnAggregates.length] = {
        field: column.field,
        aggregate: columnAggregate
      };
    }
  },

  prepareColumnListMenu() {
    if (this.get('columnMenu')) {
      let columnMenuItems = [];

      for (let i = 0, len = this.gridConfig.columns.length; i < len; i++) {
        let column = this.gridConfig.columns[i];
        let columnMenuItem = column;

        if (columnMenuItem.locked) {
          continue;
        }

        columnMenuItem.isChecked = true;
        columnMenuItems[columnMenuItems.length] = columnMenuItem;
      }

      this.set('columnMenuItems', columnMenuItems);
    }
  },

  getActionColumnTemplate: function() {
    var template = '';
    template += '<div class="dropdown column-action-menu">';
    template += '<span class="mdi mdi-dots-vertical" id="' + this.elementId + '-column-menu" data-toggle="dropdown" aria-expanded="true"></span>';
    template += '</div>';

    return template;
  },

  getColumnAlignHTML(columnConfig, record) {
    return '<span class="align-span-' + columnConfig.align + '">' + record.get(columnConfig.field) + '</span>';
  },

  highlightCell() {
    for (let key in this.dataUidMap) {
      if (this.dataUidMap.hasOwnProperty(key)) {
        let trObj = Ember.$('[data-uid=' + key + ']')[0];
        let firstCell = Ember.$(trObj).find('td:first-child');

        firstCell.css('border-left', '3px solid ' + this.dataUidMap[key]);
      }
    }
  },

  setDataSource() {
    if (this.gridData) {
      this.set('serverPaging', ((String(this.gridConfig.hideBottomBar) !== 'true') &&
        (this.gridConfig.serverPaging !== 'false' || this.gridConfig.serverPaging !== false)));

      this.gridConfig.dataSource = this.getDataSourceConfig();
    }
  },

  getDataSourceConfig() {
    this.set('serverPaging', ((String(this.gridConfig.hideBottomBar) !== 'true') &&
      (this.gridConfig.serverPaging !== 'false' || this.gridConfig.serverPaging !== false)));
    this.set('serverSorting', this.gridConfig.serverSorting !== 'false' || this.gridConfig.serverPaging !== false);

    let dataSourceConfig = {
      data: [],
      serverPaging: this.get('serverPaging'),
      serverSorting: this.get('serverSorting'),
      serverAggregates: this.get('serverAggregates'),
      serverFiltering: false,
      total: parseInt(this.gridData.total)
    };

    this.setAggregatesConfig(dataSourceConfig);

    return dataSourceConfig;
  },

  setAggregatesConfig(dataSourceConfig) {
    if (this.get('columnAggregates')) {
      dataSourceConfig.aggregate = this.get('columnAggregates');
    }
  },

  updateDataSource() {
    if (this.serverPaging) {
      this.clearDataSource();
    }

    this.grid.dataSource.data(this.get('data'));
  },

  clearDataSource() {
    let dataSource = this.grid.dataSource;

    while (dataSource.data().length) {
      let dataItem = dataSource.data()[0];

      dataSource.remove(dataItem);
    }
  },

  appendRows() {
    let data = Ember.A(this.grid.dataSource.data()) || Ember.A([]);

    for (let i = 0, len = this.newRows.length; i < len; i++) {
      let newRow = this.newRows[i];
      let row = data.findBy(this.primaryKeyField, newRow[this.primaryKeyField]);

      if (!row) {
        this.data[this.data.length] = newRow;
        this.grid.dataSource.pushCreate(newRow);
      }
    }
  },

  removeRows() {
    let data = Ember.A(this.grid.dataSource.data()) || Ember.A([]);

    for (let i = 0, len = this.removedRows.length; i < len; i++) {
      let removedRow = this.removedRows[i];
      let row = data.findBy(this.primaryKeyField, removedRow[this.primaryKeyField]);

      if (row) {
        let index = this.data.findIndex(this.findItemsIn.bind(this, removedRow));

        if (index > -1) {
          Ember.A(this.data).removeAt(index);
          this.grid.dataSource.pushDestroy(row);
        }
      }
    }
  },

  getRows() {
    return this.get('data');
  },

  findItemsIn(removedRow, item/*, index*/) {
    if (item[this.primaryKeyField] === removedRow[this.primaryKeyField]) {
      return true;
    }
  },

  getData(serverPaging) {
    let data;

    if (serverPaging) {
      data = this.gridData.data;
      this.set('totalRecords', parseInt(this.gridData.total));
      if (!data || !(data instanceof Array)) {
        Ember.Logger.error('gridData must have key data for sever side pagination.');
      }
    } else {
      data = this.gridData;

      if (!(data instanceof Array)) {
        if (this.gridData.data instanceof Array) {
          data = this.gridData.data;
          this.gridData = data;
        } else {
          Ember.Logger.error('gridData or gridData.data must be an array for client side pagination.');
        }
      }
    }

    return data;
  },

  setBottomBar() {

    if (!this.gridConfig.hideBottomBar) {
      if (!this.gridConfig.bottomBar) {
        this.gridConfig.bottomBar = {};
      }

      if (this.gridConfig.bottomBar.pageable === undefined) {
        this.gridConfig.bottomBar.pageable = true;
      }
    }

    if (this.gridConfig.bottomBar) {
      let pageable = this.gridConfig.bottomBar.pageable;

      if (pageable) {
        if (pageable === true || pageable === 'true') {
          this.gridConfig.pageable = this.defaultPageable;
        } else {
          this.gridConfig.pageable = this.defaultPageable;

          for (let key in pageable) {
            if (pageable.hasOwnProperty(key)) {
              this.gridConfig.pageable[key] = pageable[key];
            }
          }
        }
      } else {
        this.gridConfig.pageable = false;
      }
    }

    if (this.gridConfig.pageable === false || !this.gridConfig.bottomBar ) {
      this.set('noPagerClass', 'no-pager');
    }
  },

  postGridCreationTasks() {
    this.addCustomLegendPanel();
    this.handleServerPaginationElements();
    this.appendColumnListMenuTemplate();
    this.appendRowHoverTemplate();
    this.handleSorting();
    this.attachRowSelectEvent();
    this.attachColumActionHandler();

    if (this.gridConfig.cellClickEventRequired) {
      this.set('cellClickEventRequired', true);
    }

    if (this.cellClickEventRequired) {
      this.attachCellClickEvent();
    }
  },

  appendColumnListMenuTemplate() {
    if (this.get('columnMenu')) {
      let headerWrapEl = Ember.$('#' + this.gridId + ' .k-grid-header');

      headerWrapEl.append('<div class="sup-column-menu mdi mdi-dots-vertical"></div>');
    }
  },

  handleSorting() {
    let _this = this;

    this.grid.dataSource.sort = function(sortOptions) {

      if (sortOptions) {
        let sortOption = sortOptions[0];

        if (_this.get('serverSorting')) {
          _this.refreshGrid(false, {
            sortOrder: sortOption.dir,
            sortField: sortOption.field
          });
        }

        this._sort = sortOptions;

        return;
      }

      return this._sort;
    };
  },

  addCustomLegendPanel() {
    if (this.gridConfig.bottomBar) {
      let legends = this.gridConfig.bottomBar.legends;

      if (legends) {
        let gridPanel = Ember.$('#' + this.gridId);
        let pagerPanel = gridPanel.find('.k-pager-wrap.k-grid-pager');

        if (pagerPanel) {
          let html = '<div class="legend-panel">';

          html += this.addLegendItems(legends);

          html += '</div>';

          pagerPanel.prepend(html);
        }
      }
    }
  },

  updateCustomLegendPanel() {
    if (this.gridConfig.bottomBar && this.gridConfig.bottomBar.refreshLegends) {
      let legendPanel = Ember.$('#' + this.gridId).find('.legend-panel');

      this.clearLegendPanel(legendPanel);

      if (this.gridData.legends) {
        let legendItems = this.addLegendItems(this.gridData.legends);

        legendPanel.append(legendItems);
      }
    }
  },

  clearLegendPanel(legendPanel) {
    let legendItems = legendPanel.children();

    for (let i = 0, len = legendItems.length; i < len; i++) {
      legendItems[i].remove();
    }
  },

  addLegendItems(legends) {
    let html = '';

    for (let i = 0; i < legends.length; i++) {
      let legend = legends[i];
      html += this.addLegendItem(legend);
    }

    return html;
  },

  addLegendItem(legend) {
    let html = '';
    html += '<div class="legend-item">';
    html += '<span class="lengend-icon" style="background:' + legend.color + ';"></span>';
    html += '<span class="lengend-text" style="">' + legend.text + '</span>';
    html += '</div>';

    return html;
  },

  willDestroy() {
    if (this.serverPaging) {
      if (this.pageSizeCombo) {
        this.pageSizeCombo.off('change');
        this.set('pageSizeCombo', null);
      }
    }

    if (this.rowHoverTemplateEl) {
      let rowActionItemIcon = this.rowHoverTemplateEl.find('row-action-item-icon');

      rowActionItemIcon.off();
      this.set('rowHoverTemplateEl', null);
    }

    if (this.grid) {
      if (this.grid.thead) {
        this.grid.thead.off();
      }

      if (this.grid.table) {
        this.grid.table.off();
      }

      if (this.selectedRows) {
        this.set('selectedRows', null);
      }
    }

    this.set('grid', null);
  }
});
