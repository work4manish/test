import Ember from 'ember';
import NumberUtil from '../utils/number-util';

export default Ember.Component.extend({
  coreDataService: Ember.inject.service(),

  actions: {
    onKeyupSearchText(searchString) {
      let isNumericValue = NumberUtil.isNumber(searchString);

      if (searchString && !this.isSearchInProgress && (isNumericValue && searchString.length >= 7 && searchString.length <= 10)) {

        this.isSearchInProgress = true;

        this.get('coreDataService').queryRecord('base', {
          screenName: this.get('screenName'),
          userId : searchString
        }).then((users) => {
          this.isSearchInProgress = false;
          let psidList = users.get('info').userLookup;
          Ember.$('.autocomplete-result').fadeIn();
          this.setProperties({
            psidList: psidList
          });
        }).catch((reason) => {
          console.log(reason);
        });

      } else if (searchString.length === 0 && this.controller.get('psidList') &&
        this.controller.get('psidList').length > 0) {
        this.controller.set('psidList', []);
        this.userAction = 'removeUserInfo';
        this[this.userAction] = this.userAction;
        this.sendAction(this.userAction);
        Ember.$('.autocomplete-result').fadeOut();
      }
    },

    focusOutInput(){
      Ember.run.later(()=>{
        Ember.$('.autocomplete-result').fadeOut();
      },500);
    },

    selectUserList(user){
      this.$('input').val(user.userName);
      this[this.action] = this.action;
      this.sendAction(this.action,user);
      Ember.$('.autocomplete-result').fadeOut();

    }
  }
});
