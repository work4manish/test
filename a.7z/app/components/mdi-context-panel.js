import Ember from 'ember';
import DomUtil from '../utils/dom-util';

export default Ember.Component.extend({
  coreDataService: Ember.inject.service(),
  name: '',
  renderTo: null,
  prependToRenderTo: null,
  filter: null,
  taget: null,
  prependToTarget: null,
  reduceWidthBy: 120,
  reduceHeightBy: 80,
  totalPadding: 40,
  // these properties will be used when contentType is grid STARTS
  contentType: 'grid',
  gridSettings: {
    totalColumnLayout: 12,
    totalColumns: 6,
    eachColumnSize: 1
  },
  // these properties will be used when contentType is grid ENDS
  showOn: 'click',
  serviceParams: null,
  contextPanelConfig: {
    orientation: 'vertical',
    alignToAnchor: true,
    //closeOnClick: true,
    animation: {
      open: {
        effects: "fadeIn"
      },
      duration: 500
    }
  },

  headerItems: null,
  detailItems: null,

  contextPanelStyle: Ember.computed('height', 'width', function() {
    let style = '';

    style += 'height:' + this.height + 'px;';
    style += 'width:' + this.width + 'px;';

    return Ember.String.htmlSafe(style);
  }),

  eventHandlers: {
    onOpen(event) {
      this.renderItems();
      this.$(event.item).css('display', 'none');
    },

    onActivate(event) {
      if (this.contentType === 'grid') {
        let offset = this.$(this.parent.element).find('.grid-container').offset();
        let contextPanelContainer = this.$(event.item.parentElement);

        contextPanelContainer.css('left', (offset.left + (this.reduceWidthBy / 2)) + 'px');
      } else {
        Ember.$(event.item).css('left', (this.reduceWidthBy / 2) + 'px');
      }

      this.$(event.item).css('display', 'block');
      this.enableTooltipForEllipsis();
    }
  },

  actions: {
    close() {
      this.contextPanel.close();
    }
  },

  init() {
    this.set('init', true);
    this._super();
    this.prepareContextPanelConfig();
    this.set('init', false);
  },

  didInsertElement() {
    this.contextPanel = Ember.$('#' + this.renderTo).kendoContextMenu(this.contextPanelConfig).data('kendoContextMenu');
  },

  prepareContextPanelConfig() {

    this.headerItems = Ember.A([]);
    this.detailItems = Ember.A([]);

    if (this.prependToTarget) {
      this.target = this.prependToTarget + this.target;
    }

    if (this.prependToRenderTo) {
      this.renderTo = this.prependToRenderTo + this.renderTo;
    }

    this.contextPanelConfig.filter = this.filter;
    this.contextPanelConfig.target = '#' + this.target;
    this.contextPanelConfig.showOn = this.showOn;

    let parentObject = Ember.$('#' + this.parentId);

    if (parentObject && !this.height) {
      this.set('height', parentObject.height() - this.reduceHeightBy);
    }

    if (parentObject) {
      this.set('width', parentObject.width() - this.reduceWidthBy);
    }


    if (this.serviceParams && this.serviceParams.gridId) {
      let gridId = this.serviceParams.gridId;

      this.serviceParams.gridId = '';
      this.serviceParams.gridId += gridId + '_Detail_Panel';
    }

    if (this.contentType === 'grid') {
      this.set('gridSettings.eachColumnSize', this.gridSettings.totalColumnLayout / this.gridSettings.totalColumns);
    }

    this.addEvents();
  },

  addEvents() {
    this.contextPanelConfig.open = this.eventHandlers.onOpen.bind(this);
    this.contextPanelConfig.activate = this.eventHandlers.onActivate.bind(this);
  },

  renderItems() {
    this.set('contentTypeGrid', false);
    this.set('contentTypeTooltip', false);

    if (this.contentType === 'grid') {
      this.fetchItems().then((customGridItem) => {
        let data = this.getContexPanelData(customGridItem);
        let headerItems = Ember.A(data.headerItems);
        let contentItems = Ember.A(data.contentItems);

        if (headerItems && headerItems.length > 0) {
          this.set('firstHeaderItem', headerItems.get(0));
          headerItems.removeAt(0);
          this.set('headerItems', headerItems);
        }

        if (contentItems && contentItems.length > 0) {
          this.set('contentItems', this.prepareContenItemJSON(contentItems));
        }

        this.set('contentTypeGrid', true);
      });
    } else if (this.contentType === 'tooltip') {
      this.set('contentTypeTooltip', true);
    }

    this.set('renderPanel', true);
  },

  fetchItems() {
    let serviceParams = this.serviceParams || {};
    let selectedRecord = this.parent.getSelectedRecord.apply(this.parent); //only for : this.contentType === 'grid'

    serviceParams.screenName = this.name;
    if (selectedRecord) {
      serviceParams.attributeId = selectedRecord.attributeId;
    }

    return this.get('coreDataService').queryRecord('base', serviceParams);
  },

  getContexPanelData(base) {
    let data = base.get('info');

    return data;
  },

  enableTooltipForEllipsis() {
    DomUtil.enableTooltip('div.header-item-label');
    DomUtil.enableTooltip('div.header-item-value');
    DomUtil.enableTooltip('div.content-item-label');
    DomUtil.enableTooltip('div.content-item-value');
  },

  /** This function will form the json such that if its a multiline data column width will be 12
      and the same column widht of the previous content will be adjusted.*/
  prepareContenItemJSON(rawContentItems) {
    let rowColInfo = {
      contentColItems: Ember.A([]),
      columnCounter: 1
    };

    let contentItems = Ember.A([]);
    let gridSettings = this.gridSettings;

    for (let i = 0, len = rawContentItems.length; i < len; i++) {
      let rawContentItem = rawContentItems[i];
      rawContentItem.columnSize = gridSettings.eachColumnSize;

      if (rawContentItem.multiline) {
        this.modifyPreviousContentItemWidth(rowColInfo);
        this.addMultilineRow(rawContentItem, contentItems, rowColInfo, gridSettings);
        continue;
      } else {
        rowColInfo.contentColItems.addObject(rawContentItem);
      }

      rowColInfo.columnCounter++;
      if (rowColInfo.columnCounter === gridSettings.totalColumns + 1) {
        this.addInitializeRow(contentItems, rowColInfo);
      }
    }

    if (rowColInfo.contentColItems && rowColInfo.contentColItems.length > 0) {
      this.addInitializeRow(contentItems, rowColInfo);
    }

    return contentItems;
  },

  addMultilineRow(rawContentItem, contentItems, rowColInfo, gridSettings) {
    rawContentItem.columnSize = gridSettings.totalColumnLayout;

    if (rowColInfo.columnCounter < gridSettings.totalColumns && rowColInfo.columnCounter !== 1) {
      this.addInitializeRow(contentItems, rowColInfo);
    }

    rowColInfo.contentColItems.addObject(rawContentItem);
    this.addInitializeRow(contentItems, rowColInfo);
  },

  addInitializeRow(contentItems, rowColInfo) {
    contentItems.addObject(rowColInfo.contentColItems);
    rowColInfo.contentColItems = Ember.A([]);
    rowColInfo.columnCounter = 1;
  },

  modifyPreviousContentItemWidth(rowColInfo) {
    let lastContentItem = rowColInfo.contentColItems.get(rowColInfo.contentColItems.length - 1);

    if (lastContentItem && !lastContentItem.multiline) {
      let gridSettings = this.gridSettings;
      let totalEmptyColumns = (gridSettings.totalColumns - rowColInfo.columnCounter) + 1;
      let newColumnSize = gridSettings.eachColumnSize + (gridSettings.eachColumnSize * (totalEmptyColumns));

      lastContentItem.columnSize = newColumnSize;
    }
  },

  willDistroy() {

  }
});
