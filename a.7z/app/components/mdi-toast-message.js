import Ember from 'ember';

export default Ember.Component.extend({
  toastActionLable:'GOT IT',
  toastIcon: 'mid-notifications',
  toastMsg:'',
  duration:2800,

  didInsertElement(){
    // Ember.run.later(()=>{
    //  this.$('.toast-container').fadeOut();
    // },this.duration);
  }
});
