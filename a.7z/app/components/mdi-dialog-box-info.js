import Ember from 'ember';

export default Ember.Component.extend({
  customClass: 'dialog-box-info',

  init() {
    this._super();
    this.set('customClassName', this.customClass + (this.customClassName ? ' ' + this.customClassName : ''));
  }
});
