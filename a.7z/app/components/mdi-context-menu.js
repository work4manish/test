import Ember from 'ember';
import MapActionMixin from '../mixins/map-action-mixin';

export default Ember.Component.extend(MapActionMixin, {
  name: '',
  renderTo: null,
  prependToRenderTo: null,
  filter: null,
  taget: null,
  prependToTarget: null,
  showOn: 'click',
  header: {
    menuItems: null,
    selected: null,
    checkedMenu: false,
    multiSelect: false
  },
  //menuItems: Ember.A([]),
  content: {
    menuItems: null,
    selected: null,
    checkedMenu: false,
    multiSelect: false
  },

  footer: {
    menuItems: null,
    selected: null,
    checkedMenu: false,
    multiSelect: false
  },

  /*deselectableConfig: {
    content_footer: false
  },*/

  selected: Ember.A([]),
  lastClickedMenuItem: null,
  optionLabelPath: 'title',
  optionValuePath: 'id',

  sendActionOnChange: Ember.observer('selected.length', function() {
    if (this.onChange && !this.get('init')) {
      this.sendAction(this.onChange, this.selected, this.lastClickedMenuItem);
    }
  }),

  actions: {
    onMenuItemClick(menuItem, section) {
      this.updateSelected(menuItem, section);

      if (this.onMenuItemClick) {
        this.sendAction(this.onMenuItemClick, this.lastClickedMenuItem, this.content.menuItems, this.selected, this.header, this.footer);
      }
    }
  },

  init() {
    this.set('init', true);
    this._super();
    this.mapAction('onChange');
    this.mapAction('onMenuItemClick');

    if (this.prependToTarget) {
      this.set('target', this.prependToTarget + this.target);
    }

    if (this.prependToRenderTo) {
      this.set('renderTo', this.prependToRenderTo + this.renderTo);
    }

    if (this.headerMenuItems) {
      this.set('header.menuItems', Ember.A(this.headerMenuItems));

      delete this.headerMenuItems;
    }

    let menuItems = this.contentMenuItems || this.menuItems;
    if (menuItems) {
      this.set('content.menuItems', Ember.A(menuItems));
      delete this.contentMenuItems;
      delete this.menuItems;
    }

    if (this.footerMenuItems) {
      this.set('footer.menuItems', Ember.A(this.footerMenuItems));

      delete this.footerMenuItems;
    }

    this.initializeSelectedItems();
    this.set('init', false);
  },

  initializeSelectedItems() {
    this.selected.clear();
    this.set('selected', this.getCheckedItemsFor(this.content.menuItems));

    if (this.content && this.content.menuItems) {
      this.content.selected = Ember.A([]);
      this.content.selected = this.getCheckedItemsFor(this.content.menuItems);
    }

    if (this.header && this.header.menuItems) {
      this.header.selected = Ember.A([]);
      this.header.selected = this.getCheckedItemsFor(this.header.menuItems);
    }

    if (this.footer && this.footer.menuItems) {
      this.footer.selected = Ember.A([]);
      this.footer.selected = this.getCheckedItemsFor(this.footer.menuItems);
    }
  },

  getCheckedItemsFor(list) {
    var selectedItems = Ember.A([]);
    for (let i = 0, len = list.length; i < len; i++) {
      let item = list[i];

      if (item.isChecked) {
        selectedItems.addObject(item);
      }
    }

    return selectedItems;
  },

  didInsertElement() {
    this.contextMenu = Ember.$('#' + this.renderTo).kendoContextMenu({
      orientation: "vertical",
      target: '#' + this.target,
      alignToAnchor: true,
      //closeOnClick: true,
      filter: this.filter,
      animation: {
        open: {
          effects: "fadeIn"
        },
        duration: 500
      },
      showOn: this.showOn
    }).data('kendoContextMenu');
  },

  updateSelected(menuItem, section) {
    let selected;
    let operation = menuItem.isChecked ? 'deselect' : 'select';
    this.lastClickedMenuItem = menuItem;

    Ember.set(menuItem, 'isChecked', !menuItem.isChecked);

    if (this.checkedMenu) {
      selected = this.selected;
    } else if (this.header && this.header.menuItems && this.header.menuItems.length > 0 ||
      this.footer && this.footer.menuItems && this.footer.menuItems.length > 0) {

      if (section === 'content' || section === 'header' || section === 'footer') {
        selected = this[section].selected;
      } else {
        selected = this.selected;
      }
    }

    if (this.checkedMenu || this[section].multiSelect) {
      if (operation === 'deselect') {
        let selectedItem = selected.findBy(this.optionLabelPath, menuItem[this.optionLabelPath]);
        Ember.set(selectedItem, 'isChecked', false);
        selected.removeObject(selectedItem);
      } else {
        selected.addObject(menuItem);
      }
    } else {
      this.deselectAllExcept(menuItem, section);
    }
  },

  deselectAllExcept(currentMenuItem, section) {
    let menuSection = this[section] || this;
    let menuItems = menuSection.menuItems;
    let selected = menuSection.selected || this.selected;

    for (let i = 0, len = menuItems.length; i < len; i++) {
      let menuItem = menuItems[i];

      if (menuItem[this.optionValuePath] === currentMenuItem[this.optionValuePath]) {
        continue;
      }

      if (menuItem.isChecked) {
        Ember.set(menuItem, 'isChecked', false);
      }
    }

    selected.clear();

    if (currentMenuItem.isChecked) {
      selected.addObject(currentMenuItem);
    } else if (!this.shouldAllowDeselect(menuSection, section)) {
      Ember.set(currentMenuItem, 'isChecked', true);
      selected.addObject(currentMenuItem);
    }
  },

  shouldAllowDeselect(menuSection, currentSection) {
    let allowDeselect = true;
    let deselectableConfigApplied = false;

    if (menuSection && menuSection.deselectable === false) {
      allowDeselect = false;
    } else if (this.deselectableConfig) {
      let selectedItemsSize = 0;

      for (let key in this.deselectableConfig) {
        if (key.indexOf(currentSection) > -1) {
          deselectableConfigApplied = true;

          let combinations = key.split('_');
          selectedItemsSize = 0;

          for (let i = 0; i < combinations.length; i++) {
            let combinationItem = combinations[i];

            selectedItemsSize = this.getSelectedMenuItemsFor(combinationItem).length;

            if (selectedItemsSize > 0) {
              break;
            }
          }
        }
      }

      if (deselectableConfigApplied && !selectedItemsSize) {
        allowDeselect = false;
      }
    }

    return allowDeselect;
  },

  getSelectedMenuItems() {
    if (this.content.menuItems || this.header.menuItems || this.footer.menuItems) {
      let selected = this.getSelectedMenuItemsFor('content');
      return {
        header: this.getSelectedMenuItemsFor('header'),
        menuItems: selected,
        content: selected,
        footer: this.getSelectedMenuItemsFor('footer')
      };
    } else {
      return this.selected;
    }
  },

  getSelectedMenuItemsFor(type) {
    if (this[type] && this[type].menuItems) {
      return this[type].selected;
    }

    return [];
  },

  updateIdForMenuItem(title, newId, type) {
    let menuItems = type ? this[type].menuItems : this.content.menuItems;

    for (let i = 0, len = menuItems.length; i < len; i++) {
      let menuItem = menuItems[i];

      if (title === menuItem[this.optionLabelPath]) {
        Ember.set(menuItem, this.optionValuePath, newId);

        return;
      }
    }
  },

  willDistroy() {
    console.log('removed attached events');
    this.selected.clear();
    this.header = null;
    this.footer = null;
    this.content = null;
    this.contextMenu = null;
  }
});
