import Ember from 'ember';


export default Ember.Component.extend({
  store: Ember.inject.service(),
  errors: 'Auto-populated based on PSID',
  userInfo: null,
  isAddUserRoleAction: true,

  actions: {

    onPsidSelect(user) {
      this.fetchUserInfo(user.userPsId);
    },

    removeUserInfo() {
      this.set('userInfo', []);
      Ember.$('.profile-wrapper label').removeClass('active');
      this.get('roleModel').set('userPsId', null);
    }
  },

  didInsertElement() {
    if (this.get('roleModel').get('actionType') === 'updateUserRole') {
      Ember.$('.profile-wrapper label').addClass('active');
      this.setProperties({
        isAddUserRoleAction: false,
        //errors: null
      });
    }

  },

  fetchUserInfo(psid) {
    this.get('store').findRecord('admin-user-info', psid).then((userInfo) => {

      this.get('roleModel').set('userPsId', psid); //seting userPSID in created model.

      Ember.$('.profile-wrapper label').addClass('active');
      this.setProperties({
        userInfo: userInfo
      });
    });
  }
});
