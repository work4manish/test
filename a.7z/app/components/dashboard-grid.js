import Ember from 'ember';
import AppConst from '../utils/app-const';
import ObjectUtil from '../utils/object-util';


export default Ember.Component.extend({
  coreDataService: Ember.inject.service(),
  store: Ember.inject.service(),
  serviceParams: null,
  modelName: 'base',
  refreshGrid: false,
  durationFilters: null,
  pageFilters: null,

  serviceParamsObserver: Ember.observer('serviceParams', 'serviceParams.pageFilter', 'serviceParams.durationFilter', function() {

    if (!this.serviceParamsObserverInProgress && this.dashboardGrid) {
      this.serviceParamsObserverInProgress = true;
      this.updateServiceParams();
      this.set('dashboardGrid.refreshGrid', true);
      this.fetchChartData();

      Ember.run.next(() => {
        this.set('dashboardGrid.refreshGrid', false);
        this.serviceParamsObserverInProgress = false;
      });
    }
  }),

  actions: {
    onTabChange( /*selected*/ ) {
      this.updateServiceParams();
    },

    onPageFilterChange(selected) {
      ObjectUtil.resetAll(this.pageFilters, 'selected', false);
      ObjectUtil.updateAttributeWhere('id', selected, 'selected', true, this.pageFilters);
      this.updateServiceParams();
    },

    showDetails(selectedItem) {
      this.openDetailGridDialog(selectedItem);
    }
  },

  init() {
    this._super();
    this.fetchChartData();

    this.fetchGridData().then((response) => {
      let info = response.get('info');
      let filters = info.filter;

      if (filters) {
        this.durationFilters = filters.durationFilter ? Ember.A(filters.durationFilter) : Ember.A([]);
        this.pageFilters = filters.regularFilter ? Ember.A(filters.regularFilter) : Ember.A([]);
      } else {
        //REMOVE THIS AFTER SERVER SIDE IMPLEMENTATION
        this.durationFilters = info.durationFilter ? Ember.A(info.durationFilter) : Ember.A([]);
      }

      let gridConfig = info.gridItem.gridConfig;
      gridConfig.modelName = this.modelName;
      gridConfig.gridItemRoot = 'info';
      gridConfig.noResetRefreshRequired = true;

      var detailGridServiceParams = this.prepareDetailGridServiceParams();

      if (!this.isDestroyed) {
        this.setProperties({
          'dashboardGrid': {
            gridTitle: info.gridTitle,
            filterItems: this.durationFilters,
            selectedFilter: this.getSelectedItem(this.durationFilters),
            pageFilterItems: this.pageFilters,
            selectedPageFilter: this.getSelectedItem(this.pageFilters),
            gridConfig: info.gridItem.gridConfig,
            gridData: info.gridItem.gridData,
            gridServiceParams: this.getServiceParams(),
            detailGridServiceParams: detailGridServiceParams,
            refreshGrid: this.refreshGrid
          },

          detailDialogConfig: {
            onOk: this.closeDetailGridDialog,
            callbackContext: this
          }
        });
        this.set('loaded', true);
      }
    });
  },

  setDashboardChart(chartInfo) {
    let chartData = chartInfo.chartData;
    let config = Ember.Object.create(chartInfo.chartConfig);
    let chartSeries = this.prepareChartData(chartData.chartSeries);
    let totalTitle = chartData.chartTitle;
    this.setProperties({
      chartData: chartSeries,
      chartConfig: config,
      chartLoading: false,
      isDisplayChart: true,
      label: totalTitle ? totalTitle.label : null,
      totalCount: totalTitle ? totalTitle.value : null,
      noDataFoundMessage: config.noDataFoundMessage ? config.noDataFoundMessage : 'No data found!'
    });
  },

  fetchGridData() {
    return this.get('coreDataService').queryRecord(this.modelName, this.getServiceParams());
  },

  fetchChartData() {
    if (this.get('isChartViewAvailable')) {
      let chartParams = this.getServiceParams();
      chartParams.urlType = 'chartview';
      this.set('chartLoading', true);
      this.get('coreDataService').queryRecord(this.modelName, this.getServiceParams()).then((response) => {
        this.setDashboardChart(response.get('info').chartView);
      });
    }
  },

  prepareChartData(chartData) {

    var newChartSeries = [];

    if (chartData) {
      var seriesCount = chartData.length;
      chartData.forEach(function(items) {
        items.dataItems.forEach(function(item) {

          if (items.name) {
            item.name = items.name;
          }
          if (items.title) {
            item.title = items.title;
          }

          if (items.ragColor) {
            item.ragColor = items.ragColor;
          }

          if (items.color) {
            item.color = items.color;
          }

          if (items.attributeId) {
            item.seriesCode = items.attributeId;
          }

          item.seriesCount = seriesCount;

          newChartSeries.push(item);
        });
      });
    }

    return Ember.A(newChartSeries);
  },

  getServiceParams() {
    let serviceParams = this.serviceParams || {};

    if (!this.isDestroyed) {
      if (!this.serviceParams) {
        this.set('serviceParams', serviceParams);
      }

      this.set('serviceParams.gridId', this.getGridId());

      if (this.durationFilters) {
        this.set('serviceParams.durationFilter', this.getSelectedItem(this.durationFilters));
      } else {
        this.set('serviceParams.durationFilter', '');
      }

      if (this.pageFilters) {
        this.set('serviceParams.pageFilter', this.getSelectedItem(this.pageFilters));
      } else {
        this.set('serviceParams.pageFilter', '');
      }

      this.set('serviceParams.screenName', 'generalDashboard');
    }

    return serviceParams;
  },

  prepareDetailGridServiceParams() {
    let detailGridServiceParams = Ember.copy(this.getServiceParams(), true);
    detailGridServiceParams.screenName = 'generalDashboardDetailGrid';

    return detailGridServiceParams;
  },

  getGridId(isDetailGrid) {
    var roleName = this.serviceParams.roleName;
    var gridId = this.serviceParams.dashboardId + '_' + (roleName === AppConst.LINE_MANAGER ? 'Linamanager' : 'RoleBased') + '_Grid';

    if (isDetailGrid) {
      gridId += '_Detail';
    }

    return gridId;
  },


  getSelectedItem(filterItems) {
    if (filterItems) {
      let selectedFilter = filterItems.findBy('selected', true);

      if (selectedFilter) {
        return selectedFilter.id;
      }
    }

    return '';
  },

  updateServiceParams() {
    let serviceParams = this.getServiceParams();

    this.set('dashboardGrid.gridServiceParams', serviceParams);
    this.set('dashboardGrid.detailGridServiceParams', this.prepareDetailGridServiceParams());
  },


  openDetailGridDialog(selectedItem) {
    this.set('dashboardGrid.selectedRowId', selectedItem.attributeId);
    this.set('showDetailGridDialog', true);
  },

  closeDetailGridDialog() {
    this.set('showDetailGridDialog', false);
  },
});
