import Ember from 'ember';
import MapActionMixin from '../mixins/map-action-mixin';

export default Ember.Component.extend(MapActionMixin, {
  classNames: ['mdi-input'],

  actions: {
    onKeyUp(val) {
      this.sendAction(this.action, val)
    },
  },

  init() {
    this._super();
    this.mapAction('action');
  }
});
