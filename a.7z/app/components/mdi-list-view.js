import Ember from 'ember';
import MapActionMixin from '../mixins/map-action-mixin';

export default Ember.Component.extend(MapActionMixin, {
  columns: [],
  data: [],
  onRowClick: '',
  rowClass: 'list-view-row',

  dataObserver: Ember.observer('data', function() {

  }),

  actions: {
    rowClick(selectedRowId) {
      if (this.onRowClick) {
        this.sendAction('onRowClick', selectedRowId);
      }
    }
  },

  init() {
    this._super();
    this.mapAction('onRowClick');
  },

  click(event) {
    if (this.action) {
      this.sendAction('action', event);
    }
  }
});
