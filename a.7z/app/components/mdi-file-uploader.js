import Ember from 'ember';

export default Ember.Component.extend({
  init() {
    this._super();
    this.insertOverLay();
  },

  didInsertElement() {

  },

  insertOverLay() {

  }
});
