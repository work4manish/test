import Ember from 'ember';
import ComponentReferenceExport from '../mixins/component-reference-export';
import MapActionMixin from '../mixins/map-action-mixin';

var get = Ember.get;

export default Ember.Component.extend(ComponentReferenceExport, MapActionMixin, {
  classNames: ['mdi-select2-div'],
  allValue: 'ALL',
  placeHolder: '',
  multiple: false,
  allowClear: false,
  searchEnabled: true,
  optionIdPath: 'id',
  optionLabelPath: 'title',
  optionLabelSelectedPath: null,
  optionValuePath: null,
  optionHeadlinePath: 'title',
  optionDescriptionPath: 'description',
  placeholder: null,
  value: '',
  typeaheadErrorText: "Loading failed...",
  typeaheadNoMatchesText: "No items found for '%@'",
  typeaheadSearchingText: "Searching items",
  queryAction: null,
  formatResult: null,
  formatSelection: null,
  valueSeparator:',',
  minimumInputLength: 0,
  hightlightClass: "highlight",
  selectedValues: [],
  customAction: null,
  debounceTime: 500,

  /* Info message to display **/
  infoMessage: null,

  focus() {
    try {
      var select2Instance = this.getSelectInstance();
      select2Instance.focus();
    } catch (e) {}
  },

  focusIn() {
    this.$().addClass("is-active is-completed");
  },

  click() {
    this.$().addClass("is-active is-completed");
  },

  focusOut() {
    if (this.$('input').eq(1).val() === '') {
      this.$().removeClass('is-completed');
    }
    this.$().removeClass("is-active");
    //console.log(Ember.$('.select2-drop.select2-drop-active'))
  },

  setCompleted: Ember.on('didUpdate', function() {
    if (this.get('value')) {
      Ember.$(this.get('element')).addClass("is-completed");
    }
  }),


  /*
   * Hack to fix initial data binding issue, when using ember select with server side filering
   */
  init() {

    if (!this.get('optionHeadlinePath')) {
      this.set('optionHeadlinePath', this.get('optionLabelPath') || this.get('optionIdPath'));
    }

    if (this.get('config.allowClear') === false) {
      this.allowClear = false;
    }

    this.mapAction('customAction');
    this.handleAllSelect();
    return this._super();
  },


  /**
   * didInsertElement.
   * @override
   */
  didInsertElement() {
     var select2Overrides = this.container.lookup('Select2Overrides:main');
     var select2Instance = this.getSelectInstance();
    //Do also custom overidding only, when select2 succesfully created. To avoid infinite looping
    if (select2Instance != null) {
      this.setCustomInitSelection();
      if (this.formatResult) {
        this.setCustomResultFormatter();
      }
      if (this.formatSelection) {
        this.setCustomSelectionFormatter();
      }
      if (this.onSelection) {
        this.setCustomSelectHandler();
      }
      if (this.get('valueTemp')) {
        this.set('value', this.valueTemp);
        select2Instance.data(this.value);
      }
      if (this.multiple === true && this.hasMany === true) {
        this.addObserver('selectedValues', this.selectedValuesObserver);
        //this.addObserver('value', this.valuesObserver);
        //this.selectedValuesObserver();
      } else {
        this.addObserver('value', this.valuesObserver);
      }
      //if (this.get('multiple') === true) {
      if (select2Instance.container !== null) {
        select2Instance.dropdown.on('mouseleave', function( /*e*/ ) {
            select2Instance.close(true);
          });

           select2Instance.container.off('click').on('click', ".select2-choices", select2Overrides.select2ContainerClick.bind(this.getSelectInstance()));
          // this.getSelectInstance().container.resize(select2Overrides.select2Resize.bind(this.getSelectInstance()));
          // this.$(window).resize(select2Overrides.select2Resize.bind(this.getSelectInstance()));
      }

      this.registerOnClearHandler();
    }

    return this._super();
  },

  willDestroyElement() {
    if (this.get('multiple') === true) {
      this.$(window).off('resize');
    }
    if (this.multiple === true && this.hasMany === true) {
      this.removeObserver('selectedValues', this.selectedValuesObserver);
    } else {
      this.removeObserver('value', this.valuesObserver);
    }
  },
  _handleQueryAction: function() {
    var query = this.get('_query'),
      deferred = this.get('_deferred');
    this.send('queryAction', query, deferred);
  },
  actions: {
    /*
    This is proxy method for queryAction, which will be called prior to queryAction
    It debounces and calls queryAction subsequently. To avoid multiple calls to queryAction
    */
    _proxyQueryAction(query, deferred) {
      this.set('_query', query);
      this.set('_deferred', deferred);
      /**
      Debouncing, to delay sending queryAction to avoid multiple service call, as user types in search
      **/
      Ember.run.debounce(this, this._handleQueryAction, this.debounceTime);
    },
    queryAction(query, deferred) {
      this.sendAction('queryAction', query, deferred);
    }
  },
  /*
   * Enable selectbox only when readonly and disabled is not true
   */
  enabled: Ember.computed("disabled", "readonly", {
    get() {
      var readonly = this.get('readonly'),
        disabled = this.get('disabled');
      if (readonly === true || readonly === 'true') {
        return false;
      }
      return !(disabled === true || disabled === 'true');
    }
  }),

  query: Ember.computed("queryAction", {
    get() {
      if (Ember.isEmpty(this.get('queryAction'))) {
        return null;
      } else {
        return '_proxyQueryAction';
      }
    }
  }),

  onSelection(model) {
    try {
      let customAction = this.get('customAction');
      let oldValue;
      let newValue = model instanceof Ember.Object ? model.get(this.get('optionIdPath')) : model[(this.get('optionIdPath'))];

      this.handleAllSelect(newValue);

      if (customAction) {
        if (model != null) {
          oldValue = this.get('value');

          if (oldValue === newValue && Ember.isEmpty(newValue) === false) {
            return;
          }
        }
        if (this.multiple !== true && this.hasMany !== true) {
          this.sendAction(this.customAction, model);
        }
      }
    } catch (e) {
      Ember.Logger.debug(e);
    }
  },
  /*
   * This method traves through the fomatted result , and
   * finds the search text and highlights it
   */
  hightlightHTML(node, pat) {
    var skip = 0,
      pos, spannode, middlebit, middleclone, i;
    if (node.nodeType === 3) {
      pos = node.data.toUpperCase().indexOf(pat);
      if (pos >= 0) {
        spannode = document.createElement('span');
        spannode.className = this.hightlightClass;
        middlebit = node.splitText(pos);
        middlebit.splitText(pat.length);
        middleclone = middlebit.cloneNode(true);
        spannode.appendChild(middleclone);
        middlebit.parentNode.replaceChild(spannode, middlebit);
        skip = 1;
      }
    } else if (node.nodeType === 1 && node.childNodes) {
      for (i = 0; i < node.childNodes.length; ++i) {
        i += this.hightlightHTML(node.childNodes[i], pat);
      }
    }
    return skip;
  },
  /*
   * When custom format is provided for result
   * select2 options is retrived and formatResult method
   * is replaced with the provided method
   */
  setCustomResultFormatter() {
    this.getSelectInstance().opts.formatResult = function(data, container, query) {
      var formattedResult = this.formatResult(data),
        dom;
      if (typeof formattedResult === "string") {
        dom = document.createElement('div');
        dom.innerHTML = formattedResult;
      } else {
        dom = formattedResult;
      }
      if (query && query.term) {
        this.hightlightHTML(dom, query.term.toUpperCase());
      }
      return dom;
    }.bind(this);
  },
  /*
   * When custom format is provided for selection
   * select2 options is retrived and formatSelection method
   * is replaced with the provided method
   */
  setCustomSelectionFormatter() {
    this.getSelectInstance().opts.formatSelection = function(data) {
      if (data !== null && data !== undefined) {
        return this.formatSelection(data);
      }
    }.bind(this);
  },
  setCustomInitSelection() {
    this.getSelectInstance().opts.initSelection = function(element, callback) {
      if (element !== null && element !== undefined) {
        return this.onInitSelection(element, callback);
      }
    }.bind(this);
  },

  onInitSelection(element, callback){
    var value = element.val(),
          content = this.get("content"),
          contentIsArrayProxy = content instanceof Ember.Object,
          multiple = this.get("multiple"),
          optionValuePath = this.get("optionValuePath") || this.get("optionIdPath")  ;

      if (!value || !value.length) {
        return callback([]);
      }

      // this method should not be needed without the optionValuePath option
      // but make sure there is an appropriate error just in case.
      Ember.assert("select2#initSelection has been called without an \"" +
        "optionValuePath\" set.", optionValuePath);

      Ember.assert("select2#initSelection can not map string values to full objects " +
        "in typeahead mode. Please open a github issue if you have questions to this.",
        !this.get('_typeaheadMode'));


      var values;
      var filteredContent = [];

      // only split select2's string value on valueSeparator when in multiple mode
      if (this.get('multiple')) {
        var separator = this.get('valueSeparator');
        values = value.split(separator);
      } else {
        values = [value];
      }

      // for every object, check if its optionValuePath is in the selected
      // values array and save it to the right position in filteredContent
      var contentLength = get(content, 'length'),
          unmatchedValues = values.length,
          matchIndex,
          loop = 0;

      // START loop over content
      for (var i = 0; i < contentLength; i++) {
        var item = contentIsArrayProxy ? content.objectAt(i) : content[i];
        matchIndex = -1;

        if (item.children && item.children.length) {
          // take care of either nested data...
          for (var c = 0; c < item.children.length; c++) {
            var child = item.children[c];
            matchIndex = values.indexOf("" + get(child, optionValuePath));
            if (matchIndex !== -1) {
              filteredContent[loop++] = child;
              unmatchedValues--;
            }
            // break loop if all values are found
            if (unmatchedValues === 0) {
              break;
            }
          }
        } else {
          // ...or flat data structure: try to match simple item
          matchIndex = values.indexOf("" + get(item, optionValuePath));
          if (matchIndex !== -1) {
            filteredContent[loop++] = item;
            unmatchedValues--;
          }
          // break loop if all values are found
          if (unmatchedValues === 0) {
            break;
          }
        }
      }
      // END loop over content

      if (unmatchedValues === 0) {
        this.set('_hasSelectedMissingItems', false);
      } else {
        // disable the select2 element if there are keys left in the values
        // array that were not matched to an object
        this.set('_hasSelectedMissingItems', true);

        Ember.warn("select2#initSelection was not able to map each \"" +
          optionValuePath +"\" to an object from \"content\". The remaining " +
          "keys are: " + values + ". The input will be disabled until a) the " +
          "desired objects is added to the \"content\" array or b) the " +
          "\"value\" is changed.", !values.length);
      }

      if (multiple) {
        // return all matched objects
        return callback(filteredContent);
      } else {
        // only care about the first match in single selection mode
        return callback(filteredContent[0]);
      }
  },
  /*
   * When custom select handler is passed, When any selection is selected,
   * Custom select handler called
   */
  setCustomSelectHandler() {
    var select2 = this.getSelectInstance(),
      self = this;
    select2.onSelect = (function(onSelect) {

      return function( /*data, event*/ ) {
        self.onSelection.apply(self, arguments);
        return onSelect.apply(this, arguments);
      };
    })(select2.onSelect);
  },
  /*
   * Method to retrive actual jquery select2 instance
   */
  getSelectInstance() {
    if (this.select2Instance === undefined) {
      this.select2Instance = this.$().find('input.form-control').data('select2');
    }
    return this.select2Instance;
  },
  registerOnClearHandler() {
    this.$().find('input.form-control').on('select2-removed', function() {
      if (this.customAction && typeof(this.customAction) === 'string') {
        //this.sendAction(this.customAction, undefined);
      }
    }.bind(this));
  },
  /* When in multiple mode true, and hasMany as true
  The observer observes for selected values,
  and according add selected values to ember model object properly */
  selectedValuesObserver() {
    var model = this.get('modelValue'),
      modelKey = this.get('modelValueKey'),
      selectedValues = this.get('selectedValues');
    if (!Ember.isEmpty(model)) {
      model.set(modelKey, []);
      if (selectedValues && selectedValues.length) {
        model.set(modelKey, selectedValues);
      }
    }
    if (this.customAction) {
      this.sendAction(this.customAction, this.selectedValues, true);
    }
    this.handleAllSelect();
  },
  /* When in multiple mode true, and hasMany as true
  The observer observes for value change,
  and according modify selected values */
  valuesObserver( /*value*/ ) {
    var model = this.get('modelValue'),
      modelKey = this.get('modelValueKey'),
      selectedValue = this.get('value');

    if (!Ember.isEmpty(model)) {
      model.set(modelKey, []);
      if (selectedValue) {
        model.set(modelKey, [selectedValue]);
      }
    }
  },

  handleAllSelect(selectedValue) {
    let selected = this.selectedValues;
    let isEmberObject = this.content instanceof Ember.Object;
    let listItems = isEmberObject ? this.content.toArray() : this.content;

    if (selected && selected.length === 0) {
      for (let i = 0; i < listItems.length; i++) {
        let listItem = listItems[i];

        Ember.set(listItem, 'disabled', false);
      }

      if (selectedValue && selectedValue.toUpperCase() === this.allValue) {
        //Ember.A(selected).clear();
        for (let i = 0; i < listItems.length; i++) {
          let listItem = listItems[i];

          Ember.set(listItem, 'disabled', true);
        }
      }

      return;
    }

    if (selected && selected.length > 0) {
      let selectedItem;
      let selectedItemValue;

      if (selected.length === 1) {
        selectedItem = selected[0];
        selectedItemValue = selectedItem.get ? selectedItem.get(this.optionIdPath) : selectedItem[this.optionIdPath];
      }

      if (selectedItemValue && selectedItemValue.toUpperCase() === this.allValue) {
        for (let i = 0; i < listItems.length; i++) {
          let listItem = listItems[i];
          let value = isEmberObject ? listItem.get(this.optionIdPath) : listItem[this.optionIdPath];

          if (value.toUpperCase() !== this.allValue) {
            Ember.set(listItem, 'disabled', true);
          }
        }
      } else {
        for (let i = 0; i < listItems.length; i++) {
          let listItem = listItems[i];
          let value = isEmberObject ? listItem.get(this.optionIdPath) : listItem[this.optionIdPath];

          if (value && value.toUpperCase() === this.allValue) {
            Ember.set(listItem, 'disabled', true);

            break;
          }
        }
      }
    }
  }
});
