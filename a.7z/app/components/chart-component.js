import Ember from 'ember';
import layout from '../templates/components/chart-component';
import ConvertToJSON from '../mixins/convert-to-json';
import CssConst from '../utils/css-const';
import ChartConst from '../utils/chart-const';


export default Ember.Component.extend(ConvertToJSON, {
  layout: layout,
  classNames: ['chartview'],
  showToolTip: false,
  chartInstance: null,
  chartData: [],
  chartLoading: false,
  supDashConfig: true,
  chartDataSourceConfig: {},
  noDataFoundMessage: 'No Data Found',
  staticSeriesWidth: true,
  seriesShiftDistace: 0,

  init() {
    this._super();
    let chartConfigObj = this.get('chartConfig');
    if (this.get('supDashConfig') && !Ember.isEmpty(chartConfigObj) && chartConfigObj.get('xAxis')) {
      this.buildSupdashConfig(chartConfigObj);
    } else if (this.get('supDashConfig')) {
      this.set('chartConfig', {});
    }
  },

  willInsertElement() {
    this.$('.chartview').kendoChart(this.get('chartConfig'));
    this.chartInstance = this.$('.chartview').data("kendoChart");

    this.chartInstance.bind("dataBound", function(e) {
      this.setDataBoundForChart(e);
    }.bind(this));
    this.chartInstance.bind("render", function(e) {
      this.setOnRenderHanlder(e);
    }.bind(this));
    this.chartInstance.bind("seriesHover", function( /*e*/ ) {
      //$(".chartview").css("cursor", "pointer");
      Ember.run.next(() => {
        if (this.chartType.toUpperCase() === 'BAR') {
          Ember.$('.k-tooltip').css({
            'margin-top': 2 * this.seriesShiftDistace
          });
        }
      });


    }.bind(this));

    this.$(window).resize(() => {
      if (!Ember.isEmpty(this.chartInstance)) {
        //this.chartInstance.options.transitions = false;
        this.chartInstance.refresh();
      }
    });
    this.doDraw();
    this._super();
  },

  didInsertElement() {
    if (!Ember.isEmpty(this.chartInstance)) {
      this.chartInstance.resize();
    }
  },

  doDraw: Ember.observer('chartData', function() {
    var chartData = this.get('chartData');
    this.categorySelected = false;
    if (chartData && this.$('.chartview')) {
      this.chartInstance = this.$('.chartview').data("kendoChart");
      this.set('noDataFoundMessage', this.get('noDataFoundMessage'));
      this.get('chartConfig').dataSource = {
        data: this.convertToJSON(chartData)
      };
      this.prepareDataSourceConfig(this.get('chartConfig'), this.get('chartDataSourceConfig'));
      if (!this.chartInstance) {
        this.$('.chartview').kendoChart(this.get('chartConfig'));
        this.chartInstance = this.$('.chartview').data("kendoChart");
      }
      this.chartInstance.setDataSource(this.get('chartConfig').dataSource);
      this.chartInstance.options.categoryAxis.labels.color = CssConst.LABELS_COLOR;
      this.chartInstance.redraw();
    } else if (chartData) {
      this.get('chartConfig').dataSource = {
        data: this.convertToJSON(chartData)
      };
      this.prepareDataSourceConfig(this.get('chartConfig'), this.get('chartDataSourceConfig'));
    }
    return true;
  }),

  buildSupdashConfig(graphConfig) {

    this.chartType = graphConfig.get('type');
    //For setting x-axis and y-axis
    let xAxis = graphConfig.get('xAxis');
    let yAxis = graphConfig.get('yAxis');
    let xAxisLabel = graphConfig.get('xAxisDisplayName') || xAxis;

    //group by config
    let groupBy = graphConfig.get('groupBy') || false;
    let isGrouping = groupBy ? true : false;
    let stackFlag = graphConfig.get('stack') || false;
    let legendPosition = graphConfig.get('legend') || 'bottom';

    let chartConfigObj = {};
    chartConfigObj.theme = 'bootstrap';
    chartConfigObj.tooltip = {
      background: "black",
      visible: true,
      template: this.createToolTipTemplate.bind(this, groupBy)
    };
    chartConfigObj.legend = this.createLegendConfig(this.chartType, legendPosition);
    chartConfigObj.categoryAxis = this.createCategoryConfig(this.chartType);
    chartConfigObj.series = this.createSeriesConfig(this.chartType, yAxis, stackFlag, xAxisLabel);
    chartConfigObj.valueAxis = this.createValueAxisConfig(this.chartType);
    chartConfigObj.pannable = {
      lock: (this.chartType.toUpperCase() === "BAR") ? 'x' : 'y'
    };

    chartConfigObj.chartArea = {
      height: ChartConst.CHART_HEIGHT
    };

    if (this.chartType.toUpperCase() === 'COLUMN' || this.chartType.toUpperCase() === 'LINE') {
      chartConfigObj.chartArea.margin = ChartConst.CHART_MARGIN;
    }

    //Action handler
    let axisClickAction = graphConfig.get('axisClick');
    let seriesClickAction = graphConfig.get('seriesClick');
    let legendClickAction = graphConfig.get('legendClick');

    if (!legendClickAction) {
      chartConfigObj.legendItemClick = this.onLegendItemClick.bind(this);
    }

    if (seriesClickAction) {
      this[seriesClickAction] = seriesClickAction;
      chartConfigObj.seriesClick = this.onSeriesClick.bind(this, seriesClickAction);
    }

    if (axisClickAction) {
      this[axisClickAction] = axisClickAction;
      chartConfigObj.axisLabelClick = this.onAxisClick.bind(this, axisClickAction);
    }

    let chartDataSourceConfigObj = {};
    chartDataSourceConfigObj.isGrouping = isGrouping;
    chartDataSourceConfigObj.groupField = groupBy;

    this.setProperties({
      chartConfig: chartConfigObj,
      chartDataSourceConfig: chartDataSourceConfigObj,
    });
  },

  createLegendConfig(type, position) {
    let legendconfig = {};
    type = type.toUpperCase();
    legendconfig.position = position;
    legendconfig.labels = {
      color: CssConst.LABELS_COLOR,
      font: CssConst.FONT_XS + ' ' + CssConst.FONT_FAMILY,
      margin: {
        bottom: 10
      },
      template: "#: text.toUpperCase() #"
    };
    legendconfig.markers = {
      type: "circle",
      width: 7,
      margin: {
        bottom: 10
      },
    };
    if (type === "DONUT") {
      legendconfig.offsetX = -20;
    }
    if (type === "BAR") {
      legendconfig.offsetY = 10;
    }
    if (type === "COLUMN" && position !== 'bottom') {
      legendconfig.offsetX = 10;
      legendconfig.offsetY = -60;
    }
    return legendconfig;
  },

  createValueAxisConfig(type) {
    let chartType = type.toUpperCase();
    let valueAxis = {
      labels: {
        visible: (chartType !== "BAR"),
        color: CssConst.VALUE_AXIS_COLOR,
        font: CssConst.FONT_XS + ' ' + CssConst.FONT_FAMILY,
        template: "#= kendo.format('{0:N0}', value) #"
      },
      line: {
        visible: (chartType === "BAR")
      }
    };

    return valueAxis;
  },

  createSeriesConfig(type, value, stack, categoryAxis) {
    let series = [];
    let seriesObj = {};
    let chartType = type.toUpperCase();
    seriesObj.field = value;
    seriesObj.type = type;
    seriesObj.border = {
      width: 0
    };
    seriesObj.colorField = "color";
    seriesObj.categoryField = categoryAxis;
    if (chartType === 'BAR' || chartType === 'COLUMN' || chartType === 'DONUT') {
      seriesObj.stack = stack;
      seriesObj.visual = this.setSeriesWidthToFixedVlaue.bind(this);
    }

    if (chartType === 'COLUMN') {
      seriesObj.labels = {
        visible: true,
        position: "top",
        padding: {
          top: -20
        },
        font: 'bold ' + CssConst.FONT_XS + ' ' + CssConst.FONT_FAMILY,
        color: CssConst.LABELS_COLOR,
        template: (series) => {
          if (!Ember.isEmpty(series.dataItem.lastSeries)) {
            let dataItem = series.dataItem;
            if (dataItem.lastSeries && series.series.stack) {
              return dataItem.total;
            } else if (dataItem.lastSeries && !series.series.stack) {
              return dataItem.actualValue;
            }
            return '';
          } else {
            return '';
          }


        }
      };
    }

    if (chartType === 'BAR') {
      seriesObj.gap = 0;
    }
    if (chartType === 'LINE') {
      seriesObj.style = "smooth";
    }
    if (chartType === 'DONUT') {
      seriesObj.holeSize = ChartConst.DOUNT_HOLE_SIZE;
    }
    series.push(seriesObj);
    return series;
  },

  createCategoryConfig(type) {
    type = type.toUpperCase();
    let catAxis = {};
    catAxis.max = (type === "LINE" || type === "COLUMN") ? ChartConst.VISIBLE_SERIES_COUNT : ChartConst.VISIBLE_SERIES_COUNT / 2;

    catAxis.majorTicks = {
      width: 0
    };
    catAxis.labels = {
      font: CssConst.FONT_XS + ' ' + CssConst.FONT_FAMILY,
      color: CssConst.LABELS_COLOR,
      visual: this.createLabelItem.bind(this)
    };

    catAxis.majorGridLines = {
      visible: (type === "BAR") ? true : false
    };

    return catAxis;
  },

  createToolTipTemplate(groupBy, a_data) {
    let w_tpl;
    let category;
    let chartType = this.chartType.toUpperCase();
    if (chartType === 'COLUMN' || chartType === 'BAR') {
      category = groupBy ? a_data.dataItem[groupBy] : 'name';
    } else {
      category = a_data.category ? a_data.category : 'Unknown';
    }
    w_tpl = (category + ' : <span class="tooltip-number">' + a_data.dataItem['displayValue'] + '<span>');
    w_tpl = '<div class="tooltip-container">' + w_tpl + '</div>';
    return w_tpl;
  },

  setSeriesWidthToFixedVlaue(e) {
    let visual = e.createVisual();
    let chartType = this.chartType.toUpperCase();

    if (chartType === "BAR") {
      let rect = e.rect;
      let origin = rect.origin;
      let bottomRight = rect.bottomRight();
      let geom = kendo.geometry;
      let Rect = geom.Rect;
      let color = e.dataItem ? e.dataItem.color : '';
      let seriesShiftDistace = rect.bottomRight().y - rect.center().y - 10;

      rect.origin.y = rect.origin.y + seriesShiftDistace;
      this.seriesShiftDistace = seriesShiftDistace;
      let rectLayout = new Rect(rect.origin, rect.size);
      visual = new kendo.drawing.Layout(rectLayout, {
        alignContent: "center",
        alignItems: "center",
        justifyContent: "center",
        spacing: 10,
        lineSpacing: 0
      });

      let marker = new kendo.drawing.Path({
        fill: {
          color: color
        },
        stroke: "none"
      }).moveTo(origin.x, origin.y).lineTo(bottomRight.x, origin.y).lineTo(bottomRight.x, origin.y + ChartConst.BAR_SIZE).lineTo(origin.x, origin.y + ChartConst.BAR_SIZE).close();

      visual.append(marker);
      visual.reflow();
    } else if (chartType === 'COLUMN') {
      // visual.transform(kendo.geometry.transform().scale(ChartConst.BAR_SIZE / e.rect.size.width, 1, e.rect.center()));
    } else if (chartType === 'DONUT') {

    }
    return visual;
  },

  createLabelItem(e) {
    let geom = kendo.geometry;
    let Rect = geom.Rect;
    let draw = kendo.drawing;
    let chartType = this.chartType.toUpperCase();
    let layoutConfig = (chartType === "BAR") ? {} : {
      alignContent: "center",
      alignItems: "center",
      justifyContent: "center",
      spacing: 10,
      lineSpacing: 0,
      wrap: false
    };

    if (chartType === "BAR") {
      e.rect.origin.x = e.rect.origin.x + 10;
      e.rect.origin.y = e.rect.origin.y + this.seriesShiftDistace + 2;
    }
    let rect = new Rect(e.rect.origin, e.rect.size);
    let layout = new draw.Layout(rect, layoutConfig);
    /*let lineWidth = (e.rect.size.width<150)?150:e.rect.size.width;*/
    let pathA = new draw.Path().moveTo(e.rect.origin.x, e.rect.origin.y).lineTo(e.rect.origin.x + 200, e.rect.origin.y + 0).stroke("#CCCCCC", 0.5).close();

    let kendoTxt = new draw.Text(this.trimText(e.text, ChartConst.LABEL_TEXT_COUNT), '', e.options).fill(e.options.color);


    let ragColor = e.dataItem.get('ragColor') ? e.dataItem.get('ragColor') : CssConst.WHITE_COLOR;
    //used to draw circle along with lables
    let circleGeometry = new geom.Circle(e.rect.origin, ChartConst.RAG_RADIUS);
    let circle = new draw.Circle(circleGeometry).fill(ragColor, 1).stroke("none", 0);

    if (chartType === "BAR") {
      layout.append(kendoTxt, pathA);
    } else if ((chartType === "COLUMN" || chartType === "LINE")) {
      if (this.categorySelected) {
        if (this.categorySelectedId === e.dataItem.seriesCode) {
          kendoTxt = new draw.Text(this.trimText(e.text, ChartConst.LABEL_TEXT_COUNT), '', e.options).fill(CssConst.LABELS_COLOR);
          layout.append(circle, kendoTxt);

        } else {
          return e.createVisual();
        }
      } else {
        layout.append(circle, kendoTxt);
      }

    } else {
      return e.createVisual();
    }


    layout.reflow();
    return layout;
  },


  onAxisClick( /*actionName, event*/ ) {
    //this.toggleClickActionOnSeries(actionName, event);
  },

  //this will be used when action name is different that the chartClickAction.
  onSeriesClick(actionName, event) {

    if (this.chartType.toUpperCase() === 'COLUMN') {
      this.toggleClickActionOnSeries(actionName, event);
    } else {
      this.sendAction(actionName, event);
    }
  },

  onLegendItemClick(event) {
    //this.setTotalLabel(event.sender, event.seriesIndex);
    event.preventDefault();
  },

  prepareDataSourceConfig(chartConfig, chartDataConfig) {
    if (!Ember.isEmpty(chartDataConfig)) {
      if (chartDataConfig.isGrouping && !Ember.isEmpty(chartDataConfig.groupField)) {
        chartConfig.dataSource.group = {
          field: chartDataConfig.groupField,
          dir: Ember.isEmpty(chartDataConfig.groupOrderBy) ? 'asc' : 'desc'
        };
      }
      if (!Ember.isEmpty(chartDataConfig.schema)) {
        chartConfig.dataSource.schema = chartDataConfig.schema;
      }
      if (!Ember.isEmpty(chartDataConfig.sort)) {
        chartConfig.dataSource.sort = chartDataConfig.sort;
      }
    }
  },

  setTotalLabel(chart, toggledSeriesIndex) {
    let chartOptions = chart.options;
    let categories = chartOptions.categoryAxis.categories;
    let allSeries = chartOptions.series;
    let categoryLength = categories.length;
    let chartGap = (categoryLength > 0 && categoryLength <= ChartConst.VISIBLE_SERIES_COUNT) ? (ChartConst.GAP_BASE_COUNT / categoryLength) : ChartConst.GAP_BASE_COUNT / ChartConst.VISIBLE_SERIES_COUNT;

    allSeries[0].gap = parseFloat(chartGap, 10);
    allSeries[0].spacing = parseFloat(0.1, 10);

    for (let i = 0; i < categoryLength; i++) {
      let seriesFoundIndex;
      let dataFoundIndex;
      let total = 0;
      for (let j = 0; j < allSeries.length; j++) {
        var visible = allSeries[j].visible;
        var categoryField = allSeries[j].categoryField;
        var stacked = allSeries[j].stack;

        if (j === toggledSeriesIndex) {
          visible = !visible;
        }

        if (visible) {
          let seriesObj = allSeries[j].data;
          for (let k = 0; k < seriesObj.length; k++) {
            if (seriesObj[k][categoryField] === categories[i]) {
              if (typeof(seriesFoundIndex) !== 'undefined' && (allSeries[seriesFoundIndex].data[dataFoundIndex][categoryField] === seriesObj[k][categoryField]) && stacked) {
                allSeries[seriesFoundIndex].data[dataFoundIndex].lastSeries = false;
              }
              seriesObj[k].lastSeries = true;
              dataFoundIndex = k;
              seriesFoundIndex = j;
              total += seriesObj[k].actualValue;
              seriesObj[k].total = total;
              break;
            }
          }
        }
      }
    }

  },

  toggleClickActionOnSeries(actionName, event) {

    let categorySelected = event.dataItem.seriesCode;
    if (!this.categorySelected && this.categorySelectedId !== categorySelected) {

      this.categorySelectedId = event.dataItem.seriesCode;
      this.categorySelected = true;
      event.sender.options.categoryAxis.labels.color = CssConst.DISABLED_COLOR;
      event.sender.options.transitions = false;
      this.redrawChart(categorySelected, false);
      this.sendAction(actionName, event);

    } else if (this.categorySelected && this.categorySelectedId === categorySelected) {

      this.categorySelectedId = '';
      this.categorySelected = false;
      event.sender.options.categoryAxis.labels.color = CssConst.LABELS_COLOR;
      event.sender.options.transitions = false;
      this.redrawChart(categorySelected, true);
      this.sendAction(actionName, event, true);

    } else {

      this.categorySelected = true;
      this.categorySelectedId = event.dataItem.seriesCode;
      event.sender.options.categoryAxis.labels.color = CssConst.DISABLED_COLOR;
      event.sender.options.transitions = false;
      this.redrawChart(categorySelected, false);
      this.sendAction(actionName, event);
    }
  },

  redrawChart(selectedId, showOriginalSeriesColor) {

    var chartData = this.get('chartData');
    if (chartData && this.$('.chartview')) {

      if (!showOriginalSeriesColor) {
        chartData = this.prepareChartData(this.convertToJSON(chartData), selectedId);
      } else {
        chartData = this.convertToJSON(chartData);
      }

      this.chartInstance = this.$('.chartview').data("kendoChart");
      this.get('chartConfig').dataSource = {
        data: chartData
      };
      this.prepareDataSourceConfig(this.get('chartConfig'), this.get('chartDataSourceConfig'));
      if (!this.chartInstance) {
        this.$('.chartview').kendoChart(this.get('chartConfig'));
        this.chartInstance = this.$('.chartview').data("kendoChart");
      }
      this.chartInstance.setDataSource(this.get('chartConfig').dataSource);
    }
  },

  prepareChartData(dataSource, selected) {

    for (let i = 0; i < dataSource.length; i++) {
      if (dataSource[i].seriesCode !== selected) {
        dataSource[i].color = CssConst.DISABLED_COLOR;
      }
    }
    return dataSource;
  },

  mapSeriesColorWithLegend(chart) {

    let chartSeries = chart.options.series;
    for (let i = 0; i < chartSeries.length; i++) {
      let series = chartSeries[i];
      if (series && !Ember.isEmpty(series.data)) {
        series.color = series.data[0].color;
      }
    }
  },

  setDataBoundForChart(event) {

    let view = event.sender.dataSource.view();
    let chart = event.sender;
    this.dataLength = view.length;

    if (view.length === 0) {
      return;
    }

    if (this.chartType.toUpperCase() === 'COLUMN') {
      this.setTotalLabel(chart);
    }

    this.mapSeriesColorWithLegend(chart);
  },

  setOnRenderHanlder( /*event*/ ) {
    let chartViewContainer;
    let overlayPanel;
    if (this.dataLength === 0) {
      chartViewContainer = Ember.$('#' + this.elementId + '-chart-view');
      let svgObj = chartViewContainer.find('svg');

      if (svgObj.length > 0) {

        let height = svgObj.css('height');
        let width = svgObj.css('width');
        overlayPanel = chartViewContainer.parent().find('#' + this.elementId + '-no-data-overlay');
        overlayPanel.css({
          height: height,
          width: width
        });
        chartViewContainer.addClass('hide');
        overlayPanel.removeClass('hide');
      }
    } else {
      chartViewContainer = Ember.$('#' + this.elementId + '-chart-view');
      overlayPanel = chartViewContainer.parent().find('#' + this.elementId + '-no-data-overlay');
      if (!Ember.isEmpty(chartViewContainer)) {
        chartViewContainer.removeClass('hide');
      }
      if (!Ember.isEmpty(overlayPanel)) {
        overlayPanel.addClass('hide');
      }
    }
  },

  trimText(txt, len) {
    if (!txt) {
      txt = 'Unknown';
    } else if (txt.length > len) {
      txt = txt.substring(0, len) + "...";
    }
    return txt;
  },

  willDestroyElement() {
    this._super.apply(this, arguments);

    let chartInstance = this.$('.chartview').data("kendoChart");

    if (chartInstance) {
      chartInstance.destroy();
      this.$(window).off('resize');
    }
  }
});
