import Ember from 'ember';
import layout from '../templates/components/chart-component';
import ConvertToJSON from '../mixins/convert-to-json';
import CssConst from '../utils/css-const';
import ChartConst from '../utils/chart-const';


export default Ember.Component.extend(ConvertToJSON, {
  layout: layout,
  store: Ember.inject.service(),
  classNames: ['chartview'],
  showToolTip: false,
  chartInstance: null,
  chartData: [],
  chartLoading: false,
  supDashConfig: true,
  chartDataSourceConfig: {},
  noDataFoundMessage: 'No Data Found',
  staticSeriesWidth: true,
  seriesShiftDistace: 0,
  seriesColorArray: [],
  customTooltipStyle: Ember.computed('customTooltip.left', 'customTooltip.top', function() {
    let style = '';
    style += 'left:' + this.get('customTooltip.left') + ';';
    style += 'top:' + this.get('customTooltip.top') + ';';

    return Ember.String.htmlSafe(style);
  }),

  actions: {
    onMouseEnterCustomTooltip() {
      this.tooltipActive = true;
    },

    onMouseLeaveCustomTooltip() {
      this.tooltipActive = false;

      this.set('customTooltip', {
        toggleTooltipClass: ''
      });
    }
  },

  init() {
    this._super();
    let chartConfigObj = this.get('chartConfig');
    if (this.get('supDashConfig') && !Ember.isEmpty(chartConfigObj) && chartConfigObj.get('xAxis')) {
      this.buildSupdashConfig(chartConfigObj);
    } else if (this.get('supDashConfig')) {
      this.set('chartConfig', {});
    }
  },

  willInsertElement() {
    this.$('.chartview').kendoChart(this.get('chartConfig'));
    this.chartInstance = this.$('.chartview').data("kendoChart");

    this.chartInstance.bind("dataBound", function(e) {
      this.setDataBoundForChart(e);
    }.bind(this));

    this.chartInstance.bind("render", function(e) {
      this.setOnRenderHanlder(e);
    }.bind(this));

    this.chartInstance.bind("seriesHover", function(seriesObject) {
      if (this.showPointerOnSeries) {
        let seriesParentPath = seriesObject.element.parent();
        if (seriesParentPath) {
          if (seriesParentPath.parent()) {
            if (this.chartType.toUpperCase() === 'DONUT') {
              seriesParentPath.parent().parent().parent().css('cursor', 'pointer');
            } else {
              seriesParentPath.parent().css('cursor', 'pointer');
            }
          }
        }
      }

      Ember.run.next(() => {
        if (this.chartType.toUpperCase() === 'BAR') {
          Ember.$('.k-tooltip').css({
            'margin-top': 2 * this.seriesShiftDistace
          });
        }
      });
    }.bind(this));



    this.$(window).resize(() => {
      this.setHorizontalScroll();
      if (!Ember.isEmpty(this.chartInstance)) {
        //this.chartInstance.options.transitions = false;
        this.chartInstance.refresh();
      }
    });
    this.doDraw();
    this._super();
  },

  didInsertElement() {
    //this.renderLegend();
    if (!Ember.isEmpty(this.chartInstance)) {
      this.chartInstance.resize();
    }


    if (this.get('drillDownFromDashboard')) {
      Ember.run.once(() => {
        this.onAxisClick('detailScreenChartClick', this.get('drillDownFromDashboard'))
      });
    }

    if (this.get('chartConfig').customScrolling) {
      this.$('.scroll-chart-content-icon.mdi-chevron-left').on('click', () => {
        this.scrollChartContent(-50);
      });

      this.$('.scroll-chart-content-icon.mdi-chevron-right').on('click', () => {
        this.scrollChartContent(50);
      });
    }

    this.setVerticalScroll();
    this.setHorizontalScroll();


  },

  renderLegend() {
    let kendoTemplate = kendo.template('<span class="legend-item" data-bind="events: {mouseenter: onMouseEnter, mouseleave: onMouseLeave, click: onClick}" > < span class = "legend-marker" data - bind = "style:{background: markerColor}" > < /span> < span > #: name # < /span> < /span>');
    this.$('#legend').html(kendoTemplate);
    /*legend implementation */
    var viewModel = kendo.observable({
      series: this.chartInstance.options.series,
      onMouseEnter: function(e) {
        var name = e.data.name;
        this.chartInstance.toggleHighlight(true, name);
      },
      onMouseLeave: function(e) {
        var name = e.data.name;
        this.chartInstance.toggleHighlight(false, name);
      },
      onClick: function(e) {
        e.data.set("visible", !e.data.visible);
        var options = {
          series: this.series.toJSON(),
          transitions: false
        };
        this.chartInstance.setOptions(options);
      },
      markerColor: function(e) {
        return e.get("visible") ? e.color : "grey";
      }
    });

    kendo.bind(Ember.$("#legend"), viewModel);

    /* Ends*/

  },

  doDraw: Ember.observer('chartData', function() {
    var chartData = this.convertToJSON(this.get('chartData'));
    this.resetInstanceVariables();
    if (chartData && this.$('.chartview')) {
      this.chartInstance = this.$('.chartview').data("kendoChart");
      this.set('noDataFoundMessage', this.get('noDataFoundMessage'));
      this.get('chartConfig').dataSource = {
        data: chartData
      };
      this.prepareDataSourceConfig(this.get('chartConfig'), this.get('chartDataSourceConfig'));
      if (!this.chartInstance) {
        this.$('.chartview').kendoChart(this.get('chartConfig'));
        this.chartInstance = this.$('.chartview').data("kendoChart");
      }
      this.chartInstance.setDataSource(this.get('chartConfig').dataSource);
      this.chartInstance.options.categoryAxis.labels.color = CssConst.LABELS_COLOR;
      this.totalSeriesCount = this.chartInstance.options.categoryAxis.categories.length;

      if (this.chartType === 'bar') {
        let height = this.totalSeriesCount * 50;

        height = height <= 300 ? 320 : height;
        this.chartInstance.options.chartArea.height = height;
      }
      if (this.chartType === 'column') {
        let columnWidthFactor = 120;
        if (Ember.$('.secondary-content-wrapper').hasClass('secondary-nav')) {
          columnWidthFactor * 80;
        }
        let width = this.totalSeriesCount * columnWidthFactor;
        let fullWidth = Ember.$('#content-placeholder').width() - 50;

        width = width > fullWidth ? width : fullWidth
        this.chartInstance.options.chartArea.width = width;
      }
      //patch to maintain the value axis label
      var maxValue = Math.max.apply(Math, chartData.map(function(obj) {
        let maxVal = obj instanceof Ember.Object ? obj.get('actualValue') : obj.actualValue;
        return maxVal;
      }));

      this.chartInstance.options.valueAxis.majorUnit = (maxValue >= 6) ? undefined : 1;

      // //find Min value.
      // var minValue = Math.min.apply(Math, chartData.map(function(obj) {
      //   let minVal = obj instanceof Ember.Object ? obj.get('actualValue') : obj.actualValue;
      //   return minVal;
      // }));

      // this.chartInstance.options.categoryAxis.labels.padding = minValue < 0 ? {top:140} : undefined;


      this.chartInstance.redraw();
      //patch to get seriesShiftDistance, to make lable and series alligned in a row
      if (this.chartType === 'bar') {
        Ember.run.next(() => {
          this.chartInstance.refresh();

        });
      }
    } else if (chartData) {
      this.get('chartConfig').dataSource = {
        data: chartData
      };
      this.prepareDataSourceConfig(this.get('chartConfig'), this.get('chartDataSourceConfig'));
    }
    return true;
  }),

  buildSupdashConfig(graphConfig) {

    this.chartType = graphConfig.get('type');
    //For setting x-axis and y-axis
    let xAxis = graphConfig.get('xAxis');
    let yAxis = graphConfig.get('yAxis');
    let xAxisLabel = graphConfig.get('xAxisDisplayName') || xAxis;

    //group by config
    let groupBy = graphConfig.get('groupBy') || false;
    let isGrouping = groupBy ? true : false;
    let stackFlag = graphConfig.get('stack') || false;
    let legendPosition = graphConfig.get('legend') || 'bottom';

    let chartConfigObj = {};
    chartConfigObj.theme = 'bootstrap';
    chartConfigObj.tooltip = {
      background: "#000000",
      visible: true,
      template: this.createToolTipTemplate.bind(this, groupBy)
    };
    chartConfigObj.legend = this.createLegendConfig(this.chartType, legendPosition);
    chartConfigObj.categoryAxis = this.createCategoryConfig(this.chartType);
    chartConfigObj.series = this.createSeriesConfig(this.chartType, yAxis, stackFlag, xAxisLabel);
    chartConfigObj.valueAxis = this.createValueAxisConfig(this.chartType);
    chartConfigObj.customScrolling = graphConfig.get('customScrolling');
    chartConfigObj.transitions = false;

    if (chartConfigObj.customScrolling) {
      this.initializeCustomScrollSettings(chartConfigObj);
    } else {
      chartConfigObj.pannable = {
        lock: (this.chartType.toUpperCase() === "BAR") ? 'x' : 'y'
      };
    }

    chartConfigObj.chartArea = {};

    if (this.chartType.toUpperCase() === 'BAR') {
      //chartConfigObj.chartArea.height = ChartConst.CHART_HEIGHT;
    }


    if (this.chartType.toUpperCase() === 'COLUMN' || this.chartType.toUpperCase() === 'LINE') {
      chartConfigObj.chartArea.margin = ChartConst.CHART_MARGIN;
    }

    //Action handler
    let axisClickAction = graphConfig.get('axisClick');
    let seriesClickAction = graphConfig.get('seriesClick');
    let legendClickAction = graphConfig.get('legendClick');

    if (legendClickAction) {
      this[legendClickAction] = legendClickAction;
    }
    chartConfigObj.legendItemClick = this.onLegendItemClick.bind(this, legendClickAction ? legendClickAction : null);

    if (seriesClickAction) {
      if (seriesClickAction !== true && seriesClickAction !== 'true' &&
        seriesClickAction !== 'false' && seriesClickAction !== false) {
        this.showPointerOnSeries = true;
      }
      this[seriesClickAction] = seriesClickAction;
      chartConfigObj.seriesClick = this.onSeriesClick.bind(this, seriesClickAction);
    }

    if (axisClickAction) {
      this[axisClickAction] = axisClickAction;
      chartConfigObj.axisLabelClick = this.onAxisClick.bind(this, axisClickAction);
    }

    let chartDataSourceConfigObj = {};
    chartDataSourceConfigObj.isGrouping = isGrouping;
    chartDataSourceConfigObj.groupField = groupBy;

    this.setProperties({
      chartConfig: chartConfigObj,
      chartDataSourceConfig: chartDataSourceConfigObj,
    });
  },

  initializeCustomScrollSettings(chartConfigObj) {
    this.set('customScrolling', true);

    chartConfigObj.drag = this.onDrag.bind(this);
    chartConfigObj.dragEnd = this.onDragEnd.bind(this);

    // Minimum/maximum number of visible items
    this['MIN_SIZE'] = 12;
    //this['MAX_SIZE'] = 12;
    // Optional sort expression
    // var SORT = { field: "val", dir: "asc" };
    this['SORT'] = {};
    // Minimum distance in px to start dragging
    this['DRAG_THR'] = 20;
    // State variables
    this['viewStart'] = 0;
    this['viewSize'] = this.MIN_SIZE; //should be equal to MIN_SIZE
    this['newStart'] = undefined;
    this['skip'] = 0;
    this['noSkip'] = 0;
  },

  onDrag(event) {
    this.scrollChartContent(event.originalEvent.x.initialDelta);
  },

  onDragEnd( /*event*/ ) {
    this.viewStart = this.newStart;
  },

  scrollChartContent(deltaValue) {
    var chart = this.chartInstance;
    var ds = chart.dataSource;
    var delta = Math.round(deltaValue / this.DRAG_THR);

    if (delta !== 0) {
      this.newStart = Math.max(0, this.viewStart - delta);
      this.newStart = Math.min(ds.data().length - this.viewSize, this.newStart);

      ds.query({
        skip: this.newStart,
        page: 0,
        pageSize: this.viewSize
      });
    }
  },

  createLegendConfig(type, position) {
    let legendconfig = {};
    type = type.toUpperCase();
    //legendconfig.visible = false;
    legendconfig.position = position;
    legendconfig.labels = {
      color: CssConst.LABELS_COLOR,
      font: CssConst.FONT_XS + ' ' + CssConst.FONT_FAMILY,
      margin: {
        bottom: 10
      },
      template: "#: text.toUpperCase() #",
    };
    legendconfig.markers = {
      type: "circle",
      width: 7,
      margin: {
        bottom: 10
      },
    };
    if (type === "DONUT") {
      legendconfig.offsetX = -20;
    }
    if (type === "BAR") {
      legendconfig.offsetY = 10;
    }
    if (type === "COLUMN" && position !== 'bottom') {
      legendconfig.offsetX = 10;
      legendconfig.offsetY = -60;
    }
    return legendconfig;
  },

  createValueAxisConfig(type) {
    let chartType = type.toUpperCase();
    let valueAxis = {
      labels: {
        visible: (chartType !== "BAR"),
        color: CssConst.VALUE_AXIS_COLOR,
        font: CssConst.FONT_XS + ' ' + CssConst.FONT_FAMILY,
        template: "#= kendo.format('{0:N0}', value) #",
        //step : 2
      },
      line: {
        visible: (chartType === "BAR")
      }
    };
    return valueAxis;
  },

  createSeriesConfig(type, value, stack, categoryAxis) {
    let series = [];
    let seriesObj = {};
    let chartType = type.toUpperCase();
    seriesObj.field = value;
    seriesObj.type = type;
    seriesObj.border = {
      width: 0
    };
    seriesObj.colorField = "color";
    seriesObj.categoryField = categoryAxis;
    if (chartType === 'BAR' || chartType === 'COLUMN' || chartType === 'DONUT') {
      seriesObj.stack = stack;
      seriesObj.visual = this.setSeriesWidthToFixedVlaue.bind(this);
    }

    if (chartType === 'COLUMN') {
      seriesObj.labels = {
        visible: true,
        position: "top",
        padding: {
          top: -20
        },
        font: 'bold ' + CssConst.FONT_XS + ' ' + CssConst.FONT_FAMILY,
        color: CssConst.LABELS_COLOR,
        template: (series) => {
          if (!Ember.isEmpty(series.dataItem.lastSeries)) {
            let dataItem = series.dataItem;
            if (dataItem.lastSeries && series.series.stack) {
              return dataItem.title || dataItem.total;
            } else if (dataItem.lastSeries && !series.series.stack) {
              return dataItem.actualValue;
            }
            return '';
          } else {
            return '';
          }


        }
      };
    }

    if (chartType === 'BAR') {
      seriesObj.gap = 0;
    }
    if (chartType === 'LINE') {
      seriesObj.style = "smooth";
      seriesObj.highlight = {
        visual: function(e) {
          let center = e.rect.center();
          let draw = kendo.drawing;
          let geom = kendo.geometry;
          let visual = new draw.Group();
          let circleGeometryOuter = new geom.Circle(center, 15);
          let circleOuter = new draw.Circle(circleGeometryOuter, {
            fill: {
              color: e.dataItem.color
            }
          }).stroke('', 0).opacity(0.5);

          var circleGeometryInner = new geom.Circle(center, 5);
          var circleInner = new draw.Circle(circleGeometryInner).stroke('#FFFFFF', 2);

          visual.append(circleOuter, circleInner, e.createVisual());

          return visual;
        }
      };
    }
    if (chartType === 'DONUT') {
      seriesObj.holeSize = ChartConst.DONUT_HOLE_SIZE;
      seriesObj.size = ChartConst.DONUT_SIZE;
    }
    series.push(seriesObj);
    return series;
  },

  createCategoryConfig(type) {
    type = type.toUpperCase();
    let catAxis = {};
    //catAxis.max = (type === "LINE" || type === "COLUMN") ? ChartConst.VISIBLE_SERIES_COUNT : ChartConst.VISIBLE_SERIES_COUNT / 2;

    catAxis.majorTicks = {
      width: 0
    };
    catAxis.labels = {
      font: CssConst.FONT_XS + ' ' + CssConst.FONT_FAMILY,
      color: CssConst.LABELS_COLOR,
      visual: this.createLabelItem.bind(this)
    };

    catAxis.majorGridLines = {
      visible: (type === "BAR") ? true : false
    };

    return catAxis;
  },

  createToolTipTemplate(groupBy, a_data) {
    let w_tpl;
    let category;
    let chartType = this.chartType.toUpperCase();
    if (chartType === 'COLUMN' || chartType === 'BAR') {
      category = groupBy ? a_data.dataItem[groupBy] : 'name';
    } else {
      category = a_data.category ? a_data.category : 'Unknown';
    }
    if (a_data.dataItem['displayValue'] && a_data.dataItem['displayValue'].indexOf(',') !== -1) {
      w_tpl = '<div class="row rag-tool-tip-row">';
      let contentArray = a_data.dataItem['displayValue'].split(',');
      let len = contentArray.length;
      let colDivision = Math.floor(12 / (len - 1));
      let colClass = 'col-sm-' + colDivision;
      for (let i = 0; i < len; i++) {
        if (contentArray[i]) {
          let displayValue = contentArray[i].split(':');
          let divisionLine = 'rag-border';
          let ragColor = displayValue[2] ? displayValue[2] : '#FFC333';
          if (i === len - 2) divisionLine = '';
          w_tpl += '<div class="' + colClass + ' rag-tool-tip-rag-content ' + divisionLine + '"> <div class="rag-number" style="color:' + ragColor + '">' + displayValue[1] + '</div><div class="rag-text">' + displayValue[0] + '</div></div>';
        }
      }
    } else {
      w_tpl = (category + ' : <span class="tooltip-number">' + a_data.dataItem['displayValue'] + '<span>');
      w_tpl = '<div class="tooltip-container">' + w_tpl + '</div>';
    }

    return w_tpl;
  },

  setSeriesWidthToFixedVlaue(e) {
    let visual = e.createVisual();
    let chartType = this.chartType.toUpperCase();

    if (chartType === "BAR") {
      let rect = e.rect;
      let origin = rect.origin;
      let bottomRight = rect.bottomRight();
      let geom = kendo.geometry;
      let Rect = geom.Rect;
      let color = e.dataItem ? e.dataItem.color : '';
      let seriesShiftDistace = rect.bottomRight().y - rect.center().y - (ChartConst.BAR_SIZE / 2);

      rect.origin.y = rect.origin.y + seriesShiftDistace;
      this.seriesShiftDistace = seriesShiftDistace;
      let rectLayout = new Rect(rect.origin, rect.size);
      visual = new kendo.drawing.Layout(rectLayout, {
        alignContent: "center",
        alignItems: "center",
        justifyContent: "center",
        spacing: 10,
        lineSpacing: 0
      });

      let marker = new kendo.drawing.Path({
        fill: {
          color: color
        },
        stroke: "none"
      }).moveTo(origin.x, origin.y).lineTo(bottomRight.x, origin.y).lineTo(bottomRight.x, origin.y + ChartConst.BAR_SIZE).lineTo(origin.x, origin.y + ChartConst.BAR_SIZE).close();

      visual.append(marker);
      visual.reflow();
    } else if (chartType === 'COLUMN') {
      // visual.transform(kendo.geometry.transform().scale(ChartConst.BAR_SIZE / e.rect.size.width, 1, e.rect.center()));
    } else if (chartType === 'DONUT') {
      let origin = e.center;
      let radius = e.radius;
      var draw = kendo.drawing;
      var geom = kendo.geometry;

      var circleGeometryOuter = new geom.Circle(origin, radius + ChartConst.DONUT_OUTER_BORDER_GAP);
      var circleOuter = new draw.Circle(circleGeometryOuter).stroke(CssConst.DONUT_BORDER_COLOR, 1);

      var circleGeometryInner = new geom.Circle(origin, radius - (ChartConst.DONUT_SIZE + ChartConst.DONUT_OUTER_BORDER_GAP));
      var circleInner = new draw.Circle(circleGeometryInner).stroke(CssConst.DONUT_BORDER_COLOR, 1);

      visual = new draw.Group();

      visual.append(circleOuter, e.createVisual(), circleInner);
    }
    return visual;
  },

  createLabelItem(e) {
    let visual = e.createVisual();
    let geom = kendo.geometry;
    let Rect = geom.Rect;
    let draw = kendo.drawing;
    let chartType = this.chartType.toUpperCase();
    let layoutConfig = (chartType === "BAR") ? {} : {
      alignContent: "center",
      alignItems: "center",
      justifyContent: "center",
      spacing: 3,
      lineSpacing: 0,
      wrap: false
    };

    if (chartType === "BAR") {
      e.rect.origin.x = e.rect.origin.x + 10;
      e.rect.origin.y = e.rect.origin.y + this.seriesShiftDistace + 2;
    }

    let rect = new Rect(e.rect.origin, e.rect.size);
    let layout = new draw.Layout(rect, layoutConfig);
    let pathA = new draw.Path().moveTo(e.rect.origin.x, e.rect.origin.y).lineTo(e.rect.origin.x + 200, e.rect.origin.y + 0).stroke("#CCCCCC", 0.5).close();

    let kendoTxt = this.getCategoryText(chartType, e);
    let ragColor = e.dataItem.get('ragColor') ? e.dataItem.get('ragColor') : CssConst.WHITE_COLOR;
    //used to draw circle along with lables
    let circleGeometry = new geom.Circle(e.rect.origin, ChartConst.RAG_RADIUS);
    let circle = new draw.Circle(circleGeometry).fill(ragColor, 1).stroke("none", 0);

    if (chartType === "BAR") {
      layout.append(kendoTxt, pathA);
    } else if ((chartType === "COLUMN" || chartType === "LINE")) {
      if (this.categorySelected) {
        if (this.categorySelectedId === e.dataItem.seriesCode) {
          kendoTxt = this.getCategoryText(chartType, e).fill(CssConst.LABELS_COLOR);
          layout.append(circle, kendoTxt);
        } else {
          layout.append(kendoTxt);
        }
      } else {
        layout.append(circle, kendoTxt);
      }

    } else {
      return visual;
    }


    layout.reflow();
    return layout;
  },

  getCategoryText(chartType, event) {
    let maxCharToShow = 10;
    let categoryCount = this.categoryCount ? this.categoryCount : 12;

    if (chartType === 'BAR') {
      maxCharToShow = ChartConst.LABEL_TEXT_COUNT_MAX;
    } else if (chartType === 'COLUMN' || chartType === 'LINE') {
      if (categoryCount <= 7) {
        maxCharToShow = ChartConst.LABEL_TEXT_COUNT_MAX;
      } else if (categoryCount > 7 && categoryCount <= 10) {
        maxCharToShow = ChartConst.LABEL_TEXT_COUNT_AVG;
      } else if (categoryCount > 10) {
        maxCharToShow = ChartConst.LABEL_TEXT_COUNT_MIN;
      }
    }

    let kendoText = new kendo.drawing.Text(this.trimText(event.text, maxCharToShow), '', event.options)
      .fill(event.options.color);

    kendoText.tooltipText = event.text;

    return kendoText;
  },

  onAxisClick( actionName, event) {
    if (this.chartType.toUpperCase() === 'COLUMN') {
      this.toggleClickActionOnSeries(actionName, event, 'seriesCode');
    } else {
      this.sendAction(actionName, event);
    }
  },

  //this will be used when action name is different that the chartClickAction.
  onSeriesClick(actionName, event) {

    if (this.chartType.toUpperCase() === 'COLUMN') {
      this.toggleClickActionOnSeries(actionName, event, 'seriesCode');
    } else {
      this.sendAction(actionName, event);
    }
  },

  onLegendItemClick(actionName, event) {
    if (actionName) {
      this.toggleClickActionOnLegend(actionName, event, 'item');
      this.setTotalLabel(event.sender, event.seriesIndex);
    }

    event.preventDefault();
  },

  prepareDataSourceConfig(chartConfig, chartDataConfig) {
    if (!Ember.isEmpty(chartDataConfig)) {
      if (chartDataConfig.isGrouping && !Ember.isEmpty(chartDataConfig.groupField)) {
        chartConfig.dataSource.group = {
          field: chartDataConfig.groupField,
          dir: Ember.isEmpty(chartDataConfig.groupOrderBy) ? 'asc' : 'desc'
        };
      }
      if (!Ember.isEmpty(chartDataConfig.schema)) {
        chartConfig.dataSource.schema = chartDataConfig.schema;
      }
      if (!Ember.isEmpty(chartDataConfig.sort)) {
        chartConfig.dataSource.sort = chartDataConfig.sort;
      }
    }
  },

  setTotalLabel(chart, toggledSeriesIndex) {
    let chartOptions = chart.options;
    let categories = chartOptions.categoryAxis.categories;
    let allSeries = chartOptions.series;
    let categoryLength = categories.length;
    let chartGap = (categoryLength > 0 && categoryLength <= ChartConst.VISIBLE_SERIES_COUNT) ? (ChartConst.GAP_BASE_COUNT / categoryLength) : ChartConst.GAP_BASE_COUNT / ChartConst.VISIBLE_SERIES_COUNT;

    allSeries[0].gap = parseFloat(chartGap, 10);
    allSeries[0].spacing = parseFloat(0.1, 10);

    for (let i = 0; i < categoryLength; i++) {
      let seriesFoundIndex;
      let dataFoundIndex;
      let total = 0;
      for (let j = 0; j < allSeries.length; j++) {
        var visible = allSeries[j].visible;
        var categoryField = allSeries[j].categoryField;
        var stacked = allSeries[j].stack;

        if (j === toggledSeriesIndex) {
          visible = !visible;
        }

        if (visible) {
          let seriesObj = allSeries[j].data;
          for (let k = 0; k < seriesObj.length; k++) {
            if (seriesObj[k][categoryField] === categories[i]) {
              if (typeof(seriesFoundIndex) !== 'undefined' && (allSeries[seriesFoundIndex].data[dataFoundIndex][categoryField] === seriesObj[k][categoryField]) && stacked) {
                allSeries[seriesFoundIndex].data[dataFoundIndex].lastSeries = false;
              }
              seriesObj[k].lastSeries = true;
              dataFoundIndex = k;
              seriesFoundIndex = j;
              total += seriesObj[k].actualValue;
              seriesObj[k].total = total;
              break;
            }
          }
        }
      }
    }

  },

  toggleClickActionOnLegend(actionName, event, attributeName) {
    let selectedLegend = event.text;
    this.categorySelected = false;
    event.sender.options.categoryAxis.labels.color = CssConst.LABELS_COLOR;

    this.seriesIndex = event.seriesIndex;
    if (!this.selectedLegend && this.selectedLegendText !== selectedLegend) {
      this.selectedLegendText = selectedLegend;
      this.selectedLegend = true;
      this.redrawChart(selectedLegend, false, attributeName);
      this.sendAction(actionName, event);

    } else if (this.selectedLegend && this.selectedLegendText === selectedLegend) {

      this.selectedLegendText = '';
      this.selectedLegend = false;
      this.redrawChart(selectedLegend, true, attributeName);
      this.sendAction(actionName, event, true);

    } else {

      this.selectedLegend = true;
      this.selectedLegendText = selectedLegend;
      this.redrawChart(selectedLegend, false, attributeName);
      this.sendAction(actionName, event);
    }
    this.chartInstance.refresh();
  },

  toggleClickActionOnSeries(actionName, event, attributeName) {

    let categorySelected
    if (typeof event === 'string') {
      categorySelected = event;
      let series = this.chartInstance.options.series;
      let selectedSeries = {};
      for (let i = 0; i < series.length; i++) {
        selectedSeries = series[i].data.find(function(data) {
          return (data.seriesCode === categorySelected)
        });
        if (selectedSeries) {
          break;
        }
      }
      if (!selectedSeries) {
        selectedSeries = {
          title: ''
        };
      }
      event = {
        dataItem: selectedSeries,
        preventGridRefresh: true
      };
    } else {
      categorySelected = event.dataItem ? event.dataItem.seriesCode : event.text;
    }

    this.selectedLegend = false; //On selection of bar legend should retain the orignal position.

    if (!this.categorySelected && this.categorySelectedId !== categorySelected) {

      this.categorySelectedId = categorySelected;
      this.categorySelected = true;
      this.chartInstance.options.categoryAxis.labels.color = CssConst.DISABLED_COLOR;
      this.chartInstance.options.transitions = false;
      this.redrawChart(categorySelected, false, attributeName);
      this.sendAction(actionName, event);

    } else if (this.categorySelected && this.categorySelectedId === categorySelected) {

      this.categorySelectedId = '';
      this.categorySelected = false;
      this.chartInstance.options.categoryAxis.labels.color = CssConst.LABELS_COLOR;
      this.chartInstance.options.transitions = false;
      this.redrawChart(categorySelected, true, attributeName);
      this.sendAction(actionName, event, true);

    } else {

      this.categorySelected = true;
      this.categorySelectedId = categorySelected;
      this.chartInstance.options.categoryAxis.labels.color = CssConst.DISABLED_COLOR;
      this.chartInstance.options.transitions = false;
      this.redrawChart(categorySelected, false, attributeName);
      this.sendAction(actionName, event);
    }
  },

  redrawChart(selectedId, showOriginalSeriesColor, seriesCode) {
    var chartData = this.get('chartData');

    if (chartData && this.$('.chartview')) {

      if (!showOriginalSeriesColor) {
        chartData = this.prepareChartData(this.convertToJSON(chartData), selectedId, seriesCode);
      } else {
        chartData = this.convertToJSON(chartData);
      }

      this.chartInstance = this.$('.chartview').data("kendoChart");
      this.get('chartConfig').dataSource = {
        data: chartData
      };
      this.prepareDataSourceConfig(this.get('chartConfig'), this.get('chartDataSourceConfig'));
      if (!this.chartInstance) {
        this.$('.chartview').kendoChart(this.get('chartConfig'));
        this.chartInstance = this.$('.chartview').data("kendoChart");
      }
      this.chartInstance.setDataSource(this.get('chartConfig').dataSource);
    }
  },


  prepareChartData(dataSource, selected, seriesCode) {

    for (let i = 0; i < dataSource.length; i++) {
      if (isNaN(dataSource[i][seriesCode]) && dataSource[i][seriesCode].toUpperCase() !== selected.toUpperCase()) {
        dataSource[i].color = CssConst.DISABLED_COLOR;
      } else if (!isNaN(dataSource[i][seriesCode]) && dataSource[i][seriesCode] !== selected) {
        dataSource[i].color = CssConst.DISABLED_COLOR;
      }
    }
    return dataSource;
  },

  mapSeriesColorWithLegend(chart, desibleOtherLegend) {
    let chartSeries = chart.options.series;

    for (let i = 0; i < chartSeries.length; i++) {
      let series = chartSeries[i];
      if (series && !Ember.isEmpty(series.data)) {
        if (desibleOtherLegend && this.seriesIndex !== i) {
          series.color = '#cdcdcd';
        } else {
          if (this.seriesColorArray.length === chartSeries.length) {
            series.color = this.seriesColorArray[i];
          } else {
            this.seriesColorArray[i] = series.color = series.data[0].color;
          }
        }
      }
    }
  },

  setDataBoundForChart(event) {

    let view = event.sender.dataSource.view();
    let chart = event.sender;
    this.dataLength = view.length;

    if (view.length === 0) {
      return;
    }

    if (this.chartType.toUpperCase() === 'COLUMN') {
      this.setTotalLabel(chart);
      if (this.categorySelected) {
        //this.invertSeriesLableColor(event, this.categorySelectedId);
      }
    }

    this.mapSeriesColorWithLegend(chart, this.selectedLegend);
  },

  setOnRenderHanlder(event) {
    let chartViewContainer;
    let overlayPanel;
    if (this.dataLength === 0) {
      chartViewContainer = Ember.$('#' + this.elementId + '-chart-view');
      let svgObj = chartViewContainer.find('svg');

      if (svgObj.length > 0) {

        let height = svgObj.css('height');
        let width = svgObj.css('width');
        overlayPanel = chartViewContainer.parent().find('#' + this.elementId + '-no-data-overlay');
        overlayPanel.css({
          height: height,
          width: width
        });
        chartViewContainer.addClass('hide');
        overlayPanel.removeClass('hide');
      }
    } else {
      chartViewContainer = Ember.$('#' + this.elementId + '-chart-view');
      overlayPanel = chartViewContainer.parent().find('#' + this.elementId + '-no-data-overlay');
      if (!Ember.isEmpty(chartViewContainer)) {
        chartViewContainer.removeClass('hide');
      }
      if (!Ember.isEmpty(overlayPanel)) {
        overlayPanel.addClass('hide');
      }

      this.addCustomTooltipHandler(event);
    }
  },

  addCustomTooltipHandler(event) {
    event.sender.surface.bind('mouseenter', (event) => {
      var content = (typeof event.element.content === 'function') ? event.element.content() : '';

      if (event.element.tooltipText && content.indexOf('...') > -1) {
        var pos = event.element.bbox().getOrigin();

        if (!this.isDestroyed) {
          this.set('activeElementContent', content);
          this.set('customTooltip', {
            value: event.element.tooltipText,
            left: pos.x + 'px',
            top: (pos.y + 30) + 'px',
            toggleTooltipClass: 'show'
          });
        }
      }
    });

    event.sender.surface.bind('mouseleave', (event) => {
      var content = (typeof event.element.content === 'function') ? event.element.content() : '';

      if (event.element.tooltipText && content.indexOf('...') > -1) {
        if (!this.tooltipActive && !this.isDestroyed) {
          this.set('customTooltip', {
            toggleTooltipClass: ''
          });
        }
      }
    });
  },

  invertSeriesLableColor(event, categorySelected) {
    let series = event.sender.options.series;
    for (let i = 0; i < series.length; i++) {
      series[i].labels.color = CssConst.DISABLED_COLOR;
    }
  },

  resetInstanceVariables() {
    this.categorySelected = false;
    this.selectedLegend = false;
    this.seriesColorArray = [];
  },

  setHorizontalScroll() {
    if (this.chartType === 'column') {
      let columnWidthFactor = 120;
      if (Ember.$('.secondary-content-wrapper').hasClass('secondary-nav')) {
        columnWidthFactor * 80;
      }
      let width = this.totalSeriesCount * columnWidthFactor;
      let fullWidth = Ember.$('#content-placeholder').width() - 50;
      if (width > fullWidth) {
        Ember.$('.chart-content').css({
          width: fullWidth,
          overflow: 'auto'
        });
        this.$('.chartview').css({
          width: width
        });
      } else {
        Ember.$('.chart-content').css({
          width: '100%',
          overflow: 'none'
        });
        this.$('.chartview').css({
          width: '100%'
        });
      }
    }
  },

  setVerticalScroll() {
    /*calculation to fixed the scrolling height*/
    if (this.chartType === 'bar') {
      let height = this.totalSeriesCount * 50;
      height = height <= 300 ? 320 : height;
      this.$('.chartview').css({
        height: height
      });
    }
  },

  trimText(txt, len) {
    if (!txt) {
      txt = 'Unknown';
    } else if (txt.length > len) {
      txt = txt.substring(0, len) + "...";
    }
    return txt;
  },

  willDestroyElement() {
    this._super.apply(this, arguments);

    let chartInstance = this.$('.chartview').data("kendoChart");

    if (chartInstance) {
      chartInstance.destroy();
      this.$(window).off('resize');
    }
  }
});
