import Ember from 'ember';
import AppConst from '../utils/app-const';

export default Ember.Component.extend({
  coreDataService: Ember.inject.service(),
  title: null,
  showFooter: true,
  okBtnText: 'OK',
  onOk: null,
  onCancel: null,
  disableOkBtn: true,
  callbackContext: null,
  parentDialog: null,
  modelName: 'base',
  gridItemRoot: 'info',
  screenName: null,

  actions: {
    handleAction(bttonClicked) {
      if (bttonClicked === 'ok' && this.onOk) {
        this.onOk.call(this.get('callbackContext'), this.selectedRows, this.parentDialog);
      } else if (bttonClicked === 'cancel' && this.onCancel) {
        this.onCancel.call(this.get('callbackContext'), this.parentDialog);
      }
    },

    onRowItemSelect(selectedRows /*, isAllClick, currentRow*/ ) {
      this.selectedRows = selectedRows;

      this.enableAddButton(selectedRows.length > 0);
    },

    searchItems(searchFieldClass, event) {
      if (event.keyCode === AppConst.KEY_CODE.ENTER) {
        if (this.modelName) {
          let searchField = this.$('.' + searchFieldClass);
          let searchFieldValue = searchField.val();

          if (searchFieldValue) {
            this.searchFieldValue = searchFieldValue;
            let params = this.getParams();

            this.get('coreDataService').queryRecord(this.modelName, params).then((response) => {
              if (this.isDestroyed) {
                return;
              }

              let gridItem = this.getGridItem(response);
              this.controller.set('showSearchResults', false);

              if (gridItem.gridConfig) {
                Ember.run.next(() => {
                  this.controller.setProperties({
                    showSearchResults: true,
                    resultGridConfig: {
                      gridConfig: gridItem.gridConfig,
                      gridData: gridItem.gridData,
                      modelName: this.modelName,
                      gridItemRoot: this.gridItemRoot,
                      gridServiceParams: this.getGridServiceParams()
                    }
                  });
                });
              }
            });
          }

        } else {
          Ember.Logger.error('Please provide model name for search funcationlity to work.');
        }
      }
    }
  },

  init() {
    this._super();
  },

  willDestroy() {
    if (this.parentDialog) {
      this.set('parentDialog', null);
    }

    if (this.selectedRows) {
      this.set('selectedRows', null);
    }

    this.destroy();
  },

  getGridItem(response) {
    let gridItem = {};

    if (this.modelName === 'base') {
      gridItem = response.get('info').gridItem;
    } else {

    }

    return gridItem;
  },

  getParams() {
    return {
      screenName: this.screenName,
      psIds: this.searchFieldValue,
      gridId: 'UserAdmin_Assign_Users_Grid',
      screen: 'lookup'
    };
  },

  getGridServiceParams() {
    return this.getParams();
  },

  enableAddButton(enableBtn) {
    this.set('disableOkBtn', !enableBtn);
  }
});
