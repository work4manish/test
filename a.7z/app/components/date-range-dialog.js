import Ember from 'ember';
import ComponentQueryMixinMixin from 'supdash-ui-core/mixins/component-query-mixin';

export default Ember.Component.extend(ComponentQueryMixinMixin, {
  dateUtil: Ember.inject.service(),
  onOk: null,
  onCancel: null,
  fromDate: null,
  toDate: null,
  disableOkBtn: true,

  init() {
    this._super();

    this.validateBothDatePresence();
    if (!this.title) {
      this.set('title', 'Date Range');
    }
  },

  actions: {
    handleAction(bttonClicked) {
      if (bttonClicked === 'ok' && this.onOk) {
        this.onOk.call(this.get('callbackContext'), this.fromDate, this.toDate);
      } else if (bttonClicked === 'cancel' && this.onCancel) {
        this.onCancel.call(this.get('callbackContext'), this.fromDate, this.toDate);
      }
    },

    onFromDateChange(date) {
      this.fromDate = date;

      let toDatePicker = this.getChildComponentOf(this.childViews[0], 'name', 'toDate');
      toDatePicker.setMin(this.get('dateUtil').getDateObject(date).toDate());

      this.validateBothDatePresence();
    },

    onToDateChange(date) {
      this.toDate = date;

      let fromDatePicker = this.getChildComponentOf(this.childViews[0], 'name', 'fromDate');
      fromDatePicker.setMax(this.get('dateUtil').getDateObject(date).toDate());

      this.validateBothDatePresence();
    }
  },

  validateBothDatePresence() {
    this.set('disableOkBtn', !(this.fromDate && this.toDate));
  }
});
