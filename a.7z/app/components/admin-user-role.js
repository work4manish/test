import Ember from 'ember';
import convertToJSON from '../mixins/convert-to-json';
import MapActionMixin from '../mixins/map-action-mixin';

export default Ember.Component.extend(convertToJSON, MapActionMixin, {
  coreDataService: Ember.inject.service(),
  ColumnCount: 12,
  selectRoleColumnCount: 12,
  showSelectOptions: true,
  isAddUserRoleAction: true,
  newReportees: [],
  removedReportees: [],
  selectedBankIds: [],
  isRoleSelected: false,
  infoMessage: 'Please search for user on profile screen!',


  isRoleSelectedObserver: Ember.observer('isRoleSelected', function() {
    if (this.isRoleSelected) {
      this.updateGridServiceParams();
    }
  }),

  clearUserRoleScreen: Ember.observer('showSelectOptions', function() {
    if (this.get('showSelectOptions') !== true) {
      this.restAllRoleInfoFlag(false);
      Ember.run.next(() => {
        this.sendActionToRouteForOkBtn(true);
      });
    }
  }),

  actions: {

    onRoleSelection(role) {
      this.userRoleId = role;
      this.fetchRoleInfo(role);
    },

    customRoleInputValue(val) {
      this.get('roleModel').set('userRoleName', val);
    },

    bfsHierarchySelectLevel2(val, isMultiSelect) {
      if (this.get('bfsHierarchyLevel3')) {
        this.get('coreDataService').queryRecord('base', {
          screenName: 'adminUserProfileHierarchy',
          level: 3,
          roleId: this.userRoleId,
          prevLevelCode: this.getPreviousLevelCode(val, isMultiSelect)
        }).then((users) => {
          let bfsHierarchyLevel = users.get('info').bfsHierarchyLevel3;
          this.setProperties({
            bfsHierarchyLevel3: bfsHierarchyLevel,
            multiSelectedBizHierarchyLevel3: '',
            singleSelectedBizHierarchyLevel3: '',
            multiSelectedBizHierarchyLevel4: '',
            singleSelectedBizHierarchyLevel4: '',
            multiSelectedBizHierarchyLevel6: '',
            singleSelectedBizHierarchyLevel6: ''
          });
        }).catch((reason) => {
          console.log(reason);
        });
      }

    },

    bfsHierarchySelectLevel3(val, isMultiSelect) {
      if (this.get('bfsHierarchyLevel4')) {
        this.get('coreDataService').queryRecord('base', {
          screenName: 'adminUserProfileHierarchy',
          level: 4,
          roleId: this.userRoleId,
          prevLevelCode: this.getPreviousLevelCode(val, isMultiSelect)
        }).then((users) => {
          let bfsHierarchyLevel = users.get('info').bfsHierarchyLevel4;
          this.setProperties({
            bfsHierarchyLevel4: bfsHierarchyLevel,
            multiSelectedBizHierarchyLevel4: '',
            singleSelectedBizHierarchyLevel4: '',
            multiSelectedBizHierarchyLevel6: '',
            singleSelectedBizHierarchyLevel6: ''
          });
        }).catch((reason) => {
          console.log(reason);
        });
      }
    },

    bfsHierarchySelectLevel4(val, isMultiSelect) {
      if (this.get('bfsHierarchyLevel6')) {
        this.get('coreDataService').queryRecord('base', {
          screenName: 'adminUserProfileHierarchy',
          level: 6,
          roleId: this.userRoleId,
          prevLevelCode: this.getPreviousLevelCode(val, isMultiSelect)
        }).then((users) => {
          let bfsHierarchyLevel = users.get('info').bfsHierarchyLevel6;

          // if(bfsHierarchyLevel.length===0){
          //   this.sendActionToRouteForValidationFlag();
          // }

          this.setProperties({
            bfsHierarchyLevel6: bfsHierarchyLevel,
            multiSelectedBizHierarchyLevel6: '',
            singleSelectedBizHierarchyLevel6: ''
          });
        }).catch((reason) => {
          console.log(reason);
        });
      }
    },

    onAddPSIDClick() {
      this.hidePopup();
    },

    onDeleteClick(removedItem /*, actionId*/ ) {
      this.set('removedReportees', [removedItem]);
    },

    onSelectedBankIdsChange(currentRecords, primaryKeyField) {
      let selectedBankIds = Ember.copy(currentRecords, true);

      this.set('selectedBankIds', this.getSelectedBankIds(selectedBankIds, primaryKeyField));
    }
  },

  init() {
    this._super(...arguments);
    this.set('newReportees', []);
    this.set('removedReportees', []);
    this.set('selectedBankIds', []);

    this.mapAction('action');
    if (this.get('roleModel').get('actionType') === 'updateUserRole') {
      this.set('userRoleId', this.get('roleModel').get('userRoleId'));
      this.sendActionToRouteForOkBtn(false);
      this.setProperties({
        isAddUserRoleAction: false,
        selectedRoleForEdit: this.get('roleModel').get('userRoleName')
      });
      this.setRoleInfo(this.get('userEditRoleData'), this.get('roleModel'));
    } else {
      this.fetchRoles();
    }
  },

  didInsertElement() {
    if (this.get('roleModel').get('actionType') === 'updateUserRole') {
      this.$('.mdi-select2-div').addClass('is-active');
    }
  },

  fetchRoles() {
    this.get('coreDataService').query('adminAvailableRole').then((roles) => {
      let rolesArray = this.convertToJSON(roles);
      this.setProperties({
        contents: rolesArray
      });
    });
  },

  fetchRoleInfo(role) {
    let userId = this.get('roleModel').get('userPsId');
    let selectOptionsArray = this.get('contents');
    let selectedRoleObject = selectOptionsArray.findBy('id', role);

    this.restAllRoleInfoFlag(false);

    this.get('coreDataService').queryRecord('adminRoleInfo', {
      userId: userId,
      roleId: role
    }).then((roleInfo) => {
      this.setRoleInfo(roleInfo);
      if (selectedRoleObject.roleType === 'CUSTOM') {
        this.updateUiForCustomRole(selectedRoleObject);
      }
    }).catch((reason) => {
      this.restAllRoleInfoFlag(false);
      this.sendActionToRouteForOkBtn(true);
      this.sendActionOverride('popupErrorMessage', reason.errors);
    });
  },

  setRoleInfo(roleInfo, assignedValue) {
    let roleConfig = roleInfo.get('roleConfiguration') ? roleInfo.get('roleConfiguration').toJSON() : {};
    let bizHierarchyCount = 0;
    let validateArray = [];

    for (let roleAttr in roleConfig) {
      if (roleAttr.indexOf('isBizHierarchyLevel') !== -1 && roleConfig[roleAttr]) {
        bizHierarchyCount++;
        validateArray.push(roleAttr);
        this.set('assignByBFS', true);
        this.setAssignByBFSElement(roleAttr, roleConfig, roleInfo, assignedValue);

      } else if (roleAttr.indexOf('isAssgnCountries') !== -1 && roleConfig[roleAttr]) {
        validateArray.push(roleAttr);
        this.setAssignByCountry(roleInfo.get('availableCountries'), assignedValue);

      } else if (roleAttr.indexOf('isAssgnBankIds') !== -1 && roleConfig[roleAttr]) {
        this.setAssignByPSID();
      }

    }

    this.sendActionToRouteForOkBtn(false, validateArray);
    if (this.get('roleModel').get('actionType') !== 'updateUserRole') {
      this.setModelUserRole(roleConfig);
    }


    if (bizHierarchyCount > 1) {
      this.set('columnCount', 6);
    } else {
      this.set('columnCount', 12);
    }

    this.set('isRoleSelected', true);
  },

  setAssignByBFSElement(roleAttr, roleConfig, roleInfo, assignedValue) {
    let roleSuffix = roleAttr.slice(-1);
    let contentArrayKey = 'bfsHierarchyLevel' + roleSuffix;

    let multiSelectKey = 'multiBizHierarchyLevel' + roleSuffix;
    let multiSelect = roleConfig[multiSelectKey];
    let hasMayKey = 'hasManyBizHierarchyLevel' + roleSuffix;

    let selectedValueKey = multiSelect ? 'multiSelectedBizHierarchyLevel' : 'singleSelectedBizHierarchyLevel';
    selectedValueKey = selectedValueKey + roleSuffix;
    let assignedArray = assignedValue ? assignedValue.get(contentArrayKey) : [];
    let selectedValue = multiSelect ? assignedArray : (!Ember.isEmpty(assignedArray) ? assignedArray.get('lastObject') : null);


    let labelKey = 'labelBizHierarchyLevel' + roleSuffix;
    let labelValue = 'Business Function (Level ' + roleSuffix + ')';

    let infoMsgKey = 'infoMsgBizHierarchyLevel' + roleSuffix;
    let infoMsgKeyText = multiSelect ? 'Multiple selections are allowed' : '';

    let cssClassKey = 'multiSelectCssClassLevel' + roleSuffix;
    let cssClass = multiSelect ? 'multi-select-2' : 'single-select-2';

    this.set(contentArrayKey, roleInfo.get(contentArrayKey));

    this.set(multiSelectKey, multiSelect);
    this.set(selectedValueKey, selectedValue);

    this.set(hasMayKey, multiSelect);
    this.set(labelKey, labelValue);
    this.set(labelKey, labelValue);
    this.set(infoMsgKey, infoMsgKeyText);
    this.set(cssClassKey, cssClass);
  },

  setAssignByCountry(country, assignedValue) {
    this.setProperties({
      assignByCountry: country,
      selectedCountry: assignedValue ? assignedValue.get('countryCodes') : []
    });
  },


  setAssignByPSID() {
    this.setProperties({
      assignByPSID: true,
      gridServiceParams: this.getGridServiceParams(),
      gridColActionItems: [{
        "id": "delete",
        "title": "Delete",
        "iconClass": "mdi mdi-minus-circle",
        "action": "onDeleteClick"
      }]
    });
  },

  getPreviousLevelCode(selectedValue, isMultiSelect) {
    let prevLevelCode = '';

    if (isMultiSelect) {
      for (let i = 0; i < selectedValue.length; i++) {
        let selectedItem = selectedValue[i];

        prevLevelCode += (selectedItem.id || selectedItem.code) + ',';
      }

      prevLevelCode = prevLevelCode.substring(0, prevLevelCode.length - 1);

    } else {
      prevLevelCode = selectedValue.id || selectedValue.code;
    }

    return prevLevelCode;
  },

  setModelUserRole(roleConfig) {
    this.get('roleModel').setProperties({
      userRoleId: roleConfig.roleId,
      userRoleType: roleConfig.roleType
    });

    if (roleConfig.roleType === "CUSTOM") {
      if (!Ember.isEmpty(this.get('roleModel').get('userRoleName'))) {
        //this.get('roleModel').set('userRoleName', '');
        this.get('roleModel').set('userRoleName', roleConfig.roleName);

      }
    } else {
      this.get('roleModel').set('userRoleName', roleConfig.roleName);
    }
  },

  restAllRoleInfoFlag(flag) {
    this.setProperties({
      assignByBFS: flag,
      assignByCountry: flag,
      assignByPSID: flag,
      bfsHierarchyLevel2: flag,
      bfsHierarchyLevel3: flag,
      bfsHierarchyLevel4: flag,
      bfsHierarchyLevel6: flag,
      isCustomRoleSelected: flag,
      selectRoleColumnCount: 12
    });
  },

  sendActionToRouteForOkBtn(disableOkBtn, validateArray) {
    this.sendAction(this.action, disableOkBtn, validateArray);
  },

  updateUiForCustomRole( /*role*/ ) {
    this.setProperties({
      isCustomRoleSelected: true,
      selectRoleColumnCount: 6,
      customRoleName: '',
    });
  },

  getGridServiceParams() {
    let roleModel = this.get('roleModel');

    return {
      screenName: 'adminUserReporteesGrid',
      gridId: 'UserAdmin_Assign_Users_Grid',
      userId: roleModel.get('userPsId'),
      roleId: roleModel.get('userRoleId')
    };
  },

  updateGridServiceParams() {
    this.set('gridServiceParams', this.getGridServiceParams());
  },

  getSelectedBankIds(rows, primaryKeyField) {
    let reportees = [];

    if (rows && rows.length > 0) {
      for (let i = 0, len = rows.length; i < len; i++) {
        let row = rows[i];

        reportees[reportees.length] = row[primaryKeyField];
      }
    }

    return reportees;
  },
  hidePopup() {
    this.parentView.hide();
    this.sendActionOverride('showSearchResultDialog', this.parentView);
  },

  showPopup() {
    this.parentView.show();
  },

  sendActionOverride(actionName, event) {
    this[actionName] = actionName;
    this.sendAction(actionName, event);
  }

});
