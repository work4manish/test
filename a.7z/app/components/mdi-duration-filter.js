import Ember from 'ember';
import ObjectUtil from '../utils/object-util';

export default Ember.Component.extend({
  dateUtil: Ember.inject.service(),
  selected: null,
  selectedDurationLabel: '',
  onTabChange: 'onTabChange',
  dayFormat: 'DD',
  monthFormat: 'MMM',
  yearFormat: 'YYYY',
  durationMap: {
    D: 'd',
    W: 'w',
    M: 'M',
    Y: 'y'
  },

  actions: {
    onTabChange(selectedValue) {
      if (!this.isCalendarTab(selectedValue)) {
        this.updateSelected(selectedValue);
        this.setSelectedDurationLabel(selectedValue);
        this.sendAction('onTabChange', selectedValue);
      } else {
        this.set('showCustomDurationFilter', true);
      }
    }
  },

  updateSelected(selectedValue, type) {
    ObjectUtil.resetAll(this.filterItems, 'selected', false);

    if (type) {
      ObjectUtil.updateAttributeWhere('type', type, 'id', selectedValue, this.filterItems);
    }

    ObjectUtil.updateAttributeWhere('id', selectedValue, 'selected', true, this.filterItems);
  },

  sendOnTabChangeAction(fromDate, toDate) {
    this.set('selectedDurationLabel', this.getDateRage(fromDate, toDate));
    let selectedValue = fromDate + '||' + toDate;
    this.updateSelected(selectedValue, 'date');
    this.sendAction('onTabChange', selectedValue);
    this.hideDatePickerDialog();
  },

  getDateRage(fromDate, toDate) {
    if (!toDate && fromDate && String(fromDate).indexOf('||') > 0) {
      let derivedDateRange = this.deriveDateRange(fromDate, toDate);

      fromDate = derivedDateRange.fromDate;
      toDate = derivedDateRange.toDate;
    }


    let endDate = this.getEndDate(toDate);
    let startDate;

    if (!toDate) {
      for (let key in this.durationMap) {
        if (fromDate.toUpperCase().indexOf(key) > -1) {
          let factor = parseInt(fromDate.split(key)[0]);
          startDate = moment(endDate).add((factor * -1), this.durationMap[key]);
          //adding 4 days to ensure that new days falls exactly in next month
          startDate = startDate.add(4, 'days');
          //then getting the start of the month
          startDate = startDate.startOf('month');
          break;
        }
      }
    }

    let dateRange;
    let format = this.dayFormat + ' ' + this.monthFormat + ' ' + this.yearFormat;

    if (!startDate) {
      startDate = moment(fromDate);
    }

    if (startDate.year() === endDate.year()) {
      if (startDate.month() === endDate.month()) {
        dateRange = startDate.format(this.dayFormat) + ' - ' + endDate.format(format);
      } else {
        dateRange = startDate.format(this.dayFormat + ' ' + this.monthFormat) +' - '+ endDate.format(format);
      }
    } else {
      dateRange = startDate.format(format) +' - '+ endDate.format(format);
    }

    return dateRange;
  },

  deriveDateRange(fromDate/*, toDate*/) {
    let dates = fromDate.split('||');
    let derivedDateRange = {
      fromDate: this.get('dateUtil').getDateObject(dates[0]),
      toDate: this.get('dateUtil').getDateObject(dates[1]),
    };

    return derivedDateRange;
  },

  getEndDate(toDate) {
    let endDate;

    if (toDate) {
      endDate = this.get('dateUtil').getDateObject(toDate);
    }

    if (!endDate) {
      let currentDate = moment();

      endDate = currentDate.add(-currentDate.toDate().getDate(), 'days');
    }

    return endDate;
  },

  isCalendarTab(selectedValue) {
    let filterItems = this.get('filterItems');

    if (filterItems) {
      for (let i = 0; i < filterItems.length; i++) {
        let filterItem = filterItems[i];

        if ((selectedValue === filterItem.id || (selectedValue + '').toUpperCase() === 'CAL') && filterItem.type === 'date') {
          return true;
        }
      }
    }

    return false;
  },

  init() {
    this._super();

    this.setSelectedDurationLabel(this.selected);

    let filterItems = this.get('filterItems');

    if (filterItems) {
      for (let i = 0; i < filterItems.length; i++) {
        let filterItem = filterItems[i];

        if (filterItem.type === 'date') {
          var customClassNames = this.get('customClassNames');
          if (!customClassNames) {
            customClassNames = '';
          }

          filterItem.customClassNames = customClassNames + ' ' + 'mdi mdi-calendar';

          let datePickerConfig = {};

          if (filterItem.minDate) {
            datePickerConfig.min = this.get('dateUtil').getDateObject(filterItem.minDate).toDate();
          }

          if (filterItem.maxDate) {
            datePickerConfig.max = this.get('dateUtil').getDateObject(filterItem.maxDate).toDate();
          }

          this.set('dateRangeConfig', {
            title: 'Date Range',
            dateFormat: this.get('dateUtil').getDateFormat(),
            showFooter: true,
            okBtnText: 'DONE',
            onOk: this.sendOnTabChangeAction,
            onCancel: this.hideDatePickerDialog,
            callbackContext: this,
            datePickerConfig: datePickerConfig
          });
        }
      }
    }
  },

  setSelectedDurationLabel(selectedValue) {
    this.set('selectedDurationLabel', this.getDateRage(selectedValue));
  },

  showDatePickerDialog() {
    this.set('showCustomDurationFilter', true);
  },

  hideDatePickerDialog() {
    this.set('showCustomDurationFilter', false);
  },
});
