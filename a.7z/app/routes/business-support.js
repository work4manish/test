import Ember from 'ember';
import AuthenticatedRoute from 'supdash-ui-core/routes/authenticated-route';
import RouteProgressIndicator from 'supdash-ui-core/mixins/route-progress-indicator';
import AppConst from '../utils/app-const';

export default AuthenticatedRoute.extend(RouteProgressIndicator, {
  hideSecondaryNav: true,
  hideSecondaryTopBar: true,
  showModuleTitle: true,

  afterModel() {
    Ember.run.later(() => {
      Ember.getOwner(this).lookup('controller:top-bar').setAdminTopBar(true, AppConst.LABEL_BUSINESS_SUPPORT);
    });
  },
});
