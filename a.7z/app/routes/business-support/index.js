import Ember from 'ember';
import AppConst from '../../utils/app-const';

export default Ember.Route.extend({
  actions: {
    showDetails(actionItem) {
      console.log(actionItem);

      this.transitionTo('business-support.' + actionItem.routeName, {
        queryParams: {
          appTitle: actionItem.text
        }
      });
    }
  },

  afterModel() {
    Ember.run.later(() => {
      Ember.getOwner(this).lookup('controller:top-bar').setAdminTopBar(true, AppConst.LABEL_BUSINESS_SUPPORT);
    });
  },

  model() {
    return this.get('coreDataService').queryRecord('base', {
      screenName: 'businessSupportLP'
    });
  },

  setupController(controller, model) {
    let actionItems = model.get('info').actionItems;

    controller.setProperties({
      actionItems: actionItems,
      title: AppConst.LABEL_BUSINESS_SUPPORT
    });
  }
});
