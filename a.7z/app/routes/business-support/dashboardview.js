import Ember from 'ember';
import AuthenticatedRoute from 'supdash-ui-core/routes/authenticated-route';
import RouteProgressIndicator from 'supdash-ui-core/mixins/route-progress-indicator';
import RoleInfo from '../../mixins/role-info';

export default AuthenticatedRoute.extend(RouteProgressIndicator, RoleInfo, {
  hideSecondaryNav: true,
  hideSecondaryTopBar: true,
  showModuleTitle: true,
  gridServiceParams: null,

  filterGridObserver: Ember.observer('refreshGrid', function() {
    if (!this.refreshInProgress && this.refreshGrid) {
      this.controller.set('refreshGrid', this.get('refreshGrid'));
      this.set('refreshInProgress', true);

      Ember.run.next(() => {
        this.set('refreshInProgress', false);
        this.set('refreshGrid', false);
        this.controller.set('refreshGrid', this.get('refreshGrid'));
      });
    }
  }),

  actions: {
    filterGridData(searchString) {
      if (searchString.length >= 7 || searchString.length === 0) {
        this.updateGridServiceParams('userId', searchString);

        this.set('refreshGrid', true);
      }
    },

    onInfoClick(selectedRow) {
      this.loadRoleInfoPopup(selectedRow, this.controller);
    }
  },

  afterModel() {
    //to hide menu icon
    Ember.getOwner(this).lookup('controller:top-bar').setAdminTopBar(false);
  },

  setupController(controller) {
    controller.setProperties({
      title: 'User List',
      toolbarItems: this.getToolbarItems(),
      gridServiceParams: this.getGridServiceParams()
    });
  },

  getGridServiceParams() {
    this.set('gridServiceParams', this.gridServiceParams || {});
    this.set('gridServiceParams.screenName', 'dashboardViewUserList');

    return this.get('gridServiceParams');
  },

  updateGridServiceParams(key, value) {
    this.contoller.set('gridServiceParams.' + key, value);
  },

  getToolbarItems() {
    return [{
      "id": "exportUserAccess",
      "text": "Export User Access",
      "url": ""
    }, {
      "id": "exportAuditLog",
      "text": "Export Audit Log",
      "url": ""
    }, {
      "id": "exportRoleMatrix",
      "text": "Export Role Matrix",
      "url": ""
    }];
  }
});
