import Ember from 'ember';
import AuthenticatedRoute from 'supdash-ui-core/routes/authenticated-route';
import RouteProgressIndicator from 'supdash-ui-core/mixins/route-progress-indicator';
import AdminLabel from '../../utils/admin-label-const';
import NumberUtil from '../../utils/number-util';


export default AuthenticatedRoute.extend(RouteProgressIndicator, {
  hideSecondaryNav: true,
  showModuleTitle: true,
  hideSecondaryTopBar: true,
  coreDataService: Ember.inject.service(),
  screenName: 'adminUsersProfile',
  userEditProfileData: null,
  userEditRoleData: null,

  actions: {
    AddAUser() {
      this.createUserRole = this.store.createRecord('adminUserProfile', {
        actionType: 'createUserRole'
      });
      this.setPopupConfig();
    },

    updateGrid(searchString) {
      let isNumericValue = NumberUtil.isNumber(searchString);

      if (searchString && (isNumericValue && searchString.length >= 7 && searchString.length <= 10)) {

        this.controller.get('gridServiceParams').userId = searchString;
        this.refreshDOMElement('refreshGrid');

      } else if (searchString.length === 0) {
        delete this.controller.get('gridServiceParams').userId;
        this.refreshGrid(true);
      }
    },

    gridHoverOnDeactivateClick(id, row) {
      let urlPrifix = row.isRoleActive ? "disableuserrole" : "enableuserrole";
      let msg = row.isRoleActive ? "Deactivated" : "Activated";
      this.get('coreDataService').queryRecord('base', {
        screenName: 'adminUserProfileActivateDeActivate',
        roleId: row.userRoleId,
        userId: row.userPsId,
        url: urlPrifix
      }).then(( /*resp*/ ) => {
        this.refreshGrid(true);
        this.showSuccessMsg('profileScreenMsg', 'User: ' + row.userPsId + ' Role: ' + row.userRoleName + ' ' + msg + ' succesfully');

      }).catch((reason) => {
        this.showErrorMessage(reason.errors, 'profileScreenMsg');
      });
    },

    gridHoverOnEditClick(id, row) {
      this.createUserRole = this.store.createRecord('adminUserProfile', {
        userPsId: row.userPsId,
        userRoleId: row.userRoleId,
        userRoleName: row.userRoleName,
        userRoleType: row.userRoleType,
        actionType: 'updateUserRole'
      });

      this.store.queryRecord('adminInfo', {
        userId: row.userPsId,
        roleId: row.userRoleId
      }).then((info) => {
        let assignedRoles = info.get('assignedRoleInfo');
        this.createUserRole.setProperties({
          bfsHierarchyLevel2: assignedRoles.get('bfsHierarchyLevel2').toArray(),
          bfsHierarchyLevel3: assignedRoles.get('bfsHierarchyLevel3').toArray(),
          bfsHierarchyLevel4: assignedRoles.get('bfsHierarchyLevel4').toArray(),
          bfsHierarchyLevel6: assignedRoles.get('bfsHierarchyLevel6').toArray(),
          bankIds: assignedRoles.get('bankIds'),
          countryCodes: assignedRoles.get('availableCountries').toArray()
        });

        this.setPopupConfig();
        this.controller.setProperties({
          userEditProfileData: info.get('userInfo'),
          userEditRoleData: info.get('roleInfo')
        });
      }).catch((reason) => {
        this.showErrorMessage(reason.errors, 'profileScreenMsg');
      });

    },

    resetRefreshFlagToFalse() {
      this.refreshGrid(false);
    },


    onTabChange(tab) {
      let tabSelected = (tab === 'profile');

      if (this.createUserRole.get('userPsId')) {
        this.controller.set('showSelectOptions', true);
      } else {
        this.controller.set('showSelectOptions', false);
      }

      this.controller.setProperties({
        isActive: tabSelected
      });
    },

    activateSaveButton(disableOkBtn, validateArray) {
      this.controller.set('adminPopupConfig.disableOkBtn', disableOkBtn);
      this.validateArray = validateArray || [];
    },

    showSearchResultDialog(parentDialog) {
      this.openSearchResultDialog(parentDialog);
    }
  },

  openSearchResultDialog(parentDialog) {
    if (!this.controller.get('searchDialogConfig')) {
      this.controller.set('searchDialogConfig', {
        onOk: this.addReportees,
        onCancel: this.closeSearchResultDialog,
        callbackContext: this
      });
    }

    /* following needs to be set each time parentDialog refrence changes */
    this.controller.set('searchDialogConfig.disableOkBtn', true);
    this.controller.set('searchDialogConfig.parentDialog', parentDialog);
    this.controller.set('searchResultDialogVisible', true);
  },

  addReportees(selectedItems, parentDialog) {
    this.controller.set('newReportees', selectedItems);
    this.closeSearchResultDialog(parentDialog);
  },

  closeSearchResultDialog(parentDialog) {
    this.controller.set('searchResultDialogVisible', false);

    if (parentDialog) {
      parentDialog.show();
    }
  },

  beforeModel() {
    Ember.getOwner(this).lookup('controller:top-bar').setAdminTopBar(false);
  },

  setupController(controller) {
    let namespace = Ember.getOwner(this).lookup('adapter:application').namespace;

    controller.setProperties({
      title: AdminLabel.USERPROFILETITLE,
      exportAudit: AdminLabel.EXPORTAUDIT,
      exportToExcel: AdminLabel.EXPORTTOEXCEL,
      exportRoleMatrix: AdminLabel.EXPORTROLEMATRIX,
      exportRoleMatrixUrl: namespace + AdminLabel.EXPORTROLEMATRIXURL,
      exportAuditUrl: namespace + AdminLabel.EXPORTAUDITURL,
      exportToExcelUrl: namespace + AdminLabel.EXPORTTOEXCELURL,
      addUser: AdminLabel.ADDUSER,
      gridServiceParams: {
        screenName: this.screenName
      },
      gridItemId: 'UserAdmin_Users_Detail_Grid',
      rowActionItems: AdminLabel.ROWACTIONITEMS,
      isActive: true,
      selectedBankIds: []
    });
  },

  refreshGrid(refresh) {
    this.controller.set('refreshGrid', refresh);
  },

  refreshDOMElement(attr) {
    this.controller.set(attr, false);
    Ember.run.next(() => {
      this.controller.set(attr, true);
    });
  },

  setPopupConfig() {
    this.controller.setProperties({
      adminPopupConfig: {
        title: 'Add User',
        showFooter: true,
        okBtnText: 'Save',
        onOk: this.sendOnOkClick,
        onCancel: this.hideAdminDialog,
        callbackContext: this,
        tabsArrayConfig: AdminLabel.POPUPTABS,
        disableOkBtn: true,
      },
      addRolePopup: true,
      roleModel: this.createUserRole,
    });
  },

  hideAdminDialog( /*arg*/ ) {
    this.controller.setProperties({
      addRolePopup: false,
      isActive: true
    });
    Ember.$('.modal-backdrop.in').css({
      display: 'none'
    });
    delete this.createUserRole;
    this.controller.setProperties({
      userEditProfileData: null,
      userEditRoleData: null
    });
  },

  sendOnOkClick( /*arg*/ ) {

    if (this.validationFunction()) {
      return;
    }

    this.updateBankIds();

    this.createUserRole.save().then(( /*response*/ ) => {
      let actionType = this.createUserRole.get('actionType');
      let displayMsg = (actionType === 'updateUserRole') ? 'Record updated succesfully' : 'PSID Added succesfully';
      this.hideAdminDialog();
      this.controller.set('selectedBankIds', []);
      this.refreshGrid(true);

      this.showSuccessMsg('profileScreenMsg', displayMsg);
    }).catch((exception) => {
      this.showErrorMessage(exception.errors);
    });
  },

  validationFunction() {
    let fieldArray = this.validateArray;
    let selectedValueLength;

    if (Ember.isEmpty(this.createUserRole.get('userRoleName'))) {
      this.showSuccessMsg('errorMsg', 'Please Enter Role Name');
      return;
    }

    for (let i = 0; i <= fieldArray.length; i++) {

      switch (fieldArray[i]) {
        case "isBizHierarchyLevel2":
          selectedValueLength = this.createUserRole.get('bfsHierarchyLevel2') ? this.createUserRole.get('bfsHierarchyLevel2').length : 0;
          if (selectedValueLength === 0) {
            this.showSuccessMsg('errorMsg', 'Please select business function (Level 2)');
            return true;
          }
          break;
        case "isBizHierarchyLevel3":
          selectedValueLength = this.createUserRole.get('bfsHierarchyLevel3') ? this.createUserRole.get('bfsHierarchyLevel3').length : 0;
          if (selectedValueLength === 0) {
            this.showSuccessMsg('errorMsg', 'Please select business function (Level 3)');
            return true;
          }
          break;
        case "isBizHierarchyLevel4":
          selectedValueLength = this.createUserRole.get('bfsHierarchyLevel4') ? this.createUserRole.get('bfsHierarchyLevel4').length : 0;
          if (selectedValueLength === 0) {
            this.showSuccessMsg('errorMsg', 'Please select business function (Level 4)');
            return true;
          }
          break;
        case "isBizHierarchyLevel6":
          selectedValueLength = this.createUserRole.get('bfsHierarchyLevel6') ? this.createUserRole.get('bfsHierarchyLevel6').length : 0;
          if (selectedValueLength === 0) {
            this.showSuccessMsg('errorMsg', 'Please select business function (Level 6)');
            return true;
          }
          break;
        case "isAssgnCountries":
          selectedValueLength = this.createUserRole.get('countryCodes') ? this.createUserRole.get('countryCodes').length : 0;
          if (selectedValueLength === 0) {
            this.showSuccessMsg('errorMsg', 'Please select Country');
            return true;
          }
          break;
        case "isAssgnBankIds":
          // selectedValueLength = this.createUserRole.get('bankIds') ? this.createUserRole.get('bankIds').length : 0;
          // if (selectedValueLength == 0) {
          //   this.showSuccessMsg('errorMsg', 'Please select BankIds');
          //   return true;
          // }
          break;
        default:
          break;
      }
    }
  },


  showSuccessMsg(attr, msg) {
    this.controller.set(attr, msg);
    Ember.run.later(() => {
      this.controller.set(attr, false);
    }, 3000);
  },

  showErrorMessage(errors, type) {
    if (errors) {
      if (!(errors instanceof Array)) {
        errors = [errors];
      }

      let msg = '';
      let separator = ', ';
      for (var i = 0, len = errors.length; i < len; i++) {
        let error = errors[i];
        msg += error.details + separator;
      }

      msg = msg.substring(0, msg.length - separator.length);

      if (!type) {
        type = 'errorMsg';
      }

      this.showSuccessMsg(type, msg);
    }
  },

  updateBankIds() {
    let selectedBankIds = this.controller.get('selectedBankIds') || [];

    this.createUserRole.set('bankIds', selectedBankIds);
  }
});
