import Ember from 'ember';
import AuthenticatedRoute from 'supdash-ui-core/routes/authenticated-route';
import RouteProgressIndicator from 'supdash-ui-core/mixins/route-progress-indicator';
import convertToJSON from '../../../mixins/convert-to-json';
import OtherAttribTabs from '../../../mixins/other-attrib-tabs';

export default AuthenticatedRoute.extend(RouteProgressIndicator, convertToJSON, OtherAttribTabs, {
  hideSecondaryNav: true,
  showModuleTitle: true,
  refreshGrid: false,

  coreDataService: Ember.inject.service(),
  userCurrentRoleService: Ember.inject.service(),

  refreshGridObserver: Ember.observer('refreshGrid', function () {
    if (this.refreshGrid) {
      this.controller.set('reCreateGrid', false);

      Ember.run.next(() => {
        this.controller.set('reCreateGrid', true);
      });
    }
  }),

  actions: {
    onRoleChanged(role) {
      if (this.get('userCurrentRoleService').isLineManager()) {
        this.setAttr('additionalFilter', '', false);
      }

      this.removeAttributeId();
      this.updateOtherFilterTabs(role);     // this api will refresh the grid and chart
    },

    resetRefreshFlagToFalse() {
      this.refreshAll(false, false);
    },

    changedOtherAttribute(otherAttributeFilter) {
      this.removeAttributeId();
      this.setAttr('otherAttributeFilter', otherAttributeFilter);
    },

    selectAllDirectsReport(state) {
      this.removeAttributeId();
      this.setAttr('includeIndirectReports', state);
    },

    refreshOnDurationFilterChange(durationFilter) {
      this.removeAttributeId();
      this.setAttr('durationFilter', durationFilter);
    },

    onAdditionalFilterChanged(additionalFilter) {
      this.removeAttributeId();
      this.setAttr('additionalFilter', additionalFilter);
    },

    onPageFilterChanged(pageFilter) {
      this.removeAttributeId();
      this.setAttr('pageFilter', pageFilter);
    },

    detailSreenChartClick(event, showTotal) {
      let seriesCode = event.dataItem.seriesCode;

      if (showTotal) {
        let gridParams = this.controller.get('detailParmasForGrid');
        if (gridParams.attributeId) {
          delete gridParams.attributeId;
        }
      } else {
        this.controller.get('detailParmasForGrid').attributeId = seriesCode;
      }
      this.refreshAll(false, true);
    },

    showDetailDialog(selectedItem) {
      this.openDetailDialog(selectedItem);
    }
  },

  beforeModel: function(transition) {
    if (!Ember.isEmpty(transition.queryParams)) {
      this.durationFilter = transition.queryParams.durationFilter;
      this.includeIndirectReports = transition.queryParams.includeIndirectReports;
    }

  },

  model(params) {
    let userCurrentRole = this.get('userCurrentRoleService').getCurrentRole();

    let ravpromise = Ember.RSVP.hash({
      otherAttributeFilterModel: this.fetchOtherAttributeTabs(params.dashboard, userCurrentRole.roleId),
      dashboard: params.dashboard
    });

    return ravpromise;
  },

  setupController(controller, model) {
    this.sendActionToSecController(model.otherAttributeFilterModel);
    this.defaultControllerSetting(controller, model);
    this.controller.set('reCreateGrid', true);
  },

  defaultControllerSetting(controller, model) {
    let userCurrentRole = this.get('userCurrentRoleService').getCurrentRole();
    let moduleName = model.dashboard;
    let otherAttributeModel = model.otherAttributeFilterModel;

    let pageFilter = '';
    let chartId = moduleName + '_DetailView';
    let gridId = moduleName + '_Linamanager_Grid';
    let otherAttributeFilter = otherAttributeModel.get('otherAttributeFilter').findBy('selected', true);
    let otherAttributeFilterSelectedId = otherAttributeFilter ? otherAttributeFilter.id : '';

    controller.setProperties({
      detailParmasForChart: this.createServiceParams(pageFilter, chartId, userCurrentRole, otherAttributeFilterSelectedId, true),
      detailParmasForGrid: this.createServiceParams(pageFilter, gridId, userCurrentRole, otherAttributeFilterSelectedId, false),
      gridItemId: gridId,
      modelNameForModule: 'chartView',
      detailDialogConfig: {
        onOk: this.closeDetailDialog,
        callbackContext: this,
        dialogGridServiceParams: this.createServiceParams(pageFilter, gridId, userCurrentRole, otherAttributeFilterSelectedId, false, true)
      }
    });
  },

  createServiceParams(pageFilter, id, role, otherAttr, isChart, isDetailDialog) {
    let roleId = !Ember.isEmpty(role) ? role.roleId : '';
    let serviceParams = {
      pageFilter: pageFilter,
      additionalFilter: '',
      durationFilter: this.durationFilter,
      includeIndirectReports: this.includeIndirectReports,
      otherAttributeFilter: otherAttr,
      roleId: roleId,
      isLineManager: this.get('userCurrentRoleService').isLineManager(),
      screenName: 'detailScreen'
    };

    if (isDetailDialog) {
      serviceParams.screenName = 'detailScreenDialogBox';
    }

    if (isChart) {
      serviceParams.chartId = id;
    } else {
      serviceParams.gridId = id;
    }

    return serviceParams;
  },

  sendActionToSecController(model) {
    let owner = Ember.getOwner(this);
    let topBarSecondaryController = owner.lookup('controller:sup-top-bar-secondary');
    topBarSecondaryController.updateTopBarSecondary(model, this.includeIndirectReports);
  },

  refreshing(attr) {
    this.controller.set(attr, false);
    Ember.run.next(() => {
      this.controller.set(attr, true);
    });
  },

  setAttr(attr, val, refresh) {
    this.controller.get('detailParmasForChart')[attr] = val;
    this.controller.get('detailParmasForGrid')[attr] = val;
    this.controller.set('detailDialogConfig.dialogGridServiceParams.' + attr, val);

    if (refresh !== false) {
      this.refreshAll(true, true);
    }
  },

  refreshAll(chart, grid) {
    this.controller.setProperties({
      refreshChart: chart,
      refreshGrid: grid,
    });

    Ember.set(this, 'refreshGrid', false);
    Ember.run.next(() => {
      Ember.set(this, 'refreshGrid', grid);
    });
  },

  updateOtherFilterTabs(role) {
    this.fetchOtherAttributeTabs(this.currentModel.dashboard, role).then((response) => {
      let otherFilterItems = this.convertToJSON(response.get('otherAttributeFilter'));
      let selectedObject = otherFilterItems.findBy('selected', true);
      let otherAttributeFilter = (!Ember.isEmpty(selectedObject)) ? selectedObject.id : '';
      this.setAttr('roleId', role, false);
      this.setAttr('isLineManager', this.get('userCurrentRoleService').isLineManager(), false);
      this.setAttr('otherAttributeFilter', otherAttributeFilter, false);
      this.refreshAll(true, true);
      this.sendActionToSecController(response);
    });
  },

  removeAttributeId() {
    let gridParams = this.controller.get('detailParmasForGrid');

    if (gridParams.attributeId) {
      delete gridParams.attributeId;
    }
  },

  openDetailDialog(selectedItem) {
    this.controller.set('detailDialogConfig.dialogGridServiceParams.configRequired', true);
    this.controller.set('detailDialogConfig.selectedRowId', selectedItem.attributeId);
    this.controller.set('detailDialogVisible', true);
  },

  closeDetailDialog() {
    this.controller.set('detailDialogVisible', false);
  }
});
