import Ember from 'ember';
import AuthenticatedRoute from 'supdash-ui-core/routes/authenticated-route';
import RouteProgressIndicator from 'supdash-ui-core/mixins/route-progress-indicator';
import NumberUtil from '../../utils/number-util';
const {getOwner} = Ember;

export default AuthenticatedRoute.extend(RouteProgressIndicator, {
  hideSecondaryNav: true,
  hideSecondaryTopBar: true,
  showModuleTitle: true,
  coreDataService: Ember.inject.service(),
  preference: Ember.inject.service('corePreference'),
  dateUtil: Ember.inject.service(),

  actions: {
    onKeyupSearchText(searchString/*, selectedSearchCriteria*/) {
      let isNumericValue = NumberUtil.isNumber(searchString);

      if (searchString && !this.isSearchInProgress &&
          ((!isNumericValue && searchString.length >= 3) || (isNumericValue && searchString.length >= 7))) {

        this.isSearchInProgress = true;

        this.get('coreDataService').queryRecord('list-view-item', {
          searchParm: searchString,
          screenName: 'searchView',
          /*selectedSearchCriteria: selectedSearchCriteria*/
        }).then((searchListViewItem) => {

          this.isSearchInProgress = false;

          if (!this.controller.get('listViewConfig', searchListViewItem.get('listConfig'))) {
            this.controller.set('listViewConfig', null);
          }

          this.controller.set('searchResults', searchListViewItem.get('listData').data);
        }).catch((reason) => {
          console.log(reason);
        });
      } else if (searchString.length === 0 && this.controller.get('searchResults') &&
        this.controller.get('searchResults').length > 0) {
        this.controller.set('searchResults', []);
      }
    },

    onRowClick(rowId) {
      Ember.$('.base-search-box').val(this.getValueFor('name', rowId));

      this.transitionTo('home.search.detail', rowId, {
        queryParams: {
          appTitle: 'Back'
        }
      });
    }
  },

  beforeModel() {
    getOwner(this).lookup('controller:top-bar').setSearchActive(true);
  },

  deactivate() {
    getOwner(this).lookup('controller:top-bar').setSearchActive(false);
  },

  setupController(controller/*,  model*/) {
    controller.setProperties({
      listViewConfig: null,
      searchResults: [],
      dialogConfig: {
        title: 'Date Range',
        dateFormat: this.get('preference').getDateFormat(),
        showFooter: true,
        okBtnText: 'DONE',
        onOk: this.setCustomDurantion,
        onCancel: this.hideDatePickerDialog,
        callbackContext: this
      }
    });
  },

  getValueFor(key, value) {
    let searchResults = this.controller.get('searchResults');

    for (let i = 0, len = searchResults.length; i < len; i++) {
      let searchItem = searchResults[i];

      if (String(searchItem['id']) === String(value)) {
        return searchItem[key];
      }
    }

    return '';
  },

  showDatePickerDialog(searchCriteriaComponent, customMenuItem) {
    if (searchCriteriaComponent) {
      this.searchCriteriaComponent = searchCriteriaComponent;
    }
    this.controller.setProperties({
      datePickerConfig: {
        min: this.get('dateUtil').getDateObject(customMenuItem.minDate).toDate(),
        max: this.get('dateUtil').getDateObject(customMenuItem.maxDate).toDate()
      },
      showDateRangeDialog: true
    });
  },

  hideDatePickerDialog() {
    this.controller.set('showDateRangeDialog', false);
  },

  setCustomDurantion(fromDate, toDate) {
    let customDuration = this.getSelectedDateRange(fromDate, toDate);

    this.searchCriteriaComponent.mdiContextMenu.updateIdForMenuItem('Custom', customDuration, 'header');
    this.searchCriteriaComponent.updateTopBarSearchCriteria();
    this.hideDatePickerDialog();
  },

  getSelectedDateRange(fromDate, toDate) {
    return fromDate + '||' + toDate;
  },

  willDestroy() {
    this.searchCriteriaComponent = null;
  }
});
