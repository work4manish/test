/*import JSONAPISerializer from 'ember-data/serializers/json-api';

export default JSONAPISerializer.extend({
});
*/

import DS from 'ember-data';

export default DS.RESTSerializer.extend(DS.EmbeddedRecordsMixin, {
  attrs: {
    contextItems: {
      embedded: 'always'
    },
    dashboardTypes: {
      embedded: 'always'
    }
  }
});
