import Ember from 'ember';
import DS from 'ember-data';

export default DS.RESTSerializer.extend({
  serializeIntoHash: function(hash, type, record, options) {
    Ember.merge(hash, this.serialize(record, options));
  },

  serialize(record /*, options*/ ) {
    let newRecord = record.record.toJSON();

    for (let key in newRecord) {
      if (key.indexOf('bfsHierarchyLevel') !== -1 && typeof(newRecord[key]) === 'object' && newRecord[key].length > 0) {
        newRecord[key] = Ember.A(newRecord[key]).mapBy('code');
      } else if (key.indexOf('countryCodes') !== -1 && typeof(newRecord[key]) === 'object' && newRecord[key].length > 0) {
        newRecord[key] = Ember.A(newRecord[key]).mapBy('countryCode');
      } else if (key.indexOf('actionType') !== -1 && typeof(newRecord[key]) === 'string') {
        delete newRecord[key];
      }
    }
    return newRecord;
  }
});
