//import Ember from 'ember';
import DS from 'ember-data';

export default DS.RESTSerializer.extend(DS.EmbeddedRecordsMixin, {

attrs: {
    assignedRoleInfo: {
      embedded: 'always'
    },
    roleInfo: {
      embedded: 'always'
    },
    userInfo: {
      embedded: 'always'
    }
  },

  normalizeResponse(store, primaryModelClass, payload, id, requestType) {

    payload.adminInfo = payload.editUserRole;
    payload.adminInfo.id = payload.adminInfo.userInfo.userPsId;

    delete  payload.editUserRole;

    return this._super(store, primaryModelClass, payload, id, requestType);
  }
});
