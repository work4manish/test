import { moduleForComponent, test } from 'ember-qunit';
import hbs from 'htmlbars-inline-precompile';

moduleForComponent('mdi-duration-filter', 'Integration | Component | mdi duration filter', {
  integration: true
});

test('it renders', function(assert) {
  // Set any properties with this.set('myProperty', 'value');
  // Handle any actions with this.on('myAction', function(val) { ... });

  this.render(hbs`{{mdi-duration-filter}}`);

  assert.equal(this.$().text().trim(), '');

  // Template block usage:
  this.render(hbs`
    {{#mdi-duration-filter}}
      template block text
    {{/mdi-duration-filter}}
  `);

  assert.equal(this.$().text().trim(), 'template block text');
});
