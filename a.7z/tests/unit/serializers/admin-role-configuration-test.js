import { moduleForModel, test } from 'ember-qunit';

moduleForModel('admin-role-configuration', 'Unit | Serializer | admin role configuration', {
  // Specify the other units that are required for this test.
  needs: ['serializer:admin-role-configuration']
});

// Replace this with your real tests.
test('it serializes records', function(assert) {
  let record = this.subject();

  let serializedRecord = record.serialize();

  assert.ok(serializedRecord);
});
