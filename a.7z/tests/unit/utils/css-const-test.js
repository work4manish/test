import cssConst from 'supdash-ui-app/utils/css-const';
import { module, test } from 'qunit';

module('Unit | Utility | css const');

// Replace this with your real tests.
test('it works', function(assert) {
  let result = cssConst();
  assert.ok(result);
});
