import adminLabelConst from 'supdash-ui-app/utils/admin-label-const';
import { module, test } from 'qunit';

module('Unit | Utility | admin label const');

// Replace this with your real tests.
test('it works', function(assert) {
  let result = adminLabelConst();
  assert.ok(result);
});
