import Ember from 'ember';
import MdiGridCheckboxRowHelperMixin from 'supdash-ui-app/mixins/mdi-grid-checkbox-row-helper';
import { module, test } from 'qunit';

module('Unit | Mixin | mdi grid checkbox row helper');

// Replace this with your real tests.
test('it works', function(assert) {
  let MdiGridCheckboxRowHelperObject = Ember.Object.extend(MdiGridCheckboxRowHelperMixin);
  let subject = MdiGridCheckboxRowHelperObject.create();
  assert.ok(subject);
});
