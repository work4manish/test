import Ember from 'ember';
import ModulePrefixProviderMixin from 'supdash-ui-app/mixins/module-prefix-provider';
import { module, test } from 'qunit';

module('Unit | Mixin | module prefix provider');

// Replace this with your real tests.
test('it works', function(assert) {
  let ModulePrefixProviderObject = Ember.Object.extend(ModulePrefixProviderMixin);
  let subject = ModulePrefixProviderObject.create();
  assert.ok(subject);
});
