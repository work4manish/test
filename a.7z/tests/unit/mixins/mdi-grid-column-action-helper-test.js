import Ember from 'ember';
import MdiGridColumnActionHelperMixin from 'supdash-ui-app/mixins/mdi-grid-column-action-helper';
import { module, test } from 'qunit';

module('Unit | Mixin | mdi grid column action helper');

// Replace this with your real tests.
test('it works', function(assert) {
  let MdiGridColumnActionHelperObject = Ember.Object.extend(MdiGridColumnActionHelperMixin);
  let subject = MdiGridColumnActionHelperObject.create();
  assert.ok(subject);
});
