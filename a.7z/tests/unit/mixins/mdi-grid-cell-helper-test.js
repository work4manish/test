import Ember from 'ember';
import MdiGridCellHelperMixin from 'supdash-ui-app/mixins/mdi-grid-cell-helper';
import { module, test } from 'qunit';

module('Unit | Mixin | mdi grid cell helper');

// Replace this with your real tests.
test('it works', function(assert) {
  let MdiGridCellHelperObject = Ember.Object.extend(MdiGridCellHelperMixin);
  let subject = MdiGridCellHelperObject.create();
  assert.ok(subject);
});
