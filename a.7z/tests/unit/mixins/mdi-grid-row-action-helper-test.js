import Ember from 'ember';
import MdiGridRowActionHelperMixin from 'supdash-ui-app/mixins/mdi-grid-row-action-helper';
import { module, test } from 'qunit';

module('Unit | Mixin | mdi grid row action helper');

// Replace this with your real tests.
test('it works', function(assert) {
  let MdiGridRowActionHelperObject = Ember.Object.extend(MdiGridRowActionHelperMixin);
  let subject = MdiGridRowActionHelperObject.create();
  assert.ok(subject);
});
