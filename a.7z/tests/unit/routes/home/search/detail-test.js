import { moduleFor, test } from 'ember-qunit';

moduleFor('route:home/search/detail', 'Unit | Route | home/search/detail', {
  // Specify the other units that are required for this test.
  // needs: ['controller:foo']
});

test('it exists', function(assert) {
  let route = this.subject();
  assert.ok(route);
});
