import { moduleFor, test } from 'ember-qunit';

moduleFor('adapter:admin-role-info', 'Unit | Adapter | admin role info', {
  // Specify the other units that are required for this test.
  // needs: ['serializer:foo']
});

// Replace this with your real tests.
test('it exists', function(assert) {
  let adapter = this.subject();
  assert.ok(adapter);
});
