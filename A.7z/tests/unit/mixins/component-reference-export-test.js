import Ember from 'ember';
import ComponentReferenceExportMixin from 'supdash-ui-app/mixins/component-reference-export';
import { module, test } from 'qunit';

module('Unit | Mixin | component reference export');

// Replace this with your real tests.
test('it works', function(assert) {
  let ComponentReferenceExportObject = Ember.Object.extend(ComponentReferenceExportMixin);
  let subject = ComponentReferenceExportObject.create();
  assert.ok(subject);
});
