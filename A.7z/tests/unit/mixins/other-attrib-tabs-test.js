import Ember from 'ember';
import OtherAttribTabsMixin from 'supdash-ui-app/mixins/other-attrib-tabs';
import { module, test } from 'qunit';

module('Unit | Mixin | other attrib tabs');

// Replace this with your real tests.
test('it works', function(assert) {
  let OtherAttribTabsObject = Ember.Object.extend(OtherAttribTabsMixin);
  let subject = OtherAttribTabsObject.create();
  assert.ok(subject);
});
