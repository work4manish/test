import Ember from 'ember';
import ComponentSupportMixin from 'supdash-ui-app/mixins/component-support';
import { module, test } from 'qunit';

module('Unit | Mixin | component support');

// Replace this with your real tests.
test('it works', function(assert) {
  let ComponentSupportObject = Ember.Object.extend(ComponentSupportMixin);
  let subject = ComponentSupportObject.create();
  assert.ok(subject);
});
