import Ember from 'ember';
import ConvertToJSONMixin from 'supdash-ui-app/mixins/convert-to-json';
import { module, test } from 'qunit';

module('Unit | Mixin | convert to json');

// Replace this with your real tests.
test('it works', function(assert) {
  let ConvertToJSONObject = Ember.Object.extend(ConvertToJSONMixin);
  let subject = ConvertToJSONObject.create();
  assert.ok(subject);
});
