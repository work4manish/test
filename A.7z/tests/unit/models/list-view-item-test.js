import { moduleForModel, test } from 'ember-qunit';

moduleForModel('list-view-item', 'Unit | Model | list view item', {
  // Specify the other units that are required for this test.
  needs: []
});

test('it exists', function(assert) {
  let model = this.subject();
  // let store = this.store();
  assert.ok(!!model);
});
