import objectUtil from 'supdash-ui-app/utils/object-util';
import { module, test } from 'qunit';

module('Unit | Utility | object util');

// Replace this with your real tests.
test('it works', function(assert) {
  let result = objectUtil();
  assert.ok(result);
});
