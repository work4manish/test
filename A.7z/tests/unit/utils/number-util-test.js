import numberUtil from 'supdash-ui-app/utils/number-util';
import { module, test } from 'qunit';

module('Unit | Utility | number util');

// Replace this with your real tests.
test('it works', function(assert) {
  let result = numberUtil();
  assert.ok(result);
});
