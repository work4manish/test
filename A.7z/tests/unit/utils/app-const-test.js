import appConst from 'supdash-ui-app/utils/app-const';
import { module, test } from 'qunit';

module('Unit | Utility | app const');

// Replace this with your real tests.
test('it works', function(assert) {
  let result = appConst();
  assert.ok(result);
});
