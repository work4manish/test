import { moduleForModel, test } from 'ember-qunit';

moduleForModel('business-function', 'Unit | Serializer | business function', {
  // Specify the other units that are required for this test.
  needs: ['serializer:business-function']
});

// Replace this with your real tests.
test('it serializes records', function(assert) {
  let record = this.subject();

  let serializedRecord = record.serialize();

  assert.ok(serializedRecord);
});
