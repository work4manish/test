import { moduleForModel, test } from 'ember-qunit';

moduleForModel('role-configuration', 'Unit | Serializer | role configuration', {
  // Specify the other units that are required for this test.
  needs: ['serializer:role-configuration']
});

// Replace this with your real tests.
test('it serializes records', function(assert) {
  let record = this.subject();

  let serializedRecord = record.serialize();

  assert.ok(serializedRecord);
});
