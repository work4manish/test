import Model from 'ember-data/model';
import attr from 'ember-data/attr';

export default Model.extend({
  userPsId: attr('string'),
  userRoleId: attr('string'),
  userRoleName: attr('string'),
  userRoleType: attr('string'),
  bfsHierarchyLevel2:attr('array'),
  bfsHierarchyLevel3: attr('array'),
  bfsHierarchyLevel4: attr('array'),
  bfsHierarchyLevel6: attr('array'),
  bankIds: attr('array'),
  countryCodes: attr('array')
});
