import Role from './admin-available-role';
import attr from 'ember-data/attr';

export default Role.extend({
  isBizHierarchyLevel2: attr('boolean'),
  dftlBizHierarchyLevel2: attr('string'),
  excldBizHierarchyLevel2: attr('string'),
  multiBizHierarchyLevel2: attr('boolean'),

  isBizHierarchyLevel3: attr('boolean'),
  dftlBizHierarchyLevel3: attr('string'),
  excldBizHierarchyLevel3: attr('string'),
  multiBizHierarchyLevel3: attr('boolean'),

  isBizHierarchyLevel4: attr('boolean'),
  dftlBizHierarchyLevel4: attr('string'),
  excldBizHierarchyLevel4: attr('string'),
  multiBizHierarchyLevel4: attr('boolean'),

  isBizHierarchyLevel6: attr('boolean'),
  dftlBizHierarchyLevel6: attr('string'),
  excldBizHierarchyLevel6: attr('string'),
  multiBizHierarchyLevel3: attr('boolean'),

  isAssgnCountries: attr('boolean'),
  isAssgnBankIds: attr('boolean'),
  defaultAttributeCode: attr('string')
});
