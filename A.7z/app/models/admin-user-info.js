import Model from 'ember-data/model';
import attr from 'ember-data/attr';

export default Model.extend({
  userPsId: attr('string'),
  supvsrId: attr('string'),
  supvsrName: attr('string'),
  userName: attr('string'),
  userRegion: attr('string'),
  userCountry: attr('string'),
  department: attr('string'),
  isUserActive: attr('string'),
  bizFuncLevel2: attr('string'),
  bizDivLevel3: attr('string'),
  bizSecLevel4: attr('string'),
  bizFuncLevel6: attr('string'),
  bizFunction: attr(),
  existingRoles: attr()
});

