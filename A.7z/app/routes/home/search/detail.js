import Ember from 'ember';
import AuthenticatedRoute from 'supdash-ui-core/routes/authenticated-route';
import RouteProgressIndicator from 'supdash-ui-core/mixins/route-progress-indicator';

export default AuthenticatedRoute.extend(RouteProgressIndicator, {
  hideSecondaryNav: true,
  hideSecondaryTopBar: true,
  showModuleTitle: true,
  coreDataService: Ember.inject.service(),
  screenName: 'searchDetailView',

  actions: {
    onChartSeriesClickAction(series, showTotal) {
      if (showTotal) {
        this.controller.set('renderGrid', false);

        return;
      }

      this.controller.set('renderGrid', false);

      Ember.run.next(() => {
        this.updateGridServiceParams({
          screenName: this.screenName,
          userId: this.selectedRecordId,
          dashboardName: series.dataItem.seriesCode,
          durationFilter: this.getSearchCriteria('duration')
        });

        this.controller.setProperties({
          renderGrid: true,
          gridItemId: 'Linamanager_Grid',
          gridServiceParams: this.getGridServiceParams()
        });
      });
    },

    showDetails(selectedItem) {
      this.openDetailGridDialog(selectedItem);
    }
  },

  beforeModel() {
    this.controllerFor('home.search').setProperties({
      detailActiveCls: 'detail-active'
    });
  },

  model(params /*, transition*/ ) {
    this.selectedRecordId = params.psId;

    return this.get('coreDataService').queryRecord('base', {
      userId: this.selectedRecordId,
      screenName: this.screenName,
      durationFilter: this.getSearchCriteria('duration')
    });
  },

  deactivate() {
    this.controllerFor('home.search').setProperties({
      detailActiveCls: ''
    });
  },

  setupController(controller, model) {
    controller.setProperties({
      renderGrid: false,
      serviceParams: this.getGridServiceParams(),
      topBarInfo: model.get('info').topBarInfo,
      detailGridDialogConfig: {
        onOk: this.closeDetailGridDialog,
        callbackContext: this,
        detailGridServiceParams: this.getDetailGridServiceParams()
      }
    });
  },

  updateGridServiceParams(params) {
    let detailGridParamsExist = this.controller.get('detailGridDialogConfig') &&
                                  this.controller.get('detailGridDialogConfig.detailGridServiceParams');
    for (let paramName in params) {
      if (params.hasOwnProperty(paramName)) {
        this.controller.set('gridServiceParams.' + [paramName], params[paramName]);

        if (detailGridParamsExist) {
          this.controller.set('detailGridDialogConfig.detailGridServiceParams.' + [paramName], params[paramName]);
        }
      }
    }
  },

  getGridServiceParams() {
    if (!this.controller.get('gridServiceParams')) {
      this.controller.set('gridServiceParams', {
        userId: this.selectedRecordId,
        screenName: this.screenName,
        chartId: 'Search_View_By_Dashboard',
        gridId: 'Linamanager_Grid',
        durationFilter: this.getSearchCriteria('duration'),
        dashboardName: this.getSearchCriteria('exceptionReport'),
        dashboardName1: this.getSearchCriteria('generalReport')
      });
    }

    return this.controller.get('gridServiceParams');
  },

  getDetailGridServiceParams() {
    var detailGridServiceParams = Ember.copy(this.getGridServiceParams(), true);

    return detailGridServiceParams;
  },

  getSearchCriteria(type) {
    let topBarController = Ember.getOwner(this).lookup('controller:top-bar');
    let selectedSearchCriteria = topBarController.get('selectedSearchCriteria');

    if (type) {
      for (let i = 0, len = selectedSearchCriteria.length; i < len; i++) {
        let criteriaItem = selectedSearchCriteria[i];

        if (criteriaItem.type === type) {
          return criteriaItem.id;
        }
      }
    }
  },

  openDetailGridDialog(selectedItem) {
    this.controller.set('detailGridDialogConfig.selectedRowId', selectedItem.attributeId);
    this.controller.set('showDetailGridDialog', true);
  },

  closeDetailGridDialog() {
    this.controller.set('showDetailGridDialog', false);
  }
});
