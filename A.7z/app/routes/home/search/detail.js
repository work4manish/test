import Ember from 'ember';
import AuthenticatedRoute from 'supdash-ui-core/routes/authenticated-route';
import RouteProgressIndicator from 'supdash-ui-core/mixins/route-progress-indicator';

export default AuthenticatedRoute.extend(RouteProgressIndicator, {
  hideSecondaryNav: true,
  hideSecondaryTopBar: true,
  showModuleTitle: true,
  coreDataService: Ember.inject.service(),
  screenName: 'searchDetailView',

  actions: {
    onChartSeriesClickAction(series, showTotal) {
      if (showTotal) {
        this.controller.set('renderGrid', false);

        return;
      }

      this.controller.set('renderGrid', false);

      Ember.run.next(() => {
        this.controller.setProperties({
          renderGrid: true,
          gridItemId: 'Linamanager_Grid',
          gridServiceParams: {
            screenName: this.screenName,
            userId: this.selectedRecordId,
            dashboardName: series.dataItem.seriesCode,
            durationFilter: this.getSearchCriteria('duration')
          }
        });
      });
    }
  },

  beforeModel() {
    this.controllerFor('home.search').setProperties({
      detailActiveCls: 'detail-active'
    });
  },

  model(params /*, transition*/ ) {
    this.selectedRecordId = params.psId;

    return this.get('coreDataService').queryRecord('base', {
      userId: this.selectedRecordId,
      screenName: this.screenName,
      durationFilter: this.getSearchCriteria('duration')
    });
  },

  deactivate() {
    this.controllerFor('home.search').setProperties({
      detailActiveCls: ''
    });
  },

  setupController(controller, model) {
    controller.setProperties({
      renderGrid: false,
      serviceParams: {
        userId: this.selectedRecordId,
        screenName: this.screenName,
        chartId: 'Search_View_By_Dashboard',
        durationFilter: this.getSearchCriteria('duration'),
        dashboardName: this.getSearchCriteria('exceptionReport'),
        dashboardName1: this.getSearchCriteria('generalReport')
      },
      topBarInfo: model.get('info').topBarInfo
    });
  },

  getSearchCriteria(type) {
    let topBarController = Ember.getOwner(this).lookup('controller:top-bar');
    let selectedSearchCriteria = topBarController.get('selectedSearchCriteria');

    if (type) {
      for (let i = 0, len = selectedSearchCriteria.length; i < len; i++) {
        let criteriaItem = selectedSearchCriteria[i];

        if (criteriaItem.type === type) {
          return criteriaItem.id;
        }
      }
    }
  }
});
