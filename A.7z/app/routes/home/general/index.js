import Ember from 'ember';
import AuthenticatedRoute from 'supdash-ui-core/routes/authenticated-route';
import RouteProgressIndicator from 'supdash-ui-core/mixins/route-progress-indicator';
import OtherAttribTabs from '../../../mixins/other-attrib-tabs';

export default AuthenticatedRoute.extend(RouteProgressIndicator, OtherAttribTabs, {
  hideSecondaryNav: false,
  userCurrentRoleService: Ember.inject.service(),
  backActionObserver: Ember.observer('topBarContoller.backActionPerformed', function() {
    if (this.topBarContoller&& this.topBarContoller.backActionPerformed) {
      this.restoreLandingScreenState();
    }
  }),

  actions: {
    onMenuItemClicked(menuItem) {
      let queryParams = Ember.copy(menuItem);
      queryParams.appTitle = menuItem.title;

      this.transitionTo('home.general.generaldetail', menuItem.id, {
        queryParams: queryParams
      });
    }
  },

  init() {
    this._super();
    this.topBarContoller = Ember.getOwner(this).lookup('controller:top-bar');
    this.secTopBarContoller = Ember.getOwner(this).lookup('controller:sup-top-bar-secondary');
  },

  restoreLandingScreenState() {
    let role = this.get('userCurrentRoleService').getCurrentRole();
    let dashboard = '';
    let secondaryNav = Ember.getOwner(this).lookup('controller:sup-secondary-nav');

    secondaryNav.deselectAll();

    this.fetchOtherAttributeTabs(dashboard, role.roleId).then((response) => {
      response.set('dashboardTabsVisible', true);
      response.set('hideToggleAllOnDetail', true);
      this.secTopBarContoller.updateTopBarSecondary(response);
    });
  }
});
