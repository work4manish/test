import Ember from 'ember';
import AuthenticatedRoute from 'supdash-ui-core/routes/authenticated-route';
import RouteProgressIndicator from 'supdash-ui-core/mixins/route-progress-indicator';
import OtherAttribTabs from '../../../mixins/other-attrib-tabs';
import AppConst from '../../../utils/app-const';

export default AuthenticatedRoute.extend(RouteProgressIndicator, OtherAttribTabs, {
  hideSecondaryNav: false,
  showModuleTitle: true,
  currentDashboard: null,

  actions: {
    onMenuItemClicked(menuItem) {
      this.currentDashboard = menuItem.id;
      this.updateModuleTitle(menuItem.title);
      this.loadDashboard(this.currentDashboard);
    },

    onRoleChanged(role, roleName) {
      this.reRenderDashboard(role, roleName);
    },

    //TODO: rename this action
    selectAllDirectsReport( /*state*/ ) {
      this.refreshData();
    },

    changedOtherAttribute() {
      this.refreshData();
    }
  },

  init() {
    this._super();
    this.secTopBarContoller = Ember.getOwner(this).lookup('controller:sup-top-bar-secondary');
    this.topBarContoller = Ember.getOwner(this).lookup('controller:top-bar');
  },

  model(params/*, transition*/) {
    this.currentDashboard = params.dashboard;
  },

  setupController( /*model, controller*/ ) {
    this.updateAppliedFilters();
    this.loadDashboard(this.currentDashboard);
  },

  loadDashboard(dashboardId) {
    this.controller.set('selectedDashboard', dashboardId);
    let appliedFilters = this.getAppliedFilters();
    this.reRenderDashboard(appliedFilters.roleId, appliedFilters.roleName);
  },

  updateAppliedFilters(attribName, attribValue) {
    if (attribName) {
      //NOTE: this wont send request to server.
      this.controller.set('selectedFilters.' + attribName, attribValue);
    } else {
      let filters = this.secTopBarContoller.getAppliedFilters();
      filters.dashboardId = this.controller.get('selectedDashboard');
      filters.category = 'General';

      if (filters.roleName === AppConst.LINE_MANAGER) {
        filters.otherAttributeFilter = '';
      }

      this.controller.set('selectedFilters', filters);
    }
  },

  updateModuleTitle(title) {
    this.topBarContoller.setAppTitle(title);
  },

  getAppliedFilters() {
    return this.controller.get('selectedFilters');
  },

  refreshData() {
    console.log('Changing the filter: It will update the dashboard grid');
    this.updateAppliedFilters();
  },

  reRenderDashboard(roleId, roleName) {
    this.fetchOtherAttributeTabs(this.controller.get('selectedDashboard'), roleId).then((response) => {
      response.set('dashboardTabsVisible', false);
      let includeIndirects = this.controller.get('selectedFilters.includeIndirectReports');

      if (roleName === AppConst.LINE_MANAGER) {
        response.set('dashboardTabsVisible', true);
        response.set('hideToggleAllOnDetail', true);
      }

      this.secTopBarContoller.updateTopBarSecondary(response, includeIndirects);

      this.updateAppliedFilters();

      this.controller.set('renderDashboard', false);

      Ember.run.later(() => {
        this.controller.set('renderDashboard', true);
      });
    });
  }
});
