import Ember from 'ember';
import AuthenticatedRoute from 'supdash-ui-core/routes/authenticated-route';
import RouteProgressIndicator from 'supdash-ui-core/mixins/route-progress-indicator';
import AdminLabel from '../../utils/admin-label-const';

export default AuthenticatedRoute.extend(RouteProgressIndicator, {
  actions: {
    gotoUserProfiles() {
      Ember.getOwner(this).lookup('controller:top-bar').setAdminTopBar(false);
      this.transitionTo('admin.userprofiles', {
        queryParams: {
          appTitle: AdminLabel.USERPROFILETITLE
        }
      });
    }

  },

  beforeModel() {
    Ember.getOwner(this).lookup('controller:top-bar').setAdminTopBar(true);
  },

  setupController(controller) {
    controller.setProperties({
      title: AdminLabel.HEADERTITLE,
      UserProfile: AdminLabel.USERPROFILETITLE
    });
  }
});
