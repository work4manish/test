import Ember from 'ember';
import AuthenticatedRoute from 'supdash-ui-core/routes/authenticated-route';
import RouteProgressIndicator from 'supdash-ui-core/mixins/route-progress-indicator';
import AdminLabel from '../../utils/admin-label-const';
import NumberUtil from '../../utils/number-util';


export default AuthenticatedRoute.extend(RouteProgressIndicator, {
  hideSecondaryNav: true,
  showModuleTitle: true,
  hideSecondaryTopBar: true,
  coreDataService: Ember.inject.service(),
  screenName: 'adminUsersProfile',

  actions: {
    AddAUser() {
      this.createUserRole = this.store.createRecord('createUserRole');
      this.setPopupConfig();
    },

    updateGrid(searchString) {
      let isNumericValue = NumberUtil.isNumber(searchString);

      if (searchString && (isNumericValue && searchString.length >= 7 && searchString.length <= 10)) {

        this.controller.get('gridServiceParams').userId = searchString;
        this.refreshDOMElement('refreshGrid');

      } else if (searchString.length === 0) {
        delete this.controller.get('gridServiceParams').userId;
        this.refreshGrid(true);
      }
    },

    gridHoverOnDeactivateClick(a,b){
      console.log(a,b);
    },

    gridHoverOnEditClick(data){
      console.log(data);
    },

    resetRefreshFlagToFalse() {
      this.refreshGrid(false);
    },


    onTabChange(tab) {
      let tabSelected = (tab === 'profile');

      // if(tabSelected){
      //   this.controller.set('adminPopupConfig.disableOkBtn', true);
      // }

      this.controller.setProperties({
        isActive: tabSelected
      });
    },

    activateSaveButton(validateArray) {
      this.controller.set('adminPopupConfig.disableOkBtn', false);
      this.validateArray = validateArray;
    }

  },

  beforeModel() {
    Ember.getOwner(this).lookup('controller:top-bar').setAdminTopBar(false);
  },

  setupController(controller) {
    let namespace = Ember.getOwner(this).lookup('adapter:application').namespace;
    let rowActionItems = [{
      "id": "deactivate",
      "title": "Deactivate User",
      "iconClass": "mdi mdi-lock",
      "action": "gridHoverOnDeactivateClick"
    }, {
      "id": "editUser",
      "title": "Edit User",
      "iconClass": "mdi mdi-border-color",
      "action": "gridHoverOnEditClick"
    }];
    controller.setProperties({
      title: AdminLabel.USERPROFILETITLE,
      exportAudit: AdminLabel.EXPORTAUDIT,
      exportToExcel: AdminLabel.EXPORTTOEXCEL,
      exportAuditUrl: namespace + AdminLabel.EXPORTAUDITURL,
      exportToExcelUrl: namespace + AdminLabel.EXPORTTOEXCELURL,
      addUser: AdminLabel.ADDUSER,
      gridServiceParams: {
        screenName: this.screenName
      },
      gridItemId: 'UserAdmin_Users_Detail_Grid',
      rowActionItems: rowActionItems,
      isActive: true
    });
  },

  refreshGrid(refresh) {
    this.controller.set('refreshGrid', refresh);
  },

  refreshDOMElement(attr) {
    this.controller.set(attr, false);
    Ember.run.next(() => {
      this.controller.set(attr, true);
    })
  },

  setPopupConfig() {
    this.controller.setProperties({
      adminPopupConfig: {
        title: 'Add User',
        showFooter: true,
        okBtnText: 'Save',
        onOk: this.sendOnOkClick,
        onCancel: this.hideAdminDialog,
        callbackContext: this,
        tabsArrayConfig: AdminLabel.POPUPTABS,
        disableOkBtn: true,
      },
      addRolePopup: true,
      roleModel: this.createUserRole,
    });

  },

  hideAdminDialog(arg) {
    this.controller.setProperties({
      addRolePopup: false,
      isActive: true
    });
    Ember.$('.modal-backdrop.in').css({
      display: 'none'
    });
    delete this.createUserRole;
  },

  sendOnOkClick(arg) {

    let selectedOptionsCount = this.createUserRole.get('countryCodes') ? this.createUserRole.get('countryCodes').length : 0;
    if (this.validateArray.indexOf("isAssgnCountries") !== -1 && selectedOptionsCount === 0) {
      this.controller.set('errorMsg', 'please select Country');
      return;
    }

    this.createUserRole.save().then((response) => {
      this.hideAdminDialog();
      this.controller.set('successMsg', 'PSID Added succesfully');
    }).catch((e) => {
      console.log(e)
    });
  }

});
