import Ember from 'ember';
import AuthenticatedRoute from 'supdash-ui-core/routes/authenticated-route';
import RouteProgressIndicator from 'supdash-ui-core/mixins/route-progress-indicator';
import ModulePrefixProvider from '../mixins/module-prefix-provider';

export default AuthenticatedRoute.extend(RouteProgressIndicator, ModulePrefixProvider, {
  hideSecondaryNav: true,
  showModuleTitle: false,
  session: Ember.inject.service(),
  userProfileService: Ember.inject.service(),
  userAssignedRoles: Ember.computed.alias('userProfileService.userProfile.roleHead'),

  beforeModel() {
    let transitionRoute;
    this.attachBeforeUnloadEvent();

    if (this.get('userAssignedRoles') === 'ADMIN') {
      transitionRoute = 'admin';
    } else {
      transitionRoute = 'home.exception';
    }

    this.transitionTo(this.get('modulePrefix') + transitionRoute);
  },

  /**
   * Purpose: This hook has been used to render the secodary navigation menu items for the home.
   */
  renderTemplate() {
    this.render('sup-top-bar-secondary', {
      outlet: 'top-bar-secondary',
      into: 'application'
    });
  },

  attachBeforeUnloadEvent() {
    console.log('index js setupController called');

    if (Ember.getOwner(this).lookup('adapter:application').invalidateSessionOnClose) {
      window.onbeforeunload = this.clearSessionOnClose.bind(this);
    }
  },

  clearSessionOnClose() {
    sessionStorage.clear();
    localStorage.clear();
    this.get('session').invalidate();
    Ember.getOwner(this).lookup('authenticator:coreRequestAuthenticator').invalidate();
  }
});
