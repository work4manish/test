import Ember from 'ember';
import MapActionMixin from '../mixins/map-action-mixin';

export default Ember.Component.extend(MapActionMixin, {
  store: Ember.inject.service(),
  showModalTabs:true,
  actions: {

    onTabChange(tab) {
      this.selectedTab = tab;
      this.sendAction(this.action, tab);
    }
  },

  init() {
    this._super();
    this.mapAction('action');
    this.set('selected',this.get('tabsArrayConfig.selected'));
    this.selectedTab = this.get('tabsArrayConfig').selected;
  }

});
