import Ember from 'ember';

export default Ember.Component.extend({
  okBtnText: 'GOT IT',
  hideCancelBtn: true,
  showFooter: true,
  isDetailMode: true,
  gridServiceParams: null,
  refreshPopupGrid: false,
  parentRowId: null,

  refreshPopupGridObserver: Ember.observer('refreshPopupGrid', function() {
    console.log('refreshPopupGrid');
  }),

  init() {
    this._super();

    if (this.gridServiceParams) {
      let gridId = this.gridServiceParams.gridId;
      let detailStr = '_Detail';

      if (gridId && gridId.indexOf(detailStr) !== (gridId.length - detailStr.length)) {
        this.gridServiceParams.gridId = '';
        this.gridServiceParams.gridId = gridId + '_Detail';
      }

      if (this.parentRowId) {
        this.gridServiceParams.attributeId = this.parentRowId;
      }

      this.gridServiceParams.configRequired = true;
    }
  }
});
