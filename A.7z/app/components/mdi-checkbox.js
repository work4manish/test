//import Ember from 'ember';
import MdChecksCheck from 'ember-cli-materialize/components/md-checks-check';

export default MdChecksCheck.extend({
  optionLabelPath: 'title',
  optionValuePath: 'id'
});
