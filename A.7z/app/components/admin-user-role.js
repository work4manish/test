import Ember from 'ember';
import convertToJSON from '../mixins/convert-to-json';
import MapActionMixin from '../mixins/map-action-mixin';


export default Ember.Component.extend(convertToJSON, MapActionMixin, {
  store: Ember.inject.service(),
  coreDataService: Ember.inject.service(),
  ColumnCount:12,

  actions: {

    onRoleSelection(role) {
      this.userRoleId = role
      //Ember.run.next(() => {
        this.fetchRoleInfo(role);
      //});

    },

    bfsHierarchySelectLevel2(val){
      if(this.get('bfsHierarchyLevel3')){
        this.get('coreDataService').queryRecord('base', {
            screenName: 'adminUserProfileHierarchy',
            level : 3,
            roleId:this.userRoleId,
            prevLevelCode:val.id
          }).then((users) => {
            let bfsHierarchyLevel = users.get('info').bfsHierarchyLevel3;
            this.setProperties({
             // bfsHierarchyLevel3: bfsHierarchyLevel
            });
          }).catch((reason) => {
            console.log(reason);
          });
        }

    },

     bfsHierarchySelectLevel3(val){
       if(this.get('bfsHierarchyLevel4')){
        this.get('coreDataService').queryRecord('base', {
          screenName: 'adminUserProfileHierarchy',
          level : 4,
          roleId:this.userRoleId,
          prevLevelCode:val.id
        }).then((users) => {
          let bfsHierarchyLevel = users.get('info').bfsHierarchyLevel4;
          this.setProperties({
           // bfsHierarchyLevel4: bfsHierarchyLevel
          });
        }).catch((reason) => {
          console.log(reason);
        });
      }
    },

    bfsHierarchySelectLevel4(val){
       if(this.get('bfsHierarchyLevel6')){
        this.get('coreDataService').queryRecord('base', {
          screenName: 'adminUserProfileHierarchy',
          level : 6,
          roleId:this.userRoleId,
          prevLevelCode:val.id
        }).then((users) => {
          let bfsHierarchyLevel = users.get('info').bfsHierarchyLevel6;
          this.setProperties({
            //bfsHierarchyLevel6: bfsHierarchyLevel
          });
        }).catch((reason) => {
          console.log(reason);
        });
      }
    }

  },

// errorMsg: Ember.addObserver('errorMsg',()=>{
//   this.set('errorMsg');
// }),

  init() {
    this._super(...arguments);
    this.mapAction('action');
    this.fetchRoles();
  },

  fetchRoles() {
    this.get('coreDataService').query('adminAvailableRole').then((roles) => {
      let rolesArray = this.convertToJSON(roles);
      this.setProperties({
        contents: rolesArray
      });
    });
  },

  fetchRoleInfo(role) {
    this.get('coreDataService').findRecord('roleInfo', role).then((roleInfo) => {
      this.restAllRoleInfoFlag(false);
      Ember.run.next(()=>{
        this.setRoleInfo(roleInfo);
      });
    });
  },

  restAllRoleInfoFlag(flag) {
    this.setProperties({
      assignByBFS: flag,
      assignByCountry: flag,
      assignByPSID: flag,
      bfsHierarchyLevel2:flag,
      bfsHierarchyLevel3:flag,
      bfsHierarchyLevel4:flag,
      bfsHierarchyLevel6:flag
    });
  },

  setRoleInfo(roleInfo) {
    let roleConfig = roleInfo.get('roleConfiguration') ? roleInfo.get('roleConfiguration').toJSON() : {};
    let bizHierarchyCount=0;
    let validateArray = [];

    this.setModelUserRole(roleConfig);


    for(let roleAttr in roleConfig){
      this.sendAction(this.action,true);
      if(roleAttr.indexOf('isBizHierarchyLevel')!==-1 && roleConfig[roleAttr]){
        bizHierarchyCount++;
        validateArray.push(roleAttr);
        this.set('assignByBFS',true);
        this.setAssignByBFSElement(roleAttr,roleConfig,roleInfo);
      }else if(roleAttr.indexOf('isAssgnCountries')!==-1 && roleConfig[roleAttr]){
          validateArray.push(roleAttr);
       this.setAssignByCountry(roleInfo.get('availableCountries'));
      }
    }

    this.sendAction(this.action,validateArray);
    if(bizHierarchyCount>1){
      this.set('columnCount',6);
    }else{
      this.set('columnCount',12);
    }
  },

  setAssignByBFSElement(roleAttr,roleConfig,roleInfo){
    let roleSuffix = roleAttr.slice(-1);
    let contentArrayKey = 'bfsHierarchyLevel'+roleSuffix;

    let multiSelectKey = 'multiBizHierarchyLevel'+roleSuffix;
    let multiSelect = roleConfig[multiSelectKey];
    let hasMayKey = 'hasManyBizHierarchyLevel'+roleSuffix;

    let labelKey = 'labelBizHierarchyLevel'+roleSuffix;
    let labelValue = 'Business Function (Level '+roleSuffix+')';

    let infoMsgKey = 'infoMsgBizHierarchyLevel'+roleSuffix;
    let infoMsgKeyText = multiSelect?'Multiple selections are allowed':'';

    let cssClassKey = 'multiSelectCssClassLevel'+roleSuffix;
    let cssClass = multiSelect?'multi-select-2':'single-select-2';

    this.set(contentArrayKey, roleInfo.get(contentArrayKey));
    this.set(multiSelectKey,multiSelect);
    this.set(hasMayKey,multiSelect);
    this.set(labelKey,labelValue);
    this.set(labelKey,labelValue);
    this.set(infoMsgKey,infoMsgKeyText);
    this.set(cssClassKey,cssClass);
  },

  setAssignByCountry(country) {
    this.setProperties({
      assignByCountry:country
    });
  },

  setAssignByPSID(PSID) {
  },

  setModelUserRole(roleConfig){
    this.get('roleModel').setProperties({
      userRoleId:roleConfig.roleId,
      userRoleName:roleConfig.roleName,
      userRoleType:roleConfig.roleType
    })

  }

});
