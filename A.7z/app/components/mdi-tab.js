import mdTab from 'ember-cli-materialize/components/md-tab';

export default mdTab.extend({
  onTabChange: 'onTabChange',
  actions: {
    onTabChange(selectedValue) {
      this.sendAction('onTabChange', selectedValue);
    }
  },

  init() {
    this._super();
  }
});
