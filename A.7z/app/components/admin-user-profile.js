import Ember from 'ember';


export default Ember.Component.extend({
  store: Ember.inject.service(),
  errors: 'Auto-populated based on PSID',

  actions: {

    onPsidSelect(user) {
      this.fetchUserInfo(user.userPsId);
    },

    removeUserInfo() {
      this.set('userInfo', []);
    }
  },

  fetchUserInfo(psid) {
    this.get('store').findRecord('admin-user-info', psid).then((userInfo) => {

    this.get('roleModel').set('userPsId',psid);//seting userPSID in created model.

      Ember.$('.profile-wrapper label').addClass('active');
      this.setProperties({
        userInfo: userInfo
      });
    });
  }
});
