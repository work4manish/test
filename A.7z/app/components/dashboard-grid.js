import Ember from 'ember';
import AppConst from '../utils/app-const';

export default Ember.Component.extend({
  coreDataService: Ember.inject.service(),
  serviceParams: null,
  modelName: 'base',
  refreshGrid: false,
  durationFilters: null,

  serviceParamsObserver: Ember.observer('serviceParams', 'serviceParams.durationFilter', function() {

    if (!this.serviceParamsObserverInProgress && this.dashboardGrid) {
      this.serviceParamsObserverInProgress = true;
      this.updateServiceParams();
      this.set('dashboardGrid.refreshGrid', true);

      Ember.run.next(() => {
        this.set('dashboardGrid.refreshGrid', false);
        this.serviceParamsObserverInProgress = false;
      });
    }
  }),

  actions: {
    onTabChange(/*selected*/) {
      this.updateServiceParams();
    },

    showDetails(selectedItem) {
      this.openDetailGridDialog(selectedItem);
    }
  },

  init() {
    this._super();

    this.fetchData().then((response) => {
      let info = response.get('info');
      this.durationFilters = Ember.A(info.durationFilter);
      let gridConfig = info.gridItem.gridConfig;
      gridConfig.modelName = this.modelName;
      gridConfig.gridItemRoot = 'info';
      gridConfig.noResetRefreshRequired = true;

      var detailGridServiceParams = this.prepareDetailGridServiceParams();

      if (!this.isDestroyed) {
        this.setProperties({
          'dashboardGrid': {
            gridTitle: info.gridTitle,
            filterItems: this.durationFilters,
            selectedFilter: this.getSelectedDuration(),
            gridConfig: info.gridItem.gridConfig,
            gridData: info.gridItem.gridData,
            gridServiceParams: this.getServiceParams(),
            detailGridServiceParams: detailGridServiceParams,
            refreshGrid: this.refreshGrid
          },
          detailDialogConfig: {
            onOk: this.closeDetailGridDialog,
            callbackContext: this
          }
        });

        this.set('loaded', true);
      }
    });
  },

  fetchData() {
    return this.get('coreDataService').queryRecord(this.modelName, this.getServiceParams());
  },

  getServiceParams() {
    let serviceParams = this.serviceParams || {};

    if (!this.isDestroyed) {
      if (!this.serviceParams) {
        this.set('serviceParams', serviceParams);
      }

      this.set('serviceParams.gridId', this.getGridId());

      if (this.durationFilters) {
        this.set('serviceParams.durationFilter', this.getSelectedDuration());
      } else {
        this.set('serviceParams.durationFilter', '');
      }

      this.set('serviceParams.screenName', 'generalDashboard');
    }

    return serviceParams;
  },

  prepareDetailGridServiceParams() {
    let detailGridServiceParams = Ember.copy(this.getServiceParams(), true);
    detailGridServiceParams.screenName = 'generalDashboardDetailGrid';

    return detailGridServiceParams;
  },

  getGridId(isDetailGrid) {
    var roleName = this.serviceParams.roleName;
    var gridId = this.serviceParams.dashboardId + '_' + (roleName === AppConst.LINE_MANAGER ? 'Linamanager' : 'RoleBased') + '_Grid';

    if (isDetailGrid) {
      gridId += '_Detail';
    }

    return gridId;
  },

  getSelectedDuration() {
    let selectedFilter = this.durationFilters.findBy('selected', true);

    if (selectedFilter) {
      return selectedFilter.id;
    }
  },

  updateServiceParams() {
    let serviceParams = this.getServiceParams();

    this.set('dashboardGrid.gridServiceParams', serviceParams);
    this.set('dashboardGrid.detailGridServiceParams', this.prepareDetailGridServiceParams());
  },


  openDetailGridDialog(selectedItem) {
    this.set('dashboardGrid.selectedRowId', selectedItem.attributeId);
    this.set('showDetailGridDialog', true);
  },

  closeDetailGridDialog() {
    this.set('showDetailGridDialog', false);
  },
});
