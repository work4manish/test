import Ember from 'ember';
import ComponentReferenceExport from '../mixins/component-reference-export';
import MapActionMixin from '../mixins/map-action-mixin';


export default Ember.Component.extend(ComponentReferenceExport,MapActionMixin, {
  classNames: ['mdi-select2-div'],
  placeHolder: '',
  multiple: false,
  allowClear: false,
  searchEnabled: true,
  optionIdPath: 'id',
  optionLabelPath: 'text',
  optionLabelSelectedPath: null,
  optionValuePath: null,
  optionHeadlinePath: 'text',
  optionDescriptionPath: 'description',
  placeholder: null,
  value: '',
  typeaheadErrorText: "Loading failed...",
  typeaheadNoMatchesText: "No items found for '%@'",
  typeaheadSearchingText: "Searching items",
  queryAction: null,
  formatResult: null,
  formatSelection: null,
  minimumInputLength: 0,
  hightlightClass: "highlight",
  selectedValues: [],
  customAction: null,
  debounceTime: 500,

  /* Info message to display **/
  infoMessage: null,

  focus() {
    try {
      var select2Instance = this.getSelectInstance();
      select2Instance.focus();
    } catch (e) {}
  },

  focusIn(){
    this.$().addClass("is-active is-completed");
  },
  click(){
    this.$().addClass("is-active is-completed");
  },
  focusOut(){
    if (this.$('input').eq(1).val() === '') {
      this.$().removeClass('is-completed');
    }
    this.$().removeClass("is-active");
  },
  setCompleted: Ember.on('didUpdate', function () {
    if (this.get('value')) {
      $(this.get('element')).addClass("is-completed");
    }
  }),


  /*
   * Hack to fix initial data binding issue, when using ember select with server side filering
   */
  init() {

    if (!this.get('optionHeadlinePath')) {
      this.set('optionHeadlinePath', this.get('optionLabelPath') || this.get('optionIdPath'));
    }

    if (this.get('config.allowClear') === false) {
      this.allowClear = false;
    }

    this.mapAction('customAction');
    return this._super();
  },


  /**
   * didInsertElement.
   * @override
   */
  didInsertElement() {
    var select2Overrides = this.container.lookup('Select2Overrides:main'),
      select2Instance = this.getSelectInstance();
    //Do also custom overidding only, when select2 succesfully created. To avoid infinite looping
    if (select2Instance != null) {
      if (this.formatResult) {
        this.setCustomResultFormatter();
      }
      if (this.formatSelection) {
        this.setCustomSelectionFormatter();
      }
      if (this.onSelection) {
        this.setCustomSelectHandler();
      }
      if (this.get('valueTemp')) {
        this.set('value', this.valueTemp);
        select2Instance.data(this.value);
      }
      if (this.multiple === true && this.hasMany === true) {
        this.addObserver('selectedValues', this.selectedValuesObserver);
        //this.addObserver('value', this.valuesObserver);
        //this.selectedValuesObserver();
      }else{
        this.addObserver('value', this.valuesObserver);
      }
      if (this.get('multiple') === true) {
        if (select2Instance.container !== null) {
          //select2Instance.container.off('click').on('click', ".select2-choices", select2Overrides.select2ContainerClick.bind(this.getSelectInstance()));
          //this.getSelectInstance().container.resize(select2Overrides.select2Resize.bind(this.getSelectInstance()));
          //this.$(window).resize(select2Overrides.select2Resize.bind(this.getSelectInstance()));
        }
      }
      this.registerOnClearHandler();
    }
    return this._super();
  },
  willDestroyElement() {
    if (this.get('multiple') === true) {
      this.$(window).off('resize');
    }
    if (this.multiple === true && this.hasMany === true) {
      this.removeObserver('selectedValues', this.selectedValuesObserver);
    }else{
      this.removeObserver('value', this.valuesObserver);
    }
  },
  _handleQueryAction: function() {
    var query = this.get('_query'),
      deferred = this.get('_deferred');
    this.send('queryAction', query, deferred);
  },
  actions: {
    /*
    This is proxy method for queryAction, which will be called prior to queryAction
    It debounces and calls queryAction subsequently. To avoid multiple calls to queryAction
    */
    _proxyQueryAction(query, deferred) {
      this.set('_query', query);
      this.set('_deferred', deferred);
      /**
      Debouncing, to delay sending queryAction to avoid multiple service call, as user types in search
      **/
      Ember.run.debounce(this, this._handleQueryAction, this.debounceTime);
    },
    queryAction(query, deferred) {
      this.sendAction('queryAction', query, deferred);
    }
  },
  /*
   * Enable selectbox only when readonly and disabled is not true
   */
  enabled: Ember.computed("disabled", "readonly", {
    get() {
      var readonly = this.get('readonly'),
        disabled = this.get('disabled');
      if (readonly === true || readonly === 'true') {
        return false;
      }
      return !(disabled === true || disabled === 'true');
    }
  }),

  query: Ember.computed("queryAction", {
    get() {
      if (Ember.isEmpty(this.get('queryAction'))) {
        return null;
      } else {
        return '_proxyQueryAction';
      }
    }
  }),

  onSelection(model) {
    try {
      var customAction = this.get('customAction'),
        oldValue, newValue;
      if (customAction) {
        if (model != null) {
          oldValue = this.get('value');
          newValue = model instanceof Ember.Object ? model.get(this.get('optionIdPath')) : model[(this.get('optionIdPath'))];
          if (oldValue === newValue && Ember.isEmpty(newValue) === false) {
            return;
          }
        }
        this.sendAction(this.customAction, model);
      }
    } catch (e) {
      Ember.Logger.debug(e);
    }
  },
  /*
   * This method traves through the fomatted result , and
   * finds the search text and highlights it
   */
  hightlightHTML(node, pat) {
    var skip = 0,
      pos, spannode, middlebit, middleclone, i;
    if (node.nodeType === 3) {
      pos = node.data.toUpperCase().indexOf(pat);
      if (pos >= 0) {
        spannode = document.createElement('span');
        spannode.className = this.hightlightClass;
        middlebit = node.splitText(pos);
        middlebit.splitText(pat.length);
        middleclone = middlebit.cloneNode(true);
        spannode.appendChild(middleclone);
        middlebit.parentNode.replaceChild(spannode, middlebit);
        skip = 1;
      }
    } else if (node.nodeType === 1 && node.childNodes) {
      for (i = 0; i < node.childNodes.length; ++i) {
        i += this.hightlightHTML(node.childNodes[i], pat);
      }
    }
    return skip;
  },
  /*
   * When custom format is provided for result
   * select2 options is retrived and formatResult method
   * is replaced with the provided method
   */
  setCustomResultFormatter() {
    this.getSelectInstance().opts.formatResult = function(data, container, query) {
      var formattedResult = this.formatResult(data),
        dom;
      if (typeof formattedResult === "string") {
        dom = document.createElement('div');
        dom.innerHTML = formattedResult;
      } else {
        dom = formattedResult;
      }
      if (query && query.term) {
        this.hightlightHTML(dom, query.term.toUpperCase());
      }
      return dom;
    }.bind(this);
  },
  /*
   * When custom format is provided for selection
   * select2 options is retrived and formatSelection method
   * is replaced with the provided method
   */
  setCustomSelectionFormatter() {
    this.getSelectInstance().opts.formatSelection = function(data) {
      if (data !== null && data !== undefined) {
        return this.formatSelection(data);
      }
    }.bind(this);
  },
  /*
   * When custom select handler is passed, When any selection is selected,
   * Custom select handler called
   */
  setCustomSelectHandler() {
    var select2 = this.getSelectInstance(),
      self = this;
    select2.onSelect = (function(onSelect) {

      return function(data, event) {
        self.onSelection.apply(self, arguments);
        return onSelect.apply(this, arguments);
      };
    })(select2.onSelect);
  },
  /*
   * Method to retrive actual jquery select2 instance
   */
  getSelectInstance() {
    if (this.select2Instance === undefined) {
      this.select2Instance = this.$().find('input.form-control').data('select2');
    }
    return this.select2Instance;
  },
  registerOnClearHandler() {
    this.$().find('input.form-control').on('select2-removed', function() {
      if(this.customAction && typeof(this.customAction)==='string'){
        this.sendAction(this.customAction, undefined);
      }
    }.bind(this));
  },
  /* When in multiple mode true, and hasMany as true
  The observer observes for selected values,
  and according add selected values to ember model object properly */
  selectedValuesObserver() {
    var model = this.get('modelValue'),
      modelKey = this.get('modelValueKey'),
      selectedValues = this.get('selectedValues');
    if ( !Ember.isEmpty(model)) {
      model.set(modelKey,[]);
      if (selectedValues && selectedValues.length) {
        var selectedValuesId=[];
        for(let i=0;i<selectedValues.length;i++){
          selectedValuesId.push(selectedValues[i].id);
        }
        model.set(modelKey,selectedValuesId);
      }
    }
  },
  /* When in multiple mode true, and hasMany as true
  The observer observes for value change,
  and according modify selected values */
  valuesObserver(value) {
    var model = this.get('modelValue'),
      modelKey = this.get('modelValueKey'),
      selectedValue = this.get('value');
    if ( !Ember.isEmpty(model)) {
      model.set(modelKey,[]);
      if (selectedValue && selectedValue.id) {
        model.set(modelKey,[selectedValue.id]);
      }
    }
  }
});
