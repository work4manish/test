import Ember from 'ember';
import CoreApplicationAdapter from 'supdash-ui-core/adapters/application';

/**
 * Purpose: This is parent class of all adapters which extends core: application adapter and is used
 * calling web services if request is made via store.
 */
export default CoreApplicationAdapter.extend({
  namespace: 'cxf/sd',
  //host: 'http://10.65.117.173:8181',
  invalidateSessionOnClose: true,
  userProfileService: Ember.inject.service(),

  pathForType(a_type) {
    return a_type;
  },

  ajax(url, type, options) {
    let params = options.data;

    if (params.sendLoggedInUserId) {
      params.loggedInUserId = this.getLoggedInUserId();
    }
    if(type!=='POST'){
      for (let paramKey in params) {
        if (params.hasOwnProperty(paramKey)) {
          params[paramKey.toLowerCase()] = params[paramKey];

          if (paramKey.toLowerCase() !== paramKey) {
            delete params[paramKey];
          }
        }
      }
    }
    delete params.screenname;
    delete params.sendUserId;
    //delete params.roleName;
    return this._super(url, type, options);
  },

  getLoggedInUserId() {
    let userProfile = this.get('userProfileService').getUserProfile();

    if (userProfile) {
      return userProfile.psId;
    }
  }
});
