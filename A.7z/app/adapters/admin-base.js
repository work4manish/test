import ApplicationAdapter from './application';

export default ApplicationAdapter.extend({
  init() {
    this._super();

    this.namespace = this.namespace + '/useradmin';
  }
});
