import ApplicationAdapter from './application';

export default ApplicationAdapter.extend({
  buildURL: function(modelName, id, snapshot, requestType, query) {
    let chartId = '';

    if (query.hasOwnProperty('chartId')) {
      chartId = query.chartId;
    }

    let viewType = chartId.split('_')[0];
    viewType = viewType.replace(/([~!@#$%^&*()_+=`{}\[\]\|\\:;'<>,.\/? ])+/g, '').toLowerCase();

    let contextPath = viewType + '/chartview';

    return this._buildURL(contextPath);
  }
});
