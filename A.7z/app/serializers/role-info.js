import Ember from 'ember';
import DS from 'ember-data';

export default DS.RESTSerializer.extend(DS.EmbeddedRecordsMixin, {
  primaryKey:'roleConfiguration',

  attrs: {
    bfsHierarchyLevel4: {
      embedded: 'always'
    },
    bfsHierarchyLevel3: {
      embedded: 'always'
    },
    bfsHierarchyLevel2: {
      embedded: 'always'
    },
    roleConfiguration: {
      embedded: 'always'
    },
    availableCountries: {
      embedded: 'always'
    },
    bfsHierarchyLevel6: {
      embedded: 'always'
    }
  },
});
