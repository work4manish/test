import Ember from 'ember';
import DS from 'ember-data';

export default DS.RESTSerializer.extend(DS.EmbeddedRecordsMixin, {
  primaryKey:'userPsId',

  normalizeResponse(store, primaryModelClass, payload, id, requestType) {

    payload.adminUserInfo = payload.userInfo[0];

    payload.adminUserInfo.isUserActive = (!Ember.isEmpty(payload.adminUserInfo.isUserActive) && payload.adminUserInfo.isUserActive.toUpperCase()==='Y')?'Active' : 'Inactive';

    delete payload.userInfo;

    return this._super(store, primaryModelClass, payload, id, requestType);
  }
});



