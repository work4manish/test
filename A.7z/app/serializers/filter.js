import DS from 'ember-data';

export default DS.RESTSerializer.extend(DS.EmbeddedRecordsMixin, {
  attrs: {
    durationFilter: {
      embedded: 'always'
    },
    regularFilter: {
      embedded: 'always'
    },
    otherAttributeFilter: {
      embedded: 'always'
    },
    additionalFilter: {
      embedded: 'always'
    },
  }
});
