export default {
  LINE_MANAGER: 'Line Manager'
};
