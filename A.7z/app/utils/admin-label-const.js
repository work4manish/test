export default {
  dashboardAppTitle: 'SDB',
  baseAppTitle: 'Admin',
  HEADERTITLE: 'Entitlements',
  USERPROFILETITLE: 'User Profiles',
  EXPORTAUDIT: 'EXPORT AUDIT TRAIL',
  EXPORTTOEXCEL: 'EXPORT TO EXCEL',
  EXPORTAUDITURL: '/useradmin/audittrail',
  EXPORTTOEXCELURL: '/useradmin/userprofilereport',
  ADDUSER: 'ADD A USER',
  POPUPTABS: {
    tabArray: [{
      "id": "profile",
      "title": "Profile"
    }, {
      "id": "userRole",
      "title": "User Role"
    }],
    selected: 'profile'
  },
};
