import Ember from 'ember';

export default {
  resetAllExcept(currentItem, items, attributeToReset, resetValue, keyAttribute) {
    if (!keyAttribute) {
      keyAttribute = 'id';
    }

    for (let i = 0, len = items.length; i < len; i++) {
      let item = items[i];

      if (!currentItem || String(item[keyAttribute]) !== String(currentItem[keyAttribute])) {
        Ember.set(item, attributeToReset, resetValue);
      }
    }
  },

  resetAll(items, attributeToReset, resetValue, keyAttribute) {
    this.resetAllExcept(null, items, attributeToReset, resetValue, keyAttribute);
  },

  updateAttributeWhere(attribName, attribValue, updateAttribName, updateAttribValue, items) {
    for (let i = 0, len = items.length; i < len; i++) {
      let item = items[i];

      if (String(item[attribName]) === String(attribValue)) {
        Ember.set(item, updateAttribName, updateAttribValue);
      }
    }
  }
};
