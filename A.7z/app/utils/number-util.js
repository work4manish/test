var NumberUtil = {
  isNumber(input) {
    let output = accounting.parse(input);

    if (String(input) === String(output)) {
      return true;
    }

    return false;
  }
};

export default NumberUtil;
