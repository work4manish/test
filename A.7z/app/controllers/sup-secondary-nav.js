import Ember from 'ember';
import ObjectUtil from '../utils/object-util';

export default Ember.Controller.extend({
  coreDataService: Ember.inject.service(),

  actions: {
    onMenuItemClick(menuItem) {
      ObjectUtil.resetAllExcept(menuItem, this.menuItems, 'active', false);
      Ember.set(menuItem, 'active', true);

      if (this.previousMenuItemId !== menuItem.id) {
        this.send('onMenuItemClicked', menuItem);
      }

      this.previousMenuItemId = menuItem.id;
    }
  },

  init() {
    this._super();
    this.get('coreDataService').queryRecord('base', {
      screenName: 'secondaryMenu',
      category: 'General'
    }).then((menu) => {
      let menuItems = menu.get('info').menuItems;

      this.set('menuItems', menuItems);
      this.set('loaded', true);
    });
  },

  deselectAll() {
    ObjectUtil.resetAll(this.menuItems, 'active', false);
    this.previousMenuItemId = null;
  }
});
