import Ember from 'ember';
import convertToJSON from '../mixins/convert-to-json';
import AppConst from '../utils/app-const';

export default Ember.Controller.extend(convertToJSON, {
  coreDataService: Ember.inject.service(),
  routing: Ember.inject.service('-routing'),
  userCurrentRoleService: Ember.inject.service(),
  userAssignedRoles: Ember.computed.alias('userCurrentRoleService.userAssignedRoles'),
  isAllSwitcheShow: true,

  routesMap: {
    generalMIS: 'home.general',
    exceptionMIS: 'home.exception'
  },

  actions: {

    changeView(selectedView) {
      this.setSelectedContext(selectedView);
    },

    changeDashboardType(selectedDashboardType) {
      this.get('routing').transitionTo(this.routesMap[selectedDashboardType]);
    },

    toggleAll(state) {
      this.allSelected = state.checked;
      Ember.run.later(() => {
        this.send('selectAllDirectsReport', state.checked);
      }, 300);
    },

    onRoleChange(role) {
      let roleSerice = this.get('userCurrentRoleService');
      roleSerice.setCurrentRole(role);
      this.setRoleConfig();

      let roleObject = roleSerice.getCurrentRole();
      this.send('onRoleChanged', roleObject.roleId, roleObject.roleName);
    },

    changedOtherAttributeTab(selectedAttrTab) {
      this.send('changedOtherAttribute', selectedAttrTab);
    },

    showRoleInfoPopup() {
      let currentRole = this.get('userCurrentRoleService').getCurrentRole();

      this.get('coreDataService').queryRecord('base', {
        screenName: 'roleInfoPopup',
        roleId: currentRole.roleId
      }).then((menu) => {
        let roleInfoDetail = menu.get('info').roleInfoDetail;

        this.setProperties({
          displayRoleInfoPopup: true,
          roleInfoDetail: roleInfoDetail,
          roleInfoPopupConfig: {
            title: currentRole.roleName + ' Details',
            okBtnText: 'GOT IT',
            onOk: this.closeRoleInfoPopup,
            callbackContext: this
          }
        });
      });
    }
  },

  getAppliedFilters() {
    let role = this.get('userCurrentRoleService').getCurrentRole();
    let roleId = role.roleId;
    let roleName = role.roleName;
    let includeIndirectReport = this.allSelected;

    if (roleName === AppConst.LINE_MANAGER) {
      if (includeIndirectReport === undefined) {
        includeIndirectReport = true;
      }
    }

    return {
      roleId: roleId,
      roleName: roleName,
      includeIndirectReports: includeIndirectReport,
      otherAttributeFilter: this.get('otherAttributeTab')
    };
  },

  closeRoleInfoPopup() {
    this.set('displayRoleInfoPopup', false);
  },

  init() {
    this.setRoleConfig();
    let selectedRole = this.get('userCurrentRoleService').getCurrentRole();
    let topBarSecondary = this.topBarSecondaryJSON();
    this.contextItems = topBarSecondary.contextItems;

    this.setProperties({
      contents: this.get('userAssignedRoles'),
      selectedRole: selectedRole.roleId,
      topBarSecondary: topBarSecondary,
      selectedContext: topBarSecondary.selectedContext,
      selectedContextIcon: topBarSecondary.selectedContextIcon,
      dashboardTypes: topBarSecondary.dashboardTypes,
      selectedDashboardType: topBarSecondary.selectedDashboardType
    });
  },

  updateTopBarSecondary(dataObject, includeIndirectReport) {
    if (includeIndirectReport === undefined) {
      includeIndirectReport = this.allSelected;
    }

    this.updateLastRefreshDate(dataObject);
    this.updateOtherAttributes(dataObject, includeIndirectReport);
  },

  updateLastRefreshDate(dataObject) {
    this.set('lastRefreshDate', dataObject.get('title'));
  },

  updateOtherAttributes(dataObject, includeIndirectReport) {
    let hideOtherAttributeTabs = false;
    let otherAttributeFilter = dataObject.get('otherAttributeFilter');
    if (!Ember.isEmpty(otherAttributeFilter)) {
      let filterItems = this.convertToJSON(otherAttributeFilter);
      let selectedObject = filterItems.filterBy('selected', true)[0];
      if (!Ember.isEmpty(filterItems) && filterItems.length > 0) {
        this.setProperties({
          otherAttributeTabs: filterItems,
          otherAttributeTab: selectedObject.id,
        });
      }
    } else {
      hideOtherAttributeTabs = true;
    }

    this.toggleSecondaryTopBarTabs('detail', hideOtherAttributeTabs, includeIndirectReport,
                        dataObject.dashboardTabsVisible, dataObject.hideToggleAllOnDetail);
  },

  toggleSecondaryTopBarTabs(dashboard, hideOtherAttributeTabs, includeIndirectReport,
    dashboardTabsVisible, hideToggleAllOnDetail) {

    let showDashboardTabs = dashboardTabsVisible ? dashboardTabsVisible
                                          : ((dashboard === 'index') ? true : false);
    let showToggleOnDetail = hideToggleAllOnDetail !== undefined ? (!hideToggleAllOnDetail) : hideOtherAttributeTabs;

    this.setProperties({
      dashboardViewTabs: false,
      detailViewTabs: false
    });

    Ember.run.next(() => {
      this.setProperties({
        includeIndirectReport: includeIndirectReport,
        isAllSwitcheShowOnDetail: showToggleOnDetail,
        lastRefreshDateFlag: !showDashboardTabs,
        dashboardViewTabs: showDashboardTabs,
        detailViewTabs: hideOtherAttributeTabs ? showDashboardTabs : !showDashboardTabs
      });
    });
  },

  getDasboardTabs(topBarSecondary) {
    let dashboardTypes = topBarSecondary.dashboardTypes;
    let dashboardTabs = [];

    for (let i = 0, len = dashboardTypes.length; i < len; i++) {
      let dashboardType = dashboardTypes[i];

      dashboardTabs[i] = dashboardType;
      dashboardTabs[i]['id'] = dashboardType.id;
    }

    return dashboardTabs;
  },

  setSelectedContext(selectedView) {
    let contextItems = this.contextItems;

    for (let i = 0, len = contextItems.length; i < len; i++) {
      let contextItem = contextItems[i];

      if (contextItem.id === selectedView) {
        this.set('selectedContext', contextItem.text);
        this.set('selectedContextIcon', contextItem.iconClass);

        return;
      }
    }
  },

  setRoleConfig() {
    let selectedRole = this.get('userCurrentRoleService').getCurrentRole();
    let isLineManager = this.get('userCurrentRoleService').isLineManager();
    this.setProperties({
      roleConfig: selectedRole.roleConfig,
      isAllSwitcheShow: isLineManager
    });
  },

  topBarSecondaryJSON() {
    let topBarSecondaryObject = Ember.Object.create({
      "topBarSecondary": {
        "id": "top-bar-secondary1",

        "contextItems": [{
          "id": "sup-context-rb",
          "acronym": "RB",
          "text": "Role Based",
          "iconClass": "mdi-account-multiple"
        }, {
          "id": "sup-context-lm",
          "acronym": "LM",
          "text": "Line Manager",
          "iconClass": "mdi-account-circle",
          "isSelected": true
        }],

        "selectedContext": "Line Manager",
        "selectedContextIcon": "mdi-account-circle",

        "dashboardTypes": [{
          "id": "exceptionMIS",
          "title": "EXCEPTION MI"
        }, {
          "id": "generalMIS",
          "title": "GENERAL MI"
        }],

        "selectedDashboardType": "exceptionMIS"
      }
    });
    return topBarSecondaryObject.topBarSecondary;
  }
});
