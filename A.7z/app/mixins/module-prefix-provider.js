import Ember from 'ember';

export default Ember.Mixin.create({
  coreModuleLoader: Ember.inject.service(),
  currentModuleName: Ember.computed({
    get() {
      return this.get('coreModuleLoader').getCurrentModuleNameFromActiveTransition();
    }
  }),
  modulePrefix: Ember.computed('currentModuleName', {
    get() {
      let moduleName = this.get('currentModuleName');
      if (!Ember.isEmpty(moduleName)) {
        return moduleName + '.';
      }
      return '';
    }
  })
});
