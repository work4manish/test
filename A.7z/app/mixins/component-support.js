import Ember from 'ember';

export default Ember.Mixin.create({
  config: null,
  attributeBindings: [
    'name',
    'value',
    'readonly',
    'disabled',
    'min',
    'max',
    'size',
    'maxlength',
    'height',
    'width',
    'placeholder',
    'autofocus',
    'tabindex',
    'required',
    'error',
    'fieldLabel'
  ],
  init() {
    this._super();
    var attributeBindings = this.get('attributeBindings');
    if (attributeBindings) {
      attributeBindings.forEach(function(attr) {
        if (this.get('config.' + attr) && (this.get(attr) === undefined || this.get(attr) === null)) {
          this.set(attr, this.get('config.' + attr));
        }
      }.bind(this));
    }
  },
  setKendoOption(options, optionAttr, attr) {
    if (this.get('config.' + attr) && (this.get(attr) === undefined || this.get(attr) === null)) {
      options[optionAttr] = this.get('config.' + attr);
    } else {
      options[optionAttr] = this.get(attr);
    }
  }
});
