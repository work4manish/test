import Ember from 'ember';
import AppConst from '../utils/app-const';

export default Ember.Mixin.create({
  userCurrentRoleService: Ember.inject.service(),

  fetchOtherAttributeTabs(dashboard, roleId, filterId) {
    let selectedRole = this.get('userCurrentRoleService').getCurrentRole();
    let defaultFilterId = filterId || 5 ;
    let params = {
      roleId: selectedRole.roleId,
      filterId: defaultFilterId,
    };

    if (selectedRole.roleId !== roleId) {   //TODO:remove the passed parameter as it is not required
      console.error('please select the role on change of the role combo');
    }

    if (dashboard) {
      params.dashboard = dashboard;
    }

    return this.get('coreDataService').queryRecord('filter', params).then((response) => {
      response.set('dashboardTabsVisible', false);

      if (selectedRole.roleName === AppConst.LINE_MANAGER) {
        response.set('hideToggleAllOnDetail', false);
      } else {
        response.set('dashboardTabsVisible', false);
        response.set('hideToggleAllOnDetail', true);
      }

      return response;
    });
  }
});
