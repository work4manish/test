module.exports = function(app, options) {
  var globSync = require('glob').sync,
    mocks = globSync('./mocks/**/*.js', {
      cwd: __dirname
    }).map(require),
    proxies = globSync('./proxies/**/*.js', {
      cwd: __dirname
    }).map(require),
    morgan = require('morgan'),
    bodyParser = require('body-parser'),
    io = require('socket.io')(options.httpServer, {
      path: '/nodejs/wb-push-notification',
      transports: ['websocket', 'polling']
    });

  io.on('connection', function(socket) {
    console.log('a user connected');
  });

  function getContextPath() {
    var fs = require('fs');
    var jsonString = fs.readFileSync('./public/module.json', {
      encoding: 'utf-8'
    });
    var modules = JSON.parse(jsonString).modules;

    for (var moduleName in modules) {
      var module = modules[moduleName];

      if (module && module.active) {
        return module.contextPath;
      }
    }
  }

  function sendNextMessage() {
    setTimeout(function() {
      var currentDate = new Date(),
        futureDate = new Date();
      futureDate.setDate(currentDate.getDate() - 10);
      io.emit('pushMessage', {
        header: {
          type: 'task',
          createdDate: currentDate.getTime(),
          dueDate: futureDate.getTime()
        },
        body: {
          description: 'My Test'
        }
      });
      sendNextMessage();
    }, Math.floor(Math.random() * (6000 - 1000 + 1) + 1000));
  }

  sendNextMessage();

  app.use(morgan('dev'));
  app.use(bodyParser.json()); // to support JSON-encoded bodies
  app.use(bodyParser.urlencoded({ // to support URL-encoded bodies
    extended: true
  }));

  app.contextPath = getContextPath();

  console.log('*** contextPath in module.json file is : ' + app.contextPath + ' ***');

  app.getQueryParamValue = function(request, paramName) {
    if (!paramName) {
      console.warn('***** !!! getQueryParamValue: second parameter is missing : ' + paramName + ' !!! *****');
      return '';
    }

    return request.query[paramName.toLowerCase()];
  };
  app.getPathParamValue = function(request, paramName) {
    if (!paramName) {
      console.warn('***** !!! getQueryParamValue: second parameter is missing : ' + paramName + ' !!! *****');
      return '';
    }
    return request.params[paramName];
  };
  app.getPostParamValue = function(request, paramName) {
    if (!paramName) {
      console.warn('***** !!! getPostParamValue: second parameter is missing : ' + paramName + ' !!! *****');
      return '';
    }
    return request.body[paramName.toLowerCase()];
  };

  mocks.forEach(function(route) {
    route(app);
  });
  proxies.forEach(function(route) {
    route(app);
  });
};
