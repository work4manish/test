var requireModule = require;

module.exports = function(app) {
  var express = requireModule('express'),
    mockServerRouter = express.Router();

  mockServerRouter.get('/grid-item', function(request, response) {
    var pageJSON;
    var gridItemId = app.getQueryParamValue(request, 'gridItemId');
    var _dataURL = '../../_data/_dummyComponent/grid';

    console.log('********' + gridItemId + '********');

    pageJSON = requireModule(_dataURL + '.json');

    return response.json(pageJSON);
  });

  app.use(app.contextPath, mockServerRouter);
};
