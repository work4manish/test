var requireModule = require;
module.exports = function(app) {
	var express = requireModule('express');
	var bodyParser = requireModule('body-parser');
	var mockRouter = express.Router();
  var dataPath = '../../../_data';

	mockRouter.use(bodyParser.json());
	mockRouter.use(bodyParser.urlencoded({extended: true}));

  mockRouter.post('/login', function(request, response) {
    var userName = request.body.username;
    var password = request.body.password;
    var pageJSON;

    console.log(userName, password);

    if (userName !== '' && userName !== 'admin' && password === '1') {
      pageJSON = requireModule(dataPath + '/auth/user/login.json');
    } else if (userName !== '' && userName === 'admin' && password === '1') {
      pageJSON = requireModule(dataPath + '/auth/user/admin-login.json');
    } else {
      pageJSON = requireModule(dataPath + '/auth/user/login-failure.json');
      response.status(403);
    }

    response.send(pageJSON);
  });

  mockRouter.get('/validate', function(request, response) {
    console.log(request.body);
    var pageJSON = requireModule(dataPath + '/auth/user/login.json');

    response.send(pageJSON);
  });

  mockRouter.get('/logout', function(request, response) {
    console.log(request.body);
    var pageJSON = requireModule(dataPath + '/auth/user/invalidate.json');

    response.send(pageJSON);
  });

  mockRouter.get('/invalidate', function(request, response) {
    console.log(request.body);
    var pageJSON = requireModule(dataPath + '/auth/user/invalidate.json');

    response.send(pageJSON);
  });

	app.use(app.contextPath + '/sso', mockRouter);
};
