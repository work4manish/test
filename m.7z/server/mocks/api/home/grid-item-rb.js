var requireModule = require;
var getGeneralDashboardJSON = require('./general/general-dashboard');

module.exports = function(app) {
  var express = requireModule('express'),
    mockServerRouter = express.Router();
  var dataPath = '../../_data';

  mockServerRouter.get('/:griditem/rbgridview', function(request, response) {
    var pageJSON;
    var gridId = app.getQueryParamValue(request, 'gridId');

    console.log('***** ' + gridId);

    var dashboardCategory = app.getQueryParamValue(request, 'category');
    if (dashboardCategory === 'General') {
      return getGeneralDashboardJSON(request, response, app);
    }

    if (gridId === 'searchViewGrid')  {
      var selectedChartName = app.getQueryParamValue(request, 'selectedChart');
      if (selectedChartName === 'MISSED MARK') {
        pageJSON = requireModule(dataPath + '/search/search-item-detail-grid-missed-mark.json');
      } else {
        pageJSON = requireModule(dataPath + '/search/search-item-detail-grid.json');
      }
    } else {
      pageJSON = requireModule(dataPath + '/home/exception/detailview-grid.json');
    }

    return response.json(pageJSON);
  });

  mockServerRouter.get('/:griditem/rbgridviewdetail', function(request, response) {
    var dashboardCategory = app.getQueryParamValue(request, 'category');

    console.log('************** calling rbgridviewdetail *****************');

    if (dashboardCategory === 'General') {
      return getGeneralDashboardJSON(request, response, app);
    }

    pageJSON = requireModule(dataPath + '/home/exception/detailview-grid-popup.json');

    return response.json(pageJSON);
  });

  app.use(app.contextPath, mockServerRouter);
};
