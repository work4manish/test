var requireModule = require;
module.exports = function(app) {
  var express = requireModule('express'),
    mockServerRouter = express.Router();

  mockServerRouter.get('/getfilter', function(req, res) {
    var pageJSON;
    var filterId = String(app.getQueryParamValue(req, 'filterId'));
    var roleId = String(app.getQueryParamValue(req, 'roleId'));

    if (filterId === '1') {
      pageJSON = requireModule('../../_data/home/exception/filter-data.json');
    } else if (filterId === '5' && roleId !== 'LM') {
      pageJSON = requireModule('../../_data/home/top-bar-secondary/top-bar-secondary.json');
    } else if (filterId === '5' && roleId === 'LM') {
      pageJSON = requireModule('../../_data/home/top-bar-secondary/top-bar-secondary-lm.json');
    }

    res.header("Access-Control-Allow-Origin", "*");

    setTimeout(function() {
      res.json(pageJSON);
    }, 100);
  });

  app.use(app.contextPath + '/:linemanagerview', mockServerRouter);
};
