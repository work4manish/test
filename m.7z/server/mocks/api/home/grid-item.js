var requireModule = require;
var getGeneralDashboardJSON = require('./general/general-dashboard');

module.exports = function(app) {
  var express = requireModule('express'),
    mockServerRouter = express.Router();
  var dataPath = '../../_data';

  function getJSON(gridId) {
    var pageJSON;

    if (gridId === 'searchViewGrid')  {
      var selectedChartName = app.getQueryParamValue(request, 'selectedChart');

      if (selectedChartName === 'MISSED MARK') {
        pageJSON = requireModule(dataPath + '/search/search-item-detail-grid-missed-mark.json');
      } else {
        pageJSON = requireModule(dataPath + '/search/search-item-detail-grid.json');
      }
    } else if (gridId.indexOf('Grid_Detail') > -1) {
      pageJSON = requireModule(dataPath + '/home/exception/detailview-grid-popup.json');
    } else {
      pageJSON = requireModule(dataPath + '/home/exception/detailview-grid.json');
    }

    return pageJSON;
  }

  mockServerRouter.get('/:griditem/gridview', function(request, response) {
    var pageJSON;
    var gridId = app.getQueryParamValue(request, 'gridId');
    var configRequired = app.getQueryParamValue(request, 'configRequired');
    var dashboardCategory = app.getQueryParamValue(request, 'category');

    console.log('*** grid-item.js: dashboardCategory : ' + dashboardCategory + ' ***');

    if (dashboardCategory === 'General') {
      return getGeneralDashboardJSON(request, response, app);
    }

    if (configRequired) {
      setTimeout(function() {
        pageJSON = getJSON(gridId);
        return response.json(pageJSON);
      }, 2000);
    } else {
      pageJSON = getJSON(gridId);
      return response.json(pageJSON);
    }
  });

  mockServerRouter.get('/:griditem/gridviewdetail', function(request, response) {
    var dashboardCategory = app.getQueryParamValue(request, 'category');
    console.log('************************ /:griditem/gridviewdetail **************');
    if (dashboardCategory === 'General') {
      return getGeneralDashboardJSON(request, response, app);
    }

    pageJSON = requireModule(dataPath + '/home/exception/detailview-grid-popup.json');
    return response.json(pageJSON);
  });

  app.use(app.contextPath, mockServerRouter);
};
