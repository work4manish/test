var requireModule = require;
var dataPath = '../../../_data';

module.exports = function(request, response, app) {
  if (request && response) {
    return getGeneralDashboardJSON(request, response, app);
  }

  function getGeneralDashboardJSON(request, response, app) {
    var _dataPath = dataPath + '/home/general/dashboard';
    var gridId = app.getQueryParamValue(request, 'gridId');
    var attributeId = app.getQueryParamValue(request, 'attributeId');
    var pageJSON;

    console.log('***************************: gridId : ' + gridId);

    var detailStr = '_Detail';
    if (gridId.indexOf(detailStr) === (gridId.length - detailStr.length)) {
      pageJSON = requireModule(_dataPath + '/portfolioAddedRemoved-detail.json');
    } else {
      pageJSON = requireModule(_dataPath + '/portfolioAddedRemoved.json');
    }

    return response.json(pageJSON);
  }
};
