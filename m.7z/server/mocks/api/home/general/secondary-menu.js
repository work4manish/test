var requireModule = require;

module.exports = function(app) {
  var express = requireModule('express'),
    mockServerRouter = express.Router();

  mockServerRouter.get('/linemanagerview/dashboards', function(request, response) {
    var pageJSON;
    var _dataURL = '../../../_data/home/general/';

    pageJSON = requireModule(_dataURL + 'secondary-menu.json');

    return response.json(pageJSON);
  });

  app.use(app.contextPath, mockServerRouter);
};
