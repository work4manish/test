module.exports = function(app) {
  var express = require('express'),
    mockServerRouter = express.Router();

  mockServerRouter.get('/dashboards', function(req, res) {
    var pageJSON = "{}";
    var dashboardCategory = app.getQueryParamValue(req, 'category');

    console.log('*** dashboardCategory : ' + dashboardCategory + ' ***');

    if (dashboardCategory === 'General') {
      pageJSON = require('../../_data/home/general/secondary-menu.json');
    } else {
      pageJSON = require('../../_data/home/exception/dashboard-list.json');
    }

    res.header("Access-Control-Allow-Origin", "*");
    setTimeout(function() {
      res.json(pageJSON);
    }, 100);
  });

  app.use(app.contextPath + '/linemanagerview', mockServerRouter);
};
