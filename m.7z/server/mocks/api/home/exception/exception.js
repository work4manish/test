var requireModule = require;
module.exports = function(app) {
  var express = requireModule('express');
  var mockServerRouter = express.Router();
  var dataPath = '../../../_data';

  mockServerRouter.get('/viewbydashboard', function(req, res) {
    var pageJSON;
    var gridView = app.getQueryParamValue(req, 'gridView');

    console.log('*** /viewbydashboard ***', req.query);

    if (gridView === true || gridView === 'true') {
      pageJSON = requireModule(dataPath + '/home/exception/viewbydashboard-grid.json');
    } else {
      pageJSON = requireModule(dataPath + '/home/exception/viewbydashboard-donut.json');
    }

    res.header("Access-Control-Allow-Origin", "*");
    res.json(pageJSON);
  });

  /*mockServerRouter.get('/viewbydashboard/retrievegriddata', function(req, res) {
    var pageJSON;
    pageJSON = requireModule(dataPath + '/home/exception/viewbydashboard-grid.json');
    res.header("Access-Control-Allow-Origin", "*");
    //setTimeout(function() {
      res.json(pageJSON);
    //}, 1000);
  });
*/
  mockServerRouter.get('/viewbyemployee', function(req, res) {
    var pageJSON;
    var filterId = String(app.getQueryParamValue(req, 'durationfilter'));
    console.log(filterId);

    pageJSON = requireModule(dataPath + '/home/exception/viewbyemployee-lm-bar.json');

    res.header("Access-Control-Allow-Origin", "*");
    //setTimeout(function() {
      res.json(pageJSON);
    //}, 100);
  });

  mockServerRouter.get('/viewbysummary', function(req, res) {
    var pageJSON;
    var filterId = String(app.getQueryParamValue(req, 'durationfilter'));

    if (filterId === "1M") {
      pageJSON = requireModule(dataPath + '/home/exception/viewbysummary-line.json');
    } else if (filterId === "2M" || filterId === "3M") {
      pageJSON = requireModule(dataPath + '/home/exception/viewbysummary-line-no-data.json');
    } else {
      pageJSON = requireModule(dataPath + '/home/exception/viewbysummary-line.json');
    }
    res.header("Access-Control-Allow-Origin", "*");
    //setTimeout(function() {
      res.json(pageJSON);
    //}, 500);
  });

  app.use(app.contextPath + '/linemanagerview', mockServerRouter);
};
