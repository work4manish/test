var requireModule = require;
module.exports = function(app) {
  var express = requireModule('express');
  var mockServerRouter = express.Router();
  var dataPath = '../../../_data';

  mockServerRouter.get('/viewbydashboard', function(req, res) {
    var pageJSON;

    var gridView = app.getQueryParamValue(req, 'gridView');

    console.log('*** /viewbydashboard ***', req.query);

    if (gridView === true || gridView === 'true') {
      pageJSON = requireModule(dataPath + '/home/exception/viewbydashboard-grid.json');
    } else {
      pageJSON = requireModule(dataPath + '/home/exception/viewbydashboard-donut.json');
    }

    res.header("Access-Control-Allow-Origin", "*");
    setTimeout(function() {
      res.json(pageJSON);
    }, 1000);
  });

  /*mockServerRouter.get('/viewbydashboard/retrievegriddata', function(req, res) {
    var pageJSON;
    pageJSON = requireModule(dataPath + '/home/exception/viewbydashboard-grid.json');
    res.header("Access-Control-Allow-Origin", "*");
    setTimeout(function() {
      res.json(pageJSON);
    }, 1000);
  });
*/
  mockServerRouter.get('/viewbyemployee', function(req, res) {
    var pageJSON;
    var pageFilter = String(app.getQueryParamValue(req, 'pagefilter'));
    var roleId = String(app.getQueryParamValue(req, 'roleid'));

    if (roleId === 'LM') {
      pageJSON = requireModule(dataPath + '/home/exception/viewbyemployee-lm-bar.json');
    } else {
      if(pageFilter=='sourcesystem'){
        pageJSON = requireModule(dataPath + '/home/exception/viewbyemployee-sourcesystem-bar3.json');
      }
      if(pageFilter=='notionalamount'){
        pageJSON = requireModule(dataPath + '/home/exception/viewbyemployee-notionalamount-bar3-1.json');

      }
      if(pageFilter=='ragstatus'){
        pageJSON = requireModule(dataPath + '/home/exception/viewbyemployee-ragstatus-bar3-2.json');

      }else{
        pageJSON = requireModule(dataPath + '/home/exception/viewbyemployee-sourcesystem-bar3.json');

      }
    }

    res.header("Access-Control-Allow-Origin", "*");
    setTimeout(function() {
      res.json(pageJSON);
    }, 1000);
  });

  mockServerRouter.get('/viewbysummary', function(req, res) {
    var pageJSON;
    pageJSON = requireModule(dataPath + '/home/exception/viewbysummary-line.json');
    res.header("Access-Control-Allow-Origin", "*");
    setTimeout(function() {
      res.json(pageJSON);
    }, 0);
  });

  app.use(app.contextPath + '/rolebasedview', mockServerRouter);
};
