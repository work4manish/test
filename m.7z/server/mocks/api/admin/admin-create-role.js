var requireModule = require;
module.exports = function(app) {
  var express = requireModule('express');
  var bodyParser = requireModule('body-parser');
  var mockRouter = express.Router();
  var dataPath = '../../_data/admin';

  mockRouter.use(bodyParser.json());
  mockRouter.use(bodyParser.urlencoded({
    extended: true
  }));

  mockRouter.post('/:createuserrole', function(request, response) {
    var pageJSON = requireModule(dataPath + '/admin-create-role.json');

    //response.status(400);
    response.send(pageJSON);
  });

  app.use(app.contextPath + '/useradmin', mockRouter);
};
