var requireModule = require;
module.exports = function(app) {
  var express = requireModule('express');
  var bodyParser = requireModule('body-parser');
  var mockRouter = express.Router();
  var dataPath = '../../_data/admin';

  mockRouter.use(bodyParser.json());
  mockRouter.use(bodyParser.urlencoded({extended: true}));

  mockRouter.get('/userinfo', function(request, response) {
    var searchString = app.getQueryParamValue(request, 'searchParm');
    var psIds = app.getQueryParamValue(request, 'psIds');
    console.log('****************** SELECTED PSIDS :::  ' + psIds);
    var pageJSON = requireModule(dataPath + '/psid-search-result.json');

    response.send(pageJSON);
  });

  mockRouter.get('/userreportees', function(request, response) {
    var searchString = app.getQueryParamValue(request, 'searchParm');
    var psIds = app.getQueryParamValue(request, 'psIds');
    console.log('****************** Reportees for PSID: ' + psIds);
    var pageJSON = requireModule(dataPath + '/psid-reportees-list.json');

    response.send(pageJSON);
  });

  app.use(app.contextPath + '/useradmin', mockRouter);
};
