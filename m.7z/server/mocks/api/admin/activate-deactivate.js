var requireModule = require;
module.exports = function(app) {
  var express = requireModule('express');
  var bodyParser = requireModule('body-parser');
  var mockRouter = express.Router();
  var dataPath = '../../_data/admin';

  mockRouter.use(bodyParser.json());
  mockRouter.use(bodyParser.urlencoded({
    extended: true
  }));

  mockRouter.get('/:params1/:params2/:params3', function(request, response) {
    var actionType = app.getPathParamValue(request, 'params1');
    var level = app.getPathParamValue(request, 'params2');
    var pageJSON;

    if (actionType === "edituserrole") {
      pageJSON = requireModule(dataPath + '/admin-edit-user-role.json');
    } else if (actionType === "disableuserrole") {
      pageJSON = requireModule(dataPath + '/activate-deactivate.json');
    } else if (actionType === "enableuserrole") {
      pageJSON = requireModule(dataPath + '/activate-deactivate.json');
    }else if (actionType === "bfshierarchy") {
      pageJSON = requireModule(dataPath + '/admin-business-level-'+level+'.json');
    }

    //response.status(400);
    response.send(pageJSON);
  });

  app.use(app.contextPath + '/useradmin', mockRouter);
};
