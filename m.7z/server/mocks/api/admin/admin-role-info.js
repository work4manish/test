var requireModule = require;
module.exports = function(app) {
  var express = requireModule('express');
  var bodyParser = requireModule('body-parser');
  var mockRouter = express.Router();
  var dataPath = '../../_data/admin';

  mockRouter.use(bodyParser.json());
  mockRouter.use(bodyParser.urlencoded({
    extended: true
  }));

  mockRouter.get('/roleinfo/:roleId', function(request, response) {
    var roleId = app.getPathParamValue(request, 'roleId');
    var pageJSON;

    if (roleId == 1) {
      pageJSON = requireModule(dataPath + '/admin-role-info-1.json');
    } else if (roleId == 2) {
      pageJSON = requireModule(dataPath + '/admin-role-info-2.json');
    } else if (roleId == 3) {
      pageJSON = requireModule(dataPath + '/admin-role-info-3.json');
    } else if (roleId == 4) {
      pageJSON = requireModule(dataPath + '/admin-role-info-4.json');
    } else if (roleId == 5){
      pageJSON = requireModule(dataPath + '/admin-role-info-5.json');
    }else{
      pageJSON = requireModule(dataPath + '/admin-role-info.json');
    }

    response.send(pageJSON);
  });

  app.use(app.contextPath + '/useradmin', mockRouter);
};
