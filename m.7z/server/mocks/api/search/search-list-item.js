var requireModule = require;
module.exports = function(app) {
  var express = requireModule('express');
  var bodyParser = requireModule('body-parser');
  var mockRouter = express.Router();
  var dataPath = '../../_data/search';

  mockRouter.use(bodyParser.json());
  mockRouter.use(bodyParser.urlencoded({extended: true}));

  mockRouter.get('/retrievesearchresults', function(request, response) {
    var searchString = app.getQueryParamValue(request, 'searchParm');
    var selectedSearchCriteria = app.getQueryParamValue(request, 'selectedSearchCriteria');
    console.log(searchString, selectedSearchCriteria);

    var pageJSON = requireModule(dataPath + '/search-list-item.json');

    if (searchString.indexOf('a') === 0) {
      pageJSON = requireModule(dataPath + '/search-list-item-5.json');
    } else if (searchString.indexOf('b') === 0) {
      pageJSON = requireModule(dataPath + '/search-list-item-10.json');
    }

    response.send(pageJSON);
  });

  mockRouter.get('/retrievetopbarinfo', function(request, response) {
    var psId = app.getQueryParamValue(request, 'psId');
    console.log(psId);

    var pageJSON = requireModule(dataPath + '/search-item-detail-top-info.json');

    response.send(pageJSON);
  });

  mockRouter.get('/retrievechartdata', function(request, response) {
    var userId = app.getQueryParamValue(request, 'userId');
    var chartId = app.getQueryParamValue(request, 'chartId');
    console.log('****** ' + userId, chartId);

    var pageJSON = requireModule(dataPath + '/search-item-detail-chart.json');

    response.send(pageJSON);
  });

  mockRouter.get('/retrievegriddata', function(request, response) {
    var pageJSON;
    var dashboardName = app.getQueryParamValue(request, 'dashboardName');

    if (dashboardName === 'MissedMark') {
      pageJSON = requireModule(dataPath + '/search-item-detail-grid-missed-mark.json');
    } else {
      pageJSON = requireModule(dataPath + '/search-item-detail-grid.json');
    }

    response.send(pageJSON);
  });

  mockRouter.get('/retrievesearchfilters', function(request, response) {
    var pageJSON = requireModule(dataPath + '/search-filter-menu.json');

    response.send(pageJSON);
  });

  app.use(app.contextPath + '/searchview', mockRouter);
};
