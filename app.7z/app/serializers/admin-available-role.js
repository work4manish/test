//import Ember from 'ember';
import DS from 'ember-data';

export default DS.RESTSerializer.extend(DS.EmbeddedRecordsMixin, {
  primaryKey: 'roleId',

  normalizeResponse(store, primaryModelClass, payload, id, requestType) {

    payload.adminAvailableRoles = payload.availableRoles;

    delete payload.availableRoles;

    return this._super(store, primaryModelClass, payload, id, requestType);
  }
});
