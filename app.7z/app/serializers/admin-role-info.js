//import Ember from 'ember';
import DS from 'ember-data';

export default DS.RESTSerializer.extend(DS.EmbeddedRecordsMixin, {

  attrs: {
    bfsHierarchyLevel4: {
      embedded: 'always'
    },
    bfsHierarchyLevel3: {
      embedded: 'always'
    },
    bfsHierarchyLevel2: {
      embedded: 'always'
    },
    roleConfiguration: {
      embedded: 'always'
    },
    availableCountries: {
      embedded: 'always'
    },
    bfsHierarchyLevel6: {
      embedded: 'always'
    }
  },
  normalizeResponse(store, primaryModelClass, payload, id, requestType) {
    payload.adminRoleInfo = payload.roleInfo ? payload.roleInfo : {};
    payload.adminRoleInfo.id = 'roleInfo-' + new Date().getTime();
    delete payload.roleInfo;
    return this._super(store, primaryModelClass, payload, id, requestType);
  }
});
