var RouteMap = function() {
  this.route('home', function() {
    this.route('exception', function() {
      this.route('detail', {
        path: '/:dashboard'
      });
    });
    this.route('general');
    this.route('search', function() {
      this.route('detail', {
        path: '/:psId'
      });
    });
  });
  this.route('admin');
};

export default RouteMap;
