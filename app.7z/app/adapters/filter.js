import ApplicationAdapter from './application';

export default ApplicationAdapter.extend({
  buildURL: function(modelName, id, snapshot, requestType, query) {
    let contextPath = '';
    let viewType = '';

    if (query.hasOwnProperty('dashboard')) {
      viewType = query.dashboard.toLowerCase();
    } else {
      viewType = 'linemanagerview';
    }

    contextPath = viewType + '/getfilter';

    return this._buildURL(contextPath);
  }
});
