import Ember from 'ember';
import AuthenticatedRoute from 'supdash-ui-core/routes/authenticated-route';
import RouteProgressIndicator from 'supdash-ui-core/mixins/route-progress-indicator';
import convertToJSON from '../../../mixins/convert-to-json';

export default AuthenticatedRoute.extend(RouteProgressIndicator, convertToJSON, {
  hideSecondaryNav: true,
  coreDataService: Ember.inject.service(),
  userCurrentRoleService: Ember.inject.service(),

  model( /*params*/ ) {
    let userCurrentRole = this.get('userCurrentRoleService').getCurrentRole();

    return this.get('coreDataService').queryRecord('filter', {
      roleId: userCurrentRole.roleId,
      filterId: 1
    });
  },

  afterModel() {
    let owner = Ember.getOwner(this);
    let topBarSecondaryController = owner.lookup('controller:sup-top-bar-secondary');
    topBarSecondaryController.toggleSecondaryTopBarTabs('index');
  },

  setupController(controller, model) {
    this._super(controller, model);
    this.setDurationFilter(controller, model);
    this.defaultControllerSetting(controller);
  },

  defaultControllerSetting(controller) {

    let userCurrentRole = this.get('userCurrentRoleService').getCurrentRole();
    let gridServiceParms = this.createServiceParams('Dashboard', userCurrentRole);
    gridServiceParms.screenName = 'exceptionViewByDashboard';
    gridServiceParms.gridView = true;

    controller.setProperties({
      viewDashConfig: this.createServiceParams('Dashboard', userCurrentRole),
      viewEmpConfig: this.createServiceParams('Employee', userCurrentRole),
      viewSummaryConfig: this.createServiceParams('Summary', userCurrentRole, 'dashboardName'),
      modelNameForModule: 'chartView',
      viewByDashboardGridConfig: {
        onRowSelect: 'onDashboardSelect',
        serviceParams: gridServiceParms
      },
      viewByDashboardActionItems: [{
        id: 'toggleChartToGrid',
        iconClass: 'mdi mdi-poll-box',
        action: 'toggleView',
        title: 'Toggle view'
      }]
    });
  },


  createServiceParams(cahrtType, role, dashboardName) {

    let roleId = !Ember.isEmpty(role) ? role.roleId : '';
    let roleName = !Ember.isEmpty(role) ? role.roleName : '';

    let serviceParams = {
      chartId: this.prepareChartId(cahrtType),
      durationFilter: '',
      includeIndirectReports: true,
      roleId: roleId,
      roleName: roleName
    };

    if (!Ember.isEmpty(dashboardName)) {
      serviceParams.dashboardName = 'MissedTrades';
    }

    return serviceParams;
  },

  refreshChart(dashboard, employee, summary) {
    this.controller.setProperties({
      refreshDashboard: dashboard,
      refreshEmployee: employee,
      refreshSummary: summary
    });
  },

  refreshing(attr) {
    this.controller.set(attr, false);
    Ember.run.next(() => {
      this.controller.set(attr, true);
    });
  },

  updateAllDashboardAttr(attr, value) {
    this.controller.get('viewDashConfig')[attr] = value;
    this.controller.get('viewEmpConfig')[attr] = value;
    this.controller.get('viewSummaryConfig')[attr] = value;
    this.controller.get('viewByDashboardGridConfig').serviceParams[attr] = value;
  },

  updateAllDashboardChartId() {
    this.controller.get('viewDashConfig').chartId = this.prepareChartId('Dashboard');
    this.controller.get('viewByDashboardGridConfig').serviceParams.chartId = this.controller.get('viewDashConfig').chartId;
    this.controller.get('viewEmpConfig').chartId = this.prepareChartId('Employee');
    this.controller.get('viewSummaryConfig').chartId = this.prepareChartId('Summary');
  },

  prepareChartId(dashboard) {

    let isLineManager = this.get('userCurrentRoleService').isLineManager();
    let chartIdPrefix = isLineManager ? 'LM_' : 'RB_';
    let chartId = chartIdPrefix + 'View_By_' + dashboard;
    return chartId;
  },

  setDurationFilter(controller, model) {
    let title = model.get('title');
    let data = model.get('durationFilter');

    if (!Ember.isEmpty(data)) {
      let filterItems = this.convertToJSON(data);
      let selectedObject = filterItems.findBy('selected', true);

      if (!Ember.isEmpty(filterItems) && filterItems.length > 0) {
        controller.setProperties({
          title: title,
          durationFilter: true,
          filterItems: filterItems,
          selected: selectedObject.id,
        });
      }
    }
  },

  actions: {
    chartClickAction(data) {
      let params = this.getDashboardParamsFor('chart', data);

      this.transitionToDetail(params);
    },

    onDashboardSelect(selectedDashboard) {
      let params = this.getDashboardParamsFor('grid', selectedDashboard);

      this.transitionToDetail(params);
    },

    resetRefreshFlagToFalse() {
      this.refreshChart(false, false, false);
    },

    onRoleChanged(role, roleName) {
      this.updateAllDashboardChartId();
      this.updateAllDashboardAttr('roleId', role);
      this.updateAllDashboardAttr('roleName', roleName);
      this.refreshChart(true, true, true);
    },

    selectAllDirectsReport(state) {
      this.updateAllDashboardAttr('includeIndirectReports', state);
      this.refreshChart(true, true, true);
    },

    onTabChange(val) {
      this.controller.get('viewDashConfig').durationFilter = val;
      this.controller.get('viewEmpConfig').durationFilter = val;
      this.controller.get('viewByDashboardGridConfig').serviceParams.durationFilter = val;

      this.refreshChart(true, true, false);
    },

    toggleView(/*uniqueElementId*/) {
      // let chartElement = Ember.$('.' + uniqueElementId + '-chart-view');
      let controller = this.controller;
      let hideChart = !controller.get('toggleViewByDashboard');

      if (hideChart) {
        // chartElement.fadeOut(500, function() {
        //   chartElement.css({
        //     "visibility": "hidden",
        //     "display": "block"
        //   }).slideUp(function() {
            controller.set('toggleViewByDashboard', hideChart);
        //   });
        // });
      } else {
        controller.set('toggleViewByDashboard', hideChart);
      }
    }
  },

  transitionToDetail(params) {
    this.transitionTo('home.exception.detail', params.dashboard, {
      queryParams: {
        appTitle: params.appTitle,
        includeIndirectReports: params.includeIndirectReports,
        durationFilter: params.durationFilter
      }
    });
  },
  /*
  * componentType : chart or grid
  */
  getDashboardParamsFor(componentType, selectedItem) {
    let params = {
      includeIndirectReports: this.controller.get('viewDashConfig').includeIndirectReports,
      durationFilter: this.controller.get('viewDashConfig').durationFilter,
    };

    if (componentType === 'chart') {
      params.appTitle = selectedItem.category;
      let dashboard;

      if (selectedItem.dataItem.seriesCode) {
        dashboard = selectedItem.dataItem.seriesCode;
      } else {
        dashboard = selectedItem.category ? selectedItem.category.replace(/([~!@#$%^&*()_+=`{}\[\]\|\\:;'<>,.\/? ])+/g, '').toLowerCase() : 'notFound';
      }

      params.dashboard = dashboard;

    } else if (componentType === 'grid') {
      params.appTitle = selectedItem.dashboard;
      params.dashboard = selectedItem.dashboardId ? selectedItem.dashboardId : selectedItem.dashboard.replace(/([~!@#$%^&*()_+=`{}\[\]\|\\:;'<>,.\/? ])+/g, '').toLowerCase();
    }

    return params;
  }
});
