import AuthenticatedRoute from 'supdash-ui-core/routes/authenticated-route';
import RouteProgressIndicator from 'supdash-ui-core/mixins/route-progress-indicator';

export default AuthenticatedRoute.extend(RouteProgressIndicator, {
  hideSecondaryNav: false,
  showModuleTitle: true,

  actions: {
    /* override this action as per requirement in the nested routes*/
    onMenuItemClicked(/*menuItem*/) {},
    onRoleChanged(/*role, roleName*/) {},
    //TODO: rename this action
    selectAllDirectsReport(/*state*/) {},
    changedOtherAttribute() {}
  },

  renderTemplate() {
    this.render('sup-secondary-nav', {
      outlet: 'secondary-nav',
      into: 'application'
    });

    this.render();
  }
});
