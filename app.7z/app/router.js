import Ember from 'ember';
import config from './config/environment';
import CoreRouter from 'supdash-ui-core/core-router';
//import RouteMap from './route-map';
const { getOwner } = Ember;

const Router = CoreRouter.extend({
  location: config.locationType,
  coreTransition: Ember.inject.service(),

  willUpdateTopbarView: Ember.on('willTransition', function(transition) {
    this.get('coreTransition').pushTransitionInfo(transition);

    this.deriveTitle(transition);
  }),

  updateTopBarView: Ember.on('didTransition', function() {
    try {
      let currentRoute = this.get('coreTransition').getCurrentRoute();

      this.updateTopBar(currentRoute);

    } catch (exception) {
      console.log(exception);
    }
  }),

  updateTopBar(currentRoute) {
    let owner = getOwner(this);
    let showModuleTitle = currentRoute.get('showModuleTitle');
    let topBarController = owner.lookup('controller:top-bar');

    if (showModuleTitle && this.topBarTitle && this.topBarTitleForRoute === currentRoute.routeName) {
      topBarController.setAppTitle(this.topBarTitle);
    } else {
      topBarController.setAppTitle();
    }
  },

  deriveTitle(transition) {
    this.topBarTitle = '';
    let appTitle = transition.queryParams.appTitle ?
                      transition.queryParams.appTitle :
                      this.get('coreTransition').getTransitionQueryParams(transition).appTitle;

    if (appTitle) {
      this.topBarTitle = appTitle;
      // save the route name also and in updateTopBar check that
      // current route is equal to the topBarTitleForRoute
      let targetRouteName = transition.targetName;

      if (targetRouteName.endsWith('.index')) {
        targetRouteName = targetRouteName.substring(0, targetRouteName.lastIndexOf('.index'));
      }

      this.topBarTitleForRoute = targetRouteName;
    }
  }
});

//Router.map(RouteMap);

Router.map(function() {
  this.route('home', function() {
    this.route('exception', function() {
      this.route('detail', {
        path: '/:dashboard'
      });
    });
    this.route('general', function() {
      this.route('generaldetail', {
        path: '/:dashboard'
      });
    });
    this.route('search', function() {
      this.route('detail', {
        path: '/:psId'
      });
    });
  });

  this.route('admin', function() {
    this.route('userprofiles');
  });
});

export default Router;
