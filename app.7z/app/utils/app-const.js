export default {
  LINE_MANAGER: 'Line Manager',
  KEY_CODE: {
    ENTER: 13
  },
  STATE: {
    PROGRESS: 'Progress',
    FINISHED: 'Finished'
  }
};
