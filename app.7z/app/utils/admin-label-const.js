export default {
  dashboardAppTitle: 'SDB',
  baseAppTitle: 'Admin',
  HEADERTITLE: 'Entitlements',
  USERPROFILETITLE: 'User Profiles',
  EXPORTAUDIT: 'EXPORT AUDIT TRAIL',
  EXPORTTOEXCEL: 'EXPORT TO EXCEL',
  EXPORTROLEMATRIX: 'EXPORT ROLE MATRIX',
  EXPORTROLEMATRIXURL: '/useradmin/rolematrix',
  EXPORTAUDITURL: '/useradmin/audittrail',
  EXPORTTOEXCELURL: '/useradmin/userprofilereport',
  ADDUSER: 'ADD A USER',
  POPUPTABS: {
    tabArray: [{
      "id": "profile",
      "title": "Profile"
    }, {
      "id": "userRole",
      "title": "User Role"
    }],
    selected: 'profile'
  },
  ROWACTIONITEMS: [{
    "id": "deactivate",
    "title": "Deactivate User",
    "iconClass": "mdi mdi-lock",
    "action": "gridHoverOnDeactivateClick",
    "conditionalClass": {
      "key": "isRoleActive",
      "value": {
        "true": {
          "className": "mdi-border-color",
          "title": "Deactivate User"
        },
        "false": {
          "className": "mdi-lock-open",
          "title": "Activate User"
        }
      }
    }
  }, {
    "id": "editUser",
    "title": "Edit User",
    "iconClass": "mdi mdi-border-color",
    "action": "gridHoverOnEditClick",
    "conditionalClass": {
      "key": "isRoleActive",
      "value": {
        "true": {
          "className": "mdi-border-color",
          "title": "Edit"
        },
        "false": {
          "className": "hidden",
          "title": ""
        }
      }
    }
  }]
};
