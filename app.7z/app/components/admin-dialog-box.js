import Ember from 'ember';
import MapActionMixin from '../mixins/map-action-mixin';

export default Ember.Component.extend(MapActionMixin, {
  store: Ember.inject.service(),
  showModalTabs: true,
  showSearchResultDialog: 'showSearchResultDialog',

  actions: {
    onTabChange(tab) {
      this.selectedTab = tab;
      this.sendAction(this.action, tab);
    },

    showSearchResultDialog(parentDialog) {
      this.sendAction(this.showSearchResultDialog, parentDialog);
    }
  },

  init() {
    this._super();
    this.mapAction('action');
    this.set('selected', this.get('tabsArrayConfig.selected'));
    this.selectedTab = this.get('tabsArrayConfig').selected;
  }

});
