import Ember from 'ember';

export default Ember.Component.extend({
  classNames:['mdi-toast-msg'],
  toastActionLable:'GOT IT',
  toastIcon: 'mdi-information',
  msgTypeClass:'sucess-msg',
  outerCircleClass:null,
  toastMsg:'',
  duration:2800,

  actions:{
    closeMsgPanel(){
      //this.$('.toast-container').fadeOut();
    }
  },

  didInsertElement(){

    // this.$('.mdi-toast-msg').css({
    //   top:-10
    // });

    // Ember.run.later(()=>{
    // this.$('.mdi-toast-msg').css({
    //   top:-100
    // });
    // },this.duration);
  }
});
