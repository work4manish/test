import Ember from 'ember';
import mdRadio from 'ember-cli-materialize/components/md-radio';
import MapActionMixin from '../mixins/map-action-mixin';


export default mdRadio.extend(MapActionMixin,{
  click(e){
    if(!Ember.isEmpty(e.target) && !Ember.isEmpty(e.target.type) && e.target.type.toUpperCase()==="RADIO"){
      this.sendAction(this.onRadioClick,this.get('value'));
    }
  },
  init() {
    this._super();
    this.mapAction('onRadioClick');
  }
});
