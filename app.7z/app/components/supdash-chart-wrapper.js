import Ember from 'ember';
import convertToJSON from '../mixins/convert-to-json';

//const { get, A, computed } = Ember;

/**
 * Purpose: This is generic chart component, This componet is a wrapper for wb-new-barchart
 * All properites whihch will be required by wb-new-barchart are initialzed in the component
 * This also adds some dom element like header and action button on that header.
 */
export default Ember.Component.extend(convertToJSON, {
  classNames: ['chart-wrapper-container'],
  coreDataService: Ember.inject.service(),
  userCurrentRoleService: Ember.inject.service(),
  chartClickAction: 'chartClickAction',
  onChartSeriesClickAction: 'onChartSeriesClickAction',
  refreshOnDurationFilterChange: 'refreshOnDurationFilterChange',
  resetRefreshFlagToFalse: 'resetRefreshFlagToFalse',
  detailSreenChartClick: 'detailSreenChartClick',
  onAdditionalFilterChanged: 'onAdditionalFilterChanged',
  onPageFilterChanged: 'onPageFilterChanged',
  chartConfig: {},
  chartDataSourceConfig: {},
  isContentLoaded: false,
  showRadioComponent: false,
  serviceParams: {},
  modelNameForModule: null,
  fullWidth: false,
  durationFilter: false,
  regularFilter: false,
  hideHeader: false,
  sendActionToRoute: false,
  updateTitleValue: false,
  chartLoading: false,
  noDataFoundMessage: 'No Data Found',
  hideChart: false,

  refreshObserver: Ember.observer('refresh', function() {
    if (this.get('refresh')) {
      if (!this.hideChart) {
        this.set('chartLoading', true);
        this.initializeChartWrapper(true);
      }
    }
  }),

  hideChartObserver: Ember.observer('hideChart', function() {
    if (!this.hideChart) {
      this.set('chartLoading', true);
      this.initializeChartWrapper(true);
    }
  }),

  actions: {
    onTabChange(durationFilter) {
      if (this.get('sendActionToRoute')) {
        this.sendAction('refreshOnDurationFilterChange', durationFilter);
      } else {
        this.updateChartDataAndTitle('durationFilter', durationFilter);
      }
    },

    radioClickAction(dashboardName) {
      this.updateChartDataAndTitle('dashboardName', dashboardName);
    },

    onPageFilterChange(pageFilter) {
      if (this.get('sendActionToRoute')) {
        this.sendAction('onPageFilterChanged', pageFilter);
      } else {
        this.updateChartDataAndTitle('pageFilter', pageFilter);
      }
    },

    onAdditionalFilterChange(additionalFilter) {
      if (this.get('sendActionToRoute')) {
        this.sendAction('onAdditionalFilterChanged', additionalFilter);
      }
    },

    chartSeriesClick(event) {
      this.sendAction('chartClickAction', event);
    },

    onChartSeriesClick(event, showTotal) {

      if (this.updateTitleValue && this.get('chartTitleObj')) {
        let totalCount = showTotal ? this.get('chartTitleObj').get('value') : event.value;
        this.set('totalCount', totalCount);
      }

      this.sendAction('onChartSeriesClickAction', event, showTotal);
    },

    detailSreenChartClick(event, showTotal) {

      if (this.updateTitleValue && this.get('chartTitleObj')) {

        let totalCount = showTotal ? this.get('chartTitleObj').get('value') : (event.dataItem.title ? event.dataItem.title : event.value);
        this.set('totalCount', totalCount);
      }
      this.sendAction('detailSreenChartClick', event, showTotal);
    },

    onActionItemClick(actionName, uniqueElementId) {
      this[actionName] = actionName;      // added so that custom action can be sent from this component
      this.sendAction(actionName, uniqueElementId);
    }
  },

  init: function() {
    this._super();

    this.initializeGridConfig();
    this.initializeChartWrapper(false);
  },

  initializeGridConfig() {
    if (this.gridConfig) {
      if (this.gridConfig.onRowSelect) {
        this.actions[this.gridConfig.onRowSelect] = function (selecedItem) {
          this[this.gridConfig.onRowSelect] = this.gridConfig.onRowSelect;
          this.sendAction(this.gridConfig.onRowSelect, selecedItem);
        };
      }

      this.actions[this.resetRefreshFlagToFalse] = function() {
        this.sendAction(this.resetRefreshFlagToFalse, arguments);
      };
    }
  },

  initializeChartWrapper(updateFilter) {
    this.modelNameForModule = this.get('modelNameForModule');
    this.serviceParams = Ember.copy(this.get('serviceParams'), true);
    this.serviceParams.isLineManager = this.get('userCurrentRoleService').isLineManager();
    let showRadioComponent = this.get('showRadioComponent');
    let serviceObjects = {
      chartServices: this.get('coreDataService').queryRecord(this.modelNameForModule, this.serviceParams)
    };

    if (showRadioComponent) {
      serviceObjects.radioServices = this.get('coreDataService').queryRecord('dashboardList', {});
    }

    Ember.RSVP.hash(serviceObjects).then((a_data) => {
      if (this.isDestroyed) {
        return;
      }

      let chartServiceData = a_data.chartServices;
      let radioServiceData = !Ember.isEmpty(a_data.radioServices) ? a_data.radioServices : {};
      let chartData = chartServiceData.get('chartData');
      let config = chartServiceData.get('chartConfig');
      let chartSeries = chartData.get('chartSeries');
      let totalTitle = chartData.get('chartTitle');
      if (!Ember.isEmpty(config.get('noDataFoundMessage'))) {
        this.set('noDataFoundMessage', config.get('noDataFoundMessage'));
      }

      this.setWrapperHeight(config.get('height'));

      let title = config.get('title');

      Ember.run.next(() => {
        this.set('chartLoading', false);
      });

      this.setDataAndConfig(chartSeries, config, title, totalTitle);
      this.setDurationFilter(chartServiceData.get('filter'), updateFilter);
      //this.setRegularFilter(chartServiceData.get('filter'));
      this.setComboFilters(chartServiceData.get('filter'));

      if (showRadioComponent && !Ember.isEmpty(radioServiceData)) {
        this.setRadioFilter(radioServiceData);
      }

      if (this.get('refresh')) {
        this.sendAction('resetRefreshFlagToFalse', this);
      }

      this.set('isContentLoaded', true);
      this.set('showRadioComponent', showRadioComponent);
    });
  },

  createChartTotalLabel(chartTitleModel) {
    this.setProperties({
      label: chartTitleModel.get('label'),
      totalCount: chartTitleModel.get('value')
    });
  },

  updateChartDataAndTitle(attr, value) {
    this.set('chartLoading', true);
    this.serviceParams[attr] = value;
    this.get('coreDataService').queryRecord(this.modelNameForModule, this.serviceParams).then((a_data) => {
      if (this.isDestroyed) {
        return;
      }

      this.setWrapperHeight(a_data.get('chartConfig').get('height'));

      this.set('chartData', a_data.get('chartData').get('chartSeries'));
      if (!Ember.isEmpty(a_data.get('chartConfig').get('noDataFoundMessage'))) {
        this.set('noDataFoundMessage', a_data.get('chartConfig').get('noDataFoundMessage'));
      }

      let chartTitle = a_data.get('chartData').get('chartTitle');
      this.createChartTotalLabel(chartTitle);
      this.setProperties({
        chartTitleObj: chartTitle,
        chartLoading: false
      });

    }.bind(this));
  },

  setComboFilters(filter) {
    let comboFilters =  filter.get('comboFilters');

    if (comboFilters) {
      //TODO:
      console.log('TODO: Implementation pending');
    } else {
      this.setRegularFilter(filter);
      this.setAdditionalFilter(filter);
    }
  },

  setRegularFilter(a_data) {
    let data = a_data.get('regularFilter');

    this.set('regularFilter', false);

    //TODO: dirty fix for refreshing the content of combo...its reRending it; FIXIT
    Ember.run.next(() => {
      if (!Ember.isEmpty(data)) {
        let filterItems = this.convertToJSON(data);
        let selectedObject = filterItems.findBy('selected', true);

        if (!Ember.isEmpty(filterItems) && filterItems.length > 0) {
          this.set('regularFilter', true);
          this.setProperties({
            contents: filterItems,
            regularSelected: selectedObject.id,
          });
        }
      }
    });
  },

  setAdditionalFilter(a_data) {
    let data = a_data.get('additionalFilter');

    this.set('roleBasedView', false);
    this.set('additionalFilter', false);

    if (!this.get('userCurrentRoleService').isLineManager()) {
      Ember.run.next(() => {
        if (!Ember.isEmpty(data)) {
          let filterItems = this.convertToJSON(data);
          let selectedObject = filterItems.findBy('selected', true);

          if (!Ember.isEmpty(filterItems) && filterItems.length > 0) {
            this.set('additionalFilter', true);
            this.set('roleBasedView', true);
            this.setProperties({
              additionalFilterItems: filterItems,
              additionalFilterSelected: selectedObject.id,
            });
          }
        }
      });
    }
  },

  setDurationFilter(a_data, updateFilter) {
    let data = a_data.get('durationFilter');
    if (!Ember.isEmpty(data)) {
      let filterItems = this.convertToJSON(data);
      let selectedObject = filterItems.findBy('selected', true);
      if (!Ember.isEmpty(filterItems) && filterItems.length > 0) {

        if (!updateFilter) {
          this.set('durationFilter', true);
          this.setProperties({
            durationFilter: true,
            filterItems: filterItems
          });
        }

        this.set('selected', selectedObject.id);
      }

    } else {
      this.set('durationFilter', false);
    }

  },

  setRadioFilter(a_data) {
    this.setProperties({
      selection: a_data.get('selected'),
      optionValuePath: 'id',
      optionLabelPath: 'title',
      content: a_data.get('dashboardItems'),
      clickAction: 'radioClickAction',
    });
  },

  setDataAndConfig(data, config, title, totalTitle) {
    let legend = config.get('legend');
    let legendAlignClass = '';

    if (legend) {
      legendAlignClass = 'legend-align-' + legend;
    }

    this.setProperties({
      title: title,
      chartData: data,
      chartConfig: config,
      legendAlignClass: legendAlignClass,
      chartTitleObj: totalTitle
    });

    this.createChartTotalLabel(totalTitle);
  },

  setWrapperHeight(height){
    Ember.$('.exception-dashboard .dynamicHeight').css({height:height});
  }
});
