import Ember from 'ember';
import cs from '../mixins/component-support';

export default Ember.Component.extend(cs, {
  /**
   * TODAY_PROPERTY of the date-picker.
   *
   * @property {string} TODAY_PROPERTY
   * @default  'today'
   */
  TODAY_PROPERTY: 'today',
  format: "dd MMM yyyy",
  attributeBindings: ['longValue'],
  classNameBindings: ['readonly:readonly'],
  classNames: null, //'dropdown-date-picker - to change the look and feel like drop-down

  willInsertElement() {
    this._super();
    //this.initiateKendoComponent();
    var input = this.$('input.ember-text-field'),
      instance = this.$(input),
      config = this.get('config'),
      options = {};
    /**
     * Check for Kendo Config input.
     */
    if (!Ember.isEmpty(config)) {
      this.updateCurrentDate(config);
      options = config;
    }
    this.setKendoOption(options, 'format', 'format');
    if (this.get('longValue')) {
      options.value = this.getDateValue(this.get('longValue'));
    }

    instance.kendoDatePicker(options);

    if (config) {
      let datePickerObject = this.$(input).data("kendoDatePicker");

      if (config.min) {
        datePickerObject.min(config.min);
      }
      if (config.max) {
        datePickerObject.max(config.max);
      }
    }

    this.addObserver('longValue', this.longValueChange);
    this.addObserver('config', this.configChanged);
  },

  setMax(date) {
    let datePickerObject = this.$('input.ember-text-field').data("kendoDatePicker");

    datePickerObject.max(date);
  },

  setMin(date) {
    let datePickerObject = this.$('input.ember-text-field').data("kendoDatePicker");

    datePickerObject.min(date);
  },

  willDestroyElement() {
    this.removeObserver('config', this.configChanged);
    this.removeObserver('longValue', this.longValueChange);
    return this._super();
  },
  longValueChange() {
    var longValue = (this.longValue) ? parseInt(this.longValue) : 0;
    if (longValue && new Date(longValue).getTime() > 0) {
      this.set('value', this.getDateValue(longValue));
    } else {
      this.set('value', null);
    }
  },
  change() {
    var dateTime = kendo.parseDate(this.get('value'),
      this.get('format'));
    if (!Ember.isEmpty(dateTime)) {
      if (this.isDateRangeValid(dateTime)) {
        this.set('longValue', dateTime.getTime());
      } else {
        //Reverting back to previous date if range is invalid
        this.updateDatePickerValue(this.get('longValue'));
      }
    } else {
      this.set('longValue', null);
      this.updateDatePickerValue(null);
    }
    this.sendAction('action', this.get('value'), this.get('longValue'));
    if (this.isDateRangeValid(dateTime)) {
      this.sendAction("onChangeAction", this.get('value'), this.get('longValue'));
    }
  },
  /**
   * isDateRangeValid Function: To validate date -
   * if min and max values are present in configuration
   * @function isDateRangeValid
   * @returns  {bool}
   */
  isDateRangeValid(newDate) {
    var config = this.get('config'),
      status = true;
    if (Ember.isEmpty(config)) {
      return true;
    }
    if (config.min) {
      if (newDate >= config.min) {
        status = true;
      } else {
        status = false;
      }
    }
    if (config.max && status) {
      if (newDate <= config.max) {
        status = true;
      } else {
        status = false;
      }
    }
    return status;
  },
  /**
   * updateDatePickerValue Function: To update date value on change
   * date value will get reverted if user type invalid date or date not in range
   * @function updateDatePickerValue
   * @returns  {void}
   */
  updateDatePickerValue(longValue) {
    var input = this.$('input.ember-text-field'),
      datePickerObject = this.$(input).data("kendoDatePicker");
    if (longValue) {
      datePickerObject.value(new Date(longValue));
    } else {
      datePickerObject.value(null);
    }
  },
  /**
   * updateCurrentDate Function: To update min/max config based on TODAY_PROPERTY.
   * @function updateCurrentDate
   * @returns  {void}
   */
  updateCurrentDate(config) {
    if (config.hasOwnProperty('min') && config.min === this.get('TODAY_PROPERTY')) {
      config.min = new Date();
      //set default time for date range validation
      config.min.setHours(0, 0, 0, 0);
    }
    if (config.hasOwnProperty('max') && config.max === this.get('TODAY_PROPERTY')) {
      config.max = new Date();
      //set default time for date range validation
      config.max.setHours(0, 0, 0, 0);
    }
  },
  getDateValue(longValue) {
    return kendo.toString(new Date(longValue), this.get('format'));
  },
  configChanged() {
    var kendoInstance = this.$('input.ember-text-field').data('kendoDatePicker'),
      config = this.config,
      isValueInvalid = false,
      longValue = this.longValue;
    this.updateCurrentDate(config);
    if (config.max instanceof Date) {
      kendoInstance.max(config.max);
      if (longValue && longValue > this.config.max.getTime()) {
        isValueInvalid = true;
      }
    }
    if (config.min instanceof Date) {
      kendoInstance.min(config.min);
      if (longValue && longValue < this.config.min.getTime()) {
        isValueInvalid = true;
      }
    }
    if (isValueInvalid) {
      Ember.run.next(this, function() {
        this.set('value', null);
        this.set('longValue', null);
      });
    }
  },
  actions: {
    //Opening datepicker pane when user presses enter or clicks
    openDatePicker() {
      if (this.readonly !== true && this.get('disabled') !== true) {
        this.$('input').data("kendoDatePicker").open();
      }
    }
  }
});
