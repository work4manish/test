import DS from 'ember-data';

export default DS.Model.extend({
  title : DS.attr('string'),
  type : DS.attr('string'),
  xAxis : DS.attr('string'),
  xAxisDisplayName:DS.attr('string'),
  yAxis: DS.attr('string'),
  stack:DS.attr('boolean'),
  groupBy: DS.attr('string'),
  legend: DS.attr('string'),
  seriesClick: DS.attr('string'),
  legendClick: DS.attr('boolean'),
  axisClick : DS.attr('string'),
  hideRag: DS.attr('boolean'),
  seriesClickAction: DS.attr('string'),
  noDataFoundMessage: DS.attr('string'),
  height:DS.attr('number',{ defaultValue: 440 })
});
