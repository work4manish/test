import Ember from 'ember';

export default Ember.Mixin.create({
    init() {
        this._super();
        if (this.get('model') != null) {
            this.set('model.componentReference', this);
        }
    }
});

