import Ember from 'ember';
import AppConst from '../utils/app-const';

export default Ember.Mixin.create({
  rowSelectionMode: '', // possible values : checkbox, simple
  rowId: 'attributeId',
  checkboxLabelClass: 'mdi-checkbox-label',
  checkboxClass: 'mdi-checkbox',
  selectAllEventState: null,
  selectedRows: null,

  selectAllEventObserver: Ember.observer('selectAllEventState', 'selectedRows.length', function() {
    if (AppConst.STATE.PROGRESS === this.selectAllEventState) {
      if (this.selectedRows.length === this.get('data').length || this.selectedRows.length === 0) {
        this.sendRowCheckAction(true);
        this.set('selectAllEventState', AppConst.STATE.FINISHED);
      }
    }
  }),

  addCheckboxColumn() {
    let checkboxColConfig = {
      field: 'checkboxField',
      title: ' ',
      sortable: false,
      width: 30,
      template: '<div class="mdi-checkbox-container">' +
        '<input type="checkbox" class="checkbox '+ this.checkboxClass + ' filled-in" />' +
        '<label class="' + this.checkboxLabelClass + '"></label>' +
        '</div>',

      headerTemplate: '<div class="mdi-checkbox-container">' +
        '<input type="checkbox" class="checkbox '+ this.checkboxClass + ' filled-in" />' +
        '<label class="' + this.checkboxLabelClass + '"></label>' +
        '</div>'
    };

    if (this.gridColumnsLockable) {
      checkboxColConfig.locked = true;
      checkboxColConfig.width = 40;
    }

    this.gridConfig.columns.unshift(checkboxColConfig);
  },

  attachRowSelectEvent() {
    this.grid.thead.on('click', '.' + this.checkboxLabelClass, this.onSelectAllClick.bind(this));
    this.grid.table.on('click', '.' + this.checkboxLabelClass, this.selectRow.bind(this));
  },

  toggleCheckboxState(event, forceValue) {
    let selectedLabel = Ember.$(event.target);
    let siblings = selectedLabel.siblings();
    let checkbox = siblings.filter('.' + this.checkboxClass);

    if (forceValue !== undefined) {
      checkbox.prop('checked', forceValue);
    } else if (checkbox && checkbox.length > 0) {
      checkbox.prop('checked', !checkbox.prop('checked'));
    }

    event.stopPropagation();
    return checkbox;
  },

  selectRow(event) {
    let checkbox = this.toggleCheckboxState(event, this.forceValue);
    let row = Ember.$(event.target).closest("tr");
    let dataItem = this.grid.dataItem(row);
    let checked = checkbox.prop('checked');

    if (this.forceValue === undefined) {
      this.toggleRows(checked, row, dataItem);
      this.updateSelectAllCheckboxState(checked);
      this.sendRowCheckAction(false, dataItem);
    } else {
      this.toggleRows(this.forceValue, row, dataItem);
    }
  },

  toggleRows(checked, row, dataItem) {
    if (checked) {
      this.selectedRows.addObject(dataItem);
      row.addClass("k-state-selected");
    } else {
      this.selectedRows.removeObject(dataItem);
      row.removeClass("k-state-selected");
    }
  },

  onSelectAllClick(event) {
    let checkbox = this.toggleCheckboxState(event, this.forceValue);

    if (this.fireClickEventForEachCheckbox !== false) {
      this.forceValue = checkbox.prop('checked');
      this.grid.table.find('.' + this.checkboxLabelClass).click();
      this.set('selectAllEventState', AppConst.STATE.PROGRESS);

      delete this.forceValue;
    }
  },

  sendRowCheckAction(isAllCheckClicked, dataItem) {
    if (this.onRowCheck) {
      this[this.onRowCheck] = this.onRowCheck;
      this.sendAction(this.onRowCheck, this.getSelectedRows(), isAllCheckClicked,
                          dataItem ? dataItem.toJSON() : dataItem);
    }
  },

  updateSelectAllCheckboxState(checked) {
    var selectAllCheckboxLabel = this.grid.thead.find('.' + this.checkboxLabelClass);

    if (selectAllCheckboxLabel && selectAllCheckboxLabel.length > 0) {
      this.forceValue = checked;
      this.fireClickEventForEachCheckbox = false;
      let checkbox = selectAllCheckboxLabel.siblings().filter('.' + this.checkboxClass);

      if (this.selectedRows.length === this.get('data').length && !checkbox.prop('checked')) {
        selectAllCheckboxLabel.click();
      } else if (checkbox.prop('checked')) {
        selectAllCheckboxLabel.click();
      }

      delete this.fireClickEventForEachCheckbox;
      delete this.forceValue;
    }
  },

  resetSelectedRows() {
    if (this.selectedRows) {
      this.selectedRows.clear();
    }

    let selectAllCheckboxLabel = this.grid.thead.find('.' + this.checkboxLabelClass);
    if (selectAllCheckboxLabel && selectAllCheckboxLabel.length > 0) {
      let checkbox = selectAllCheckboxLabel.siblings().filter('.' + this.checkboxClass);

      if (checkbox) {
        this.forceValue = false;
        this.fireClickEventForEachCheckbox = false;

        selectAllCheckboxLabel.click();

        delete this.forceValue;
        delete this.fireClickEventForEachCheckbox;
      }
    }
  },

  getSelectedRows() {
    let selectedRows = [];

    if (this.selectedRows && this.selectedRows.length > 0) {
      for (let i = 0, len = this.selectedRows.length; i < len; i++) {
        let selectRow = this.selectedRows[i];

        selectedRows[selectedRows.length] = selectRow.toJSON();
      }
    }

    return selectedRows;
  }
});
